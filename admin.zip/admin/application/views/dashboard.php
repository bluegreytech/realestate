<?php 
 //$this->load->view('common/css'); 
$this->load->view('common/header'); 
$this->load->view('common/sidebar');
?>

    <div class="app-content content container-fluid">
      <div class="content-wrapper">
        <div class="content-body"><!-- Basic Tables start -->
  
<!-- Table head options start -->
<div class="row">
    <div class="col-xs-12">
       <div col-md-4></div>
       <div col-md-4></div>
       <div col-md-4></div>

    </div>
</div>
<!-- Table head options end -->



        </div>
      </div>
    </div>

<?php 
$this->load->view('common/footer'); 
//$this->load->view('common/js'); 
?>
