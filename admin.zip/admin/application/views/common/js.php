<!-- BEGIN VENDOR JS-->
 

    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.js" type="text/javascript" ></script>
    <script src="<?php echo base_url(); ?>default/js/core/libraries/jquery.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>default/vendors/js/ui/tether.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>default/js/core/libraries/bootstrap.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>default/vendors/js/ui/perfect-scrollbar.jquery.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>default/vendors/js/ui/unison.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>default/vendors/js/ui/blockUI.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>default/vendors/js/ui/jquery.matchHeight-min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>default/vendors/js/ui/screenfull.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>default/vendors/js/extensions/pace.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>default/js/jquery.dataTables.min.js" type="text/javascript"></script>
   
     <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js"></script>
    <!-- BEGIN VENDOR JS-->
    <!-- BEGIN PAGE VENDOR JS-->
    <!-- END PAGE VENDOR JS-->
    <!-- BEGIN ROBUST JS-->
     <script type="text/javascript" src="<?php echo base_url(); ?>default/js/jquery.validate.min.js"></script>

    <script src="<?php echo base_url(); ?>default/js/core/app-menu.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>default/js/core/app.js" type="text/javascript"></script>
     <script src="http://jqueryvalidation.org/files/dist/additional-methods.min.js"></script>

    
    <!-- END ROBUST JS-->
    <!-- BEGIN PAGE LEVEL JS-->
    <!-- END PAGE LEVEL JS-->
  </body>

</html>
