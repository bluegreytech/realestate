<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-10 08:40:18 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 08:40:19 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 08:40:19 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 08:40:19 --> 404 Page Not Found: Userrole/app-assets
ERROR - 2019-06-10 08:41:23 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 08:41:23 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 08:41:23 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 08:41:23 --> 404 Page Not Found: Userrole/app-assets
ERROR - 2019-06-10 08:41:24 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 08:41:25 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 08:43:22 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 08:43:23 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 08:43:58 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 08:43:58 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 08:44:56 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 08:44:56 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 08:45:03 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 08:45:03 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-10 08:45:06 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 08:45:06 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-10 08:45:08 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 08:45:08 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-10 08:45:11 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 08:45:11 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-10 08:45:16 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 08:45:16 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-10 08:45:29 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 08:45:29 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 08:45:43 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 08:45:43 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-10 08:45:52 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 08:45:52 --> 404 Page Not Found: Stream/app-assets
ERROR - 2019-06-10 08:45:56 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 08:45:56 --> 404 Page Not Found: Stream/app-assets
ERROR - 2019-06-10 08:46:05 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 08:46:05 --> 404 Page Not Found: Stream/app-assets
ERROR - 2019-06-10 08:46:15 --> Severity: Notice --> Undefined property: stdClass::$ProgramId C:\xampp\htdocs\mentor\admin\application\views\Assesment\AssesmentAdd.php 56
ERROR - 2019-06-10 08:46:15 --> Severity: Notice --> Undefined property: stdClass::$ProgramName C:\xampp\htdocs\mentor\admin\application\views\Assesment\AssesmentAdd.php 56
ERROR - 2019-06-10 08:46:15 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 08:46:15 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 08:46:25 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 08:46:25 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-10 08:49:03 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 08:49:03 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-10 08:49:05 --> Severity: Notice --> Undefined property: stdClass::$ProgramId C:\xampp\htdocs\mentor\admin\application\views\Assesment\AssesmentAdd.php 56
ERROR - 2019-06-10 08:49:05 --> Severity: Notice --> Undefined property: stdClass::$ProgramName C:\xampp\htdocs\mentor\admin\application\views\Assesment\AssesmentAdd.php 56
ERROR - 2019-06-10 08:49:58 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 08:49:58 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-10 08:52:46 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 08:52:47 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-10 08:55:08 --> Query error: Unknown column 't1.ProgramName' in 'field list' - Invalid query: SELECT `t1`.`AssesmentTypeId`, `t1`.`ProgramName`, `t1`.`ProgramDescription`, `t1`.`ProgramPrice`, `t1`.`ProgramImage`, `t1`.`IsActive`, `t2`.`StreamTypeId`, `t2`.`StreamName`
FROM `tblassesmenttype` as `t1`
LEFT JOIN `tblstreamtype` as `t2` ON `t1`.`StreamTypeId` = `t2`.`StreamTypeId`
ERROR - 2019-06-10 08:55:22 --> Severity: Notice --> Undefined variable: programData C:\xampp\htdocs\mentor\admin\application\views\Assesment\AssesmentAdd.php 53
ERROR - 2019-06-10 08:55:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mentor\admin\application\views\Assesment\AssesmentAdd.php 53
ERROR - 2019-06-10 08:55:22 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 08:55:23 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 08:57:17 --> Query error: Unknown column 't1.ProgramName' in 'field list' - Invalid query: SELECT `t1`.`AssesmentTypeId`, `t1`.`ProgramName`, `t1`.`ProgramDescription`, `t1`.`ProgramPrice`, `t1`.`ProgramImage`, `t1`.`IsActive`, `t2`.`StreamTypeId`, `t2`.`StreamName`
FROM `tblassesmenttype` as `t1`
LEFT JOIN `tblstreamtype` as `t2` ON `t1`.`StreamTypeId` = `t2`.`StreamTypeId`
ERROR - 2019-06-10 08:57:40 --> Severity: Notice --> Undefined variable: programData C:\xampp\htdocs\mentor\admin\application\views\Assesment\AssesmentAdd.php 53
ERROR - 2019-06-10 08:57:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mentor\admin\application\views\Assesment\AssesmentAdd.php 53
ERROR - 2019-06-10 08:57:40 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 08:57:40 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 08:58:12 --> Severity: Notice --> Undefined variable: programData C:\xampp\htdocs\mentor\admin\application\views\Assesment\AssesmentAdd.php 53
ERROR - 2019-06-10 08:58:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mentor\admin\application\views\Assesment\AssesmentAdd.php 53
ERROR - 2019-06-10 08:58:12 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 08:58:12 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 09:00:22 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:00:22 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 09:00:54 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:00:54 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 09:01:37 --> Query error: Unknown column 't1.ProgramName' in 'field list' - Invalid query: SELECT `t1`.`AssesmentTypeId`, `t1`.`ProgramName`, `t1`.`ProgramDescription`, `t1`.`ProgramPrice`, `t1`.`ProgramImage`, `t1`.`IsActive`, `t2`.`StreamTypeId`, `t2`.`StreamName`
FROM `tblassesmenttype` as `t1`
LEFT JOIN `tblstreamtype` as `t2` ON `t1`.`StreamTypeId` = `t2`.`StreamTypeId`
ERROR - 2019-06-10 09:02:14 --> Query error: Unknown column 't1.ProgramName' in 'field list' - Invalid query: SELECT `t1`.`AssesmentTypeId`, `t1`.`ProgramName`, `t1`.`ProgramDescription`, `t1`.`ProgramPrice`, `t1`.`ProgramImage`, `t1`.`IsActive`, `t2`.`StreamTypeId`, `t2`.`StreamName`
FROM `tblassesmenttype` as `t1`
LEFT JOIN `tblstreamtype` as `t2` ON `t1`.`StreamTypeId` = `t2`.`StreamTypeId`
ERROR - 2019-06-10 09:02:15 --> Query error: Unknown column 't1.ProgramName' in 'field list' - Invalid query: SELECT `t1`.`AssesmentTypeId`, `t1`.`ProgramName`, `t1`.`ProgramDescription`, `t1`.`ProgramPrice`, `t1`.`ProgramImage`, `t1`.`IsActive`, `t2`.`StreamTypeId`, `t2`.`StreamName`
FROM `tblassesmenttype` as `t1`
LEFT JOIN `tblstreamtype` as `t2` ON `t1`.`StreamTypeId` = `t2`.`StreamTypeId`
ERROR - 2019-06-10 09:02:18 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:02:18 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 09:03:01 --> Query error: Unknown column 't1.ProgramName' in 'field list' - Invalid query: SELECT `t1`.`AssesmentTypeId`, `t1`.`ProgramName`, `t1`.`ProgramDescription`, `t1`.`ProgramPrice`, `t1`.`ProgramImage`, `t1`.`IsActive`, `t2`.`StreamTypeId`, `t2`.`StreamName`
FROM `tblassesmenttype` as `t1`
LEFT JOIN `tblstreamtype` as `t2` ON `t1`.`StreamTypeId` = `t2`.`StreamTypeId`
ERROR - 2019-06-10 09:08:24 --> Severity: Notice --> Undefined property: stdClass::$ProgramPrice C:\xampp\htdocs\mentor\admin\application\views\Assesment\AssesmentLIst.php 56
ERROR - 2019-06-10 09:08:24 --> Severity: Notice --> Undefined property: stdClass::$ProgramImage C:\xampp\htdocs\mentor\admin\application\views\Assesment\AssesmentLIst.php 57
ERROR - 2019-06-10 09:08:24 --> Severity: Notice --> Undefined property: stdClass::$IsActive C:\xampp\htdocs\mentor\admin\application\views\Assesment\AssesmentLIst.php 59
ERROR - 2019-06-10 09:08:24 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:08:25 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 09:08:25 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 09:08:25 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 09:11:43 --> Severity: Notice --> Undefined property: stdClass::$IsActive C:\xampp\htdocs\mentor\admin\application\views\Assesment\AssesmentLIst.php 57
ERROR - 2019-06-10 09:11:44 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:11:44 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 09:11:44 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 09:11:44 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 09:12:21 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:12:21 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 09:12:21 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 09:12:21 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 09:14:05 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:14:05 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 09:14:05 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 09:14:05 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 09:14:15 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:14:15 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 09:14:15 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 09:14:15 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 09:14:25 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:14:25 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 09:14:25 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 09:14:25 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 09:15:58 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:15:58 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 09:15:58 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 09:15:58 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 09:16:05 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:16:05 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 09:16:25 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:16:25 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 09:16:29 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:16:29 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 09:16:34 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:19:01 --> Severity: Notice --> Undefined index: ProgramName C:\xampp\htdocs\mentor\admin\application\controllers\Assesment.php 59
ERROR - 2019-06-10 09:19:01 --> Severity: Notice --> Undefined index: ProgramDescription C:\xampp\htdocs\mentor\admin\application\controllers\Assesment.php 60
ERROR - 2019-06-10 09:19:01 --> Severity: Notice --> Undefined index: ProgramPrice C:\xampp\htdocs\mentor\admin\application\controllers\Assesment.php 61
ERROR - 2019-06-10 09:19:01 --> Severity: Notice --> Undefined variable: ProgramId C:\xampp\htdocs\mentor\admin\application\views\Program\ProgramAdd.php 33
ERROR - 2019-06-10 09:19:01 --> Severity: Notice --> Undefined variable: ProgramId C:\xampp\htdocs\mentor\admin\application\views\Program\ProgramAdd.php 94
ERROR - 2019-06-10 09:19:01 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:19:02 --> Severity: Notice --> Undefined variable: ProgramId C:\xampp\htdocs\mentor\admin\application\views\Program\ProgramAdd.php 33
ERROR - 2019-06-10 09:19:02 --> Severity: Notice --> Undefined variable: ProgramId C:\xampp\htdocs\mentor\admin\application\views\Program\ProgramAdd.php 94
ERROR - 2019-06-10 09:19:23 --> Severity: Notice --> Undefined index: ProgramName C:\xampp\htdocs\mentor\admin\application\controllers\Assesment.php 59
ERROR - 2019-06-10 09:19:23 --> Severity: Notice --> Undefined index: ProgramDescription C:\xampp\htdocs\mentor\admin\application\controllers\Assesment.php 60
ERROR - 2019-06-10 09:19:23 --> Severity: Notice --> Undefined index: ProgramPrice C:\xampp\htdocs\mentor\admin\application\controllers\Assesment.php 61
ERROR - 2019-06-10 09:19:23 --> Severity: Notice --> Undefined variable: ProgramId C:\xampp\htdocs\mentor\admin\application\views\Program\ProgramAdd.php 33
ERROR - 2019-06-10 09:19:23 --> Severity: Notice --> Undefined variable: ProgramId C:\xampp\htdocs\mentor\admin\application\views\Program\ProgramAdd.php 94
ERROR - 2019-06-10 09:19:24 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:19:24 --> Severity: Notice --> Undefined variable: ProgramId C:\xampp\htdocs\mentor\admin\application\views\Program\ProgramAdd.php 33
ERROR - 2019-06-10 09:19:24 --> Severity: Notice --> Undefined variable: ProgramId C:\xampp\htdocs\mentor\admin\application\views\Program\ProgramAdd.php 94
ERROR - 2019-06-10 09:19:26 --> Severity: Notice --> Undefined index: ProgramName C:\xampp\htdocs\mentor\admin\application\controllers\Assesment.php 59
ERROR - 2019-06-10 09:19:26 --> Severity: Notice --> Undefined index: ProgramDescription C:\xampp\htdocs\mentor\admin\application\controllers\Assesment.php 60
ERROR - 2019-06-10 09:19:26 --> Severity: Notice --> Undefined index: ProgramPrice C:\xampp\htdocs\mentor\admin\application\controllers\Assesment.php 61
ERROR - 2019-06-10 09:19:26 --> Severity: Notice --> Undefined variable: ProgramId C:\xampp\htdocs\mentor\admin\application\views\Program\ProgramAdd.php 33
ERROR - 2019-06-10 09:19:26 --> Severity: Notice --> Undefined variable: ProgramId C:\xampp\htdocs\mentor\admin\application\views\Program\ProgramAdd.php 94
ERROR - 2019-06-10 09:19:26 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:19:26 --> Severity: Notice --> Undefined variable: ProgramId C:\xampp\htdocs\mentor\admin\application\views\Program\ProgramAdd.php 33
ERROR - 2019-06-10 09:19:26 --> Severity: Notice --> Undefined variable: ProgramId C:\xampp\htdocs\mentor\admin\application\views\Program\ProgramAdd.php 94
ERROR - 2019-06-10 09:21:14 --> Severity: Notice --> Undefined variable: ProgramName C:\xampp\htdocs\mentor\admin\application\views\Program\ProgramAdd.php 49
ERROR - 2019-06-10 09:21:14 --> Severity: Notice --> Undefined variable: ProgramDescription C:\xampp\htdocs\mentor\admin\application\views\Program\ProgramAdd.php 54
ERROR - 2019-06-10 09:21:14 --> Severity: Notice --> Undefined variable: ProgramPrice C:\xampp\htdocs\mentor\admin\application\views\Program\ProgramAdd.php 60
ERROR - 2019-06-10 09:21:14 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:21:14 --> Severity: Notice --> Undefined variable: ProgramName C:\xampp\htdocs\mentor\admin\application\views\Program\ProgramAdd.php 49
ERROR - 2019-06-10 09:21:14 --> Severity: Notice --> Undefined variable: ProgramDescription C:\xampp\htdocs\mentor\admin\application\views\Program\ProgramAdd.php 54
ERROR - 2019-06-10 09:21:14 --> Severity: Notice --> Undefined variable: ProgramPrice C:\xampp\htdocs\mentor\admin\application\views\Program\ProgramAdd.php 60
ERROR - 2019-06-10 09:22:14 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:22:51 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:23:29 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:23:47 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:24:12 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:25:40 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:27:55 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:27:57 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:27:58 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 09:27:58 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 09:27:58 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 09:29:24 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:29:24 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 09:29:25 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 09:29:29 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:29:31 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:29:31 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 09:31:44 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:31:45 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 09:31:55 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:31:55 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 09:31:57 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:32:01 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:32:01 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 09:34:56 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:34:56 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 09:34:56 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 09:34:56 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 09:34:57 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:35:00 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:35:00 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 09:35:02 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:35:03 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:35:05 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:35:07 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:35:10 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:35:11 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:35:14 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:35:18 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:35:20 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:35:21 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 09:35:30 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:35:35 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:35:35 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 09:37:34 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:37:34 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 09:37:36 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:37:36 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 09:37:36 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 09:37:36 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 09:37:36 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-10 09:37:37 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-10 09:46:55 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:46:57 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 09:46:57 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 09:46:57 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 09:46:58 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:48:31 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:48:32 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 09:48:36 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:48:39 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:48:48 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:48:50 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:49:22 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:49:23 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 09:49:25 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:49:29 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:49:29 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 09:50:01 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:50:01 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 09:50:03 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:50:06 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:50:06 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 09:50:52 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:50:52 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 09:50:55 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:50:56 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 09:50:56 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 09:50:57 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 09:50:57 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-10 09:50:57 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-10 09:51:00 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:51:00 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:51:01 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:51:04 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:51:04 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 09:51:58 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:51:58 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 09:51:59 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:52:02 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:52:02 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 09:52:04 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:52:11 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:52:11 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 09:52:52 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:54:08 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:54:32 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:55:16 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 09:56:23 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 10:03:37 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 10:08:06 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 10:49:50 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 10:49:53 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 10:49:54 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 10:49:55 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 10:51:51 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 10:52:22 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 10:53:12 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 10:55:51 --> 404 Page Not Found: Standard/index
ERROR - 2019-06-10 10:55:58 --> 404 Page Not Found: Standard/index
ERROR - 2019-06-10 10:56:13 --> 404 Page Not Found: Stndard/index
ERROR - 2019-06-10 10:56:25 --> 404 Page Not Found: Standard/updatedata
ERROR - 2019-06-10 10:56:28 --> 404 Page Not Found: Standard/index
ERROR - 2019-06-10 10:56:38 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 10:56:39 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 10:56:39 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 10:56:39 --> 404 Page Not Found: Standard/app-assets
ERROR - 2019-06-10 10:56:42 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 10:56:42 --> 404 Page Not Found: Standard/app-assets
ERROR - 2019-06-10 10:56:46 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 10:56:46 --> 404 Page Not Found: Standard/app-assets
ERROR - 2019-06-10 10:57:43 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 10:57:44 --> 404 Page Not Found: Standard/app-assets
ERROR - 2019-06-10 10:57:44 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-10 10:57:44 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-10 10:57:57 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 10:57:58 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-10 10:57:58 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-10 10:57:58 --> 404 Page Not Found: Standard/app-assets
ERROR - 2019-06-10 10:58:16 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 10:58:17 --> 404 Page Not Found: Standard/app-assets
ERROR - 2019-06-10 10:58:17 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-10 10:58:17 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-10 10:58:44 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 10:58:44 --> 404 Page Not Found: Standard/app-assets
ERROR - 2019-06-10 10:58:44 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-10 10:58:44 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-10 10:58:53 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 10:58:53 --> 404 Page Not Found: Standard/app-assets
ERROR - 2019-06-10 10:58:53 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-10 10:58:53 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-10 10:59:03 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 10:59:03 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 10:59:03 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 10:59:06 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 10:59:10 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 10:59:11 --> 404 Page Not Found: Standard/app-assets
ERROR - 2019-06-10 10:59:13 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:00:31 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:00:31 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-10 11:00:31 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-10 11:01:06 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:01:06 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-10 11:01:06 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-10 11:01:53 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:02:04 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:02:09 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:02:09 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 11:02:09 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 11:02:09 --> 404 Page Not Found: Standard/app-assets
ERROR - 2019-06-10 11:02:10 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:02:36 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:02:37 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-10 11:02:37 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-10 11:04:41 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:04:41 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 11:04:42 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:04:42 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 11:05:38 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:05:39 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 11:06:45 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:06:45 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 11:07:56 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:07:57 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 11:09:07 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:09:07 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 11:10:26 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:10:26 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 11:10:59 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:10:59 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 11:11:12 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:11:12 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 11:11:29 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:11:29 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 11:11:29 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 11:11:29 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 11:12:43 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:12:43 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 11:12:43 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 11:12:43 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 11:13:24 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:13:27 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:13:27 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 11:13:27 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 11:13:28 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:15:25 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:15:27 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:15:27 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-10 11:15:30 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:15:30 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-10 11:15:34 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:16:59 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:17:01 --> Severity: Notice --> Undefined variable: StreamTypeId C:\xampp\htdocs\mentor\admin\application\views\Userrole\UserroleAdd.php 17
ERROR - 2019-06-10 11:17:01 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:17:01 --> 404 Page Not Found: Userrole/app-assets
ERROR - 2019-06-10 11:17:11 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:17:11 --> 404 Page Not Found: Userrole/app-assets
ERROR - 2019-06-10 11:17:15 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:17:16 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:17:31 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:17:45 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:17:49 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:17:49 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-10 11:17:56 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:30:18 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:30:18 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 11:30:18 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 11:30:21 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:30:26 --> Severity: Notice --> Undefined variable: StandardId C:\xampp\htdocs\mentor\admin\application\views\Rate\RateAdd.php 68
ERROR - 2019-06-10 11:30:26 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:30:26 --> 404 Page Not Found: Rate/app-assets
ERROR - 2019-06-10 11:30:31 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:30:31 --> 404 Page Not Found: Standard/app-assets
ERROR - 2019-06-10 11:30:36 --> 404 Page Not Found: Rate/Ratelist
ERROR - 2019-06-10 11:30:59 --> 404 Page Not Found: Rate/Ratelist
ERROR - 2019-06-10 11:31:07 --> 404 Page Not Found: Rate/RateList
ERROR - 2019-06-10 11:31:46 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:31:46 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 11:31:46 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 11:31:46 --> 404 Page Not Found: Rate/app-assets
ERROR - 2019-06-10 11:33:39 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:34:04 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:34:06 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:34:06 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 11:34:06 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 11:34:10 --> Severity: Notice --> Undefined variable: StandardId C:\xampp\htdocs\mentor\admin\application\views\Rate\RateAdd.php 68
ERROR - 2019-06-10 11:34:10 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:34:10 --> 404 Page Not Found: Rate/app-assets
ERROR - 2019-06-10 11:34:11 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:34:18 --> Severity: Notice --> Undefined variable: StandardId C:\xampp\htdocs\mentor\admin\application\views\Rate\RateAdd.php 68
ERROR - 2019-06-10 11:34:18 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:34:18 --> 404 Page Not Found: Rate/app-assets
ERROR - 2019-06-10 11:34:22 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:34:22 --> 404 Page Not Found: Standard/app-assets
ERROR - 2019-06-10 11:34:28 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:34:28 --> 404 Page Not Found: Rate/app-assets
ERROR - 2019-06-10 11:34:32 --> Severity: Notice --> Undefined variable: StandardId C:\xampp\htdocs\mentor\admin\application\views\Rate\RateAdd.php 68
ERROR - 2019-06-10 11:34:32 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:34:32 --> Severity: Notice --> Undefined variable: StandardId C:\xampp\htdocs\mentor\admin\application\views\Rate\RateAdd.php 68
ERROR - 2019-06-10 11:34:36 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:34:43 --> Severity: Notice --> Undefined variable: StandardId C:\xampp\htdocs\mentor\admin\application\views\Rate\RateAdd.php 68
ERROR - 2019-06-10 11:34:43 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:34:43 --> Severity: Notice --> Undefined variable: StandardId C:\xampp\htdocs\mentor\admin\application\views\Rate\RateAdd.php 68
ERROR - 2019-06-10 11:35:14 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:35:24 --> Severity: Notice --> Undefined property: stdClass::$StandardId C:\xampp\htdocs\mentor\admin\application\views\Rate\RateList.php 64
ERROR - 2019-06-10 11:35:24 --> Severity: Notice --> Undefined property: stdClass::$StandardId C:\xampp\htdocs\mentor\admin\application\views\Rate\RateList.php 65
ERROR - 2019-06-10 11:35:24 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:35:24 --> 404 Page Not Found: Rate/app-assets
ERROR - 2019-06-10 11:35:40 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:35:40 --> 404 Page Not Found: Rate/app-assets
ERROR - 2019-06-10 11:36:01 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:36:01 --> 404 Page Not Found: Rate/app-assets
ERROR - 2019-06-10 11:36:08 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:36:17 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:36:17 --> 404 Page Not Found: Rate/app-assets
ERROR - 2019-06-10 11:36:19 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:36:58 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:37:02 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:37:16 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:37:16 --> 404 Page Not Found: Rate/app-assets
ERROR - 2019-06-10 11:37:16 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:37:19 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:37:20 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:37:26 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:37:26 --> 404 Page Not Found: Rate/app-assets
ERROR - 2019-06-10 11:37:28 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:38:04 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:38:08 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:38:08 --> 404 Page Not Found: Standard/app-assets
ERROR - 2019-06-10 11:38:12 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:38:14 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:38:14 --> 404 Page Not Found: Standard/app-assets
ERROR - 2019-06-10 11:38:30 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:38:30 --> 404 Page Not Found: Rate/app-assets
ERROR - 2019-06-10 11:38:31 --> 404 Page Not Found: Standard/Editrate
ERROR - 2019-06-10 11:38:39 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:38:39 --> 404 Page Not Found: Rate/app-assets
ERROR - 2019-06-10 11:38:43 --> 404 Page Not Found: Standard/Editrate
ERROR - 2019-06-10 11:39:52 --> 404 Page Not Found: Standard/Editrate
ERROR - 2019-06-10 11:39:55 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:39:55 --> 404 Page Not Found: Rate/app-assets
ERROR - 2019-06-10 11:39:57 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:40:24 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:40:27 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:40:27 --> 404 Page Not Found: Rate/app-assets
ERROR - 2019-06-10 11:46:07 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:46:07 --> 404 Page Not Found: Rate/app-assets
ERROR - 2019-06-10 11:46:26 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:46:26 --> 404 Page Not Found: Rate/app-assets
ERROR - 2019-06-10 11:47:46 --> Severity: Notice --> Undefined variable: rateData C:\xampp\htdocs\mentor\admin\application\views\Rate\RateList.php 44
ERROR - 2019-06-10 11:47:46 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:47:46 --> 404 Page Not Found: Rate/app-assets
ERROR - 2019-06-10 11:48:05 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:48:05 --> 404 Page Not Found: Rate/app-assets
ERROR - 2019-06-10 11:48:33 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:48:33 --> 404 Page Not Found: Rate/app-assets
ERROR - 2019-06-10 11:48:37 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:48:39 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:48:41 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:48:41 --> 404 Page Not Found: Rate/app-assets
ERROR - 2019-06-10 11:49:00 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:49:00 --> 404 Page Not Found: Rate/app-assets
ERROR - 2019-06-10 11:49:02 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:49:06 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:49:06 --> 404 Page Not Found: Rate/app-assets
ERROR - 2019-06-10 11:49:11 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:49:13 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:49:14 --> 404 Page Not Found: Rate/app-assets
ERROR - 2019-06-10 11:59:22 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 11:59:22 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 11:59:22 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 11:59:22 --> 404 Page Not Found: Rate/app-assets
ERROR - 2019-06-10 11:59:30 --> 404 Page Not Found: QImage/QImageadd
ERROR - 2019-06-10 11:59:46 --> 404 Page Not Found: QImage/QImageadd
ERROR - 2019-06-10 12:11:35 --> 404 Page Not Found: QImage/QImageadd
ERROR - 2019-06-10 12:13:22 --> Severity: Notice --> Undefined variable: QuestionImageId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 17
ERROR - 2019-06-10 12:13:22 --> Severity: Notice --> Undefined property: stdClass::$AssesmentTypeId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 49
ERROR - 2019-06-10 12:13:22 --> Severity: Notice --> Undefined property: stdClass::$AssesmentTypeId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 49
ERROR - 2019-06-10 12:13:22 --> Severity: Notice --> Undefined property: stdClass::$AssesmentName C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 49
ERROR - 2019-06-10 12:13:22 --> Severity: Notice --> Undefined variable: QuestionImageId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 90
ERROR - 2019-06-10 12:13:22 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 12:13:22 --> 404 Page Not Found: QImage/app-assets
ERROR - 2019-06-10 12:13:45 --> Severity: Notice --> Undefined variable: QuestionImageId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 17
ERROR - 2019-06-10 12:13:45 --> Severity: Notice --> Undefined property: stdClass::$AssesmentTypeId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 49
ERROR - 2019-06-10 12:13:45 --> Severity: Notice --> Undefined property: stdClass::$AssesmentTypeId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 49
ERROR - 2019-06-10 12:13:45 --> Severity: Notice --> Undefined property: stdClass::$AssesmentName C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 49
ERROR - 2019-06-10 12:13:45 --> Severity: Notice --> Undefined variable: QuestionImageId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 90
ERROR - 2019-06-10 12:13:45 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 12:13:45 --> 404 Page Not Found: QImage/app-assets
ERROR - 2019-06-10 12:15:19 --> Severity: Notice --> Undefined variable: QuestionImageId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 17
ERROR - 2019-06-10 12:15:19 --> Severity: Notice --> Undefined property: stdClass::$AssesmentTypeId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 49
ERROR - 2019-06-10 12:15:19 --> Severity: Notice --> Undefined property: stdClass::$AssesmentTypeId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 49
ERROR - 2019-06-10 12:15:19 --> Severity: Notice --> Undefined property: stdClass::$AssesmentName C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 49
ERROR - 2019-06-10 12:15:19 --> Severity: Notice --> Undefined variable: QuestionImageId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 90
ERROR - 2019-06-10 12:15:19 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 12:15:20 --> 404 Page Not Found: QImage/app-assets
ERROR - 2019-06-10 12:16:15 --> Severity: Notice --> Undefined variable: QuestionImageId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 17
ERROR - 2019-06-10 12:16:15 --> Severity: Notice --> Undefined property: stdClass::$AssesmentTypeId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 49
ERROR - 2019-06-10 12:16:15 --> Severity: Notice --> Undefined property: stdClass::$AssesmentTypeId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 49
ERROR - 2019-06-10 12:16:15 --> Severity: Notice --> Undefined property: stdClass::$AssesmentName C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 49
ERROR - 2019-06-10 12:16:15 --> Severity: Notice --> Undefined variable: QuestionImageId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 90
ERROR - 2019-06-10 12:16:15 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 12:16:15 --> 404 Page Not Found: QImage/app-assets
ERROR - 2019-06-10 12:16:18 --> Query error: Unknown column 't3.StreamTypeId' in 'field list' - Invalid query: SELECT `t3`.`QuestionImageId`, `t3`.`StreamTypeId`, `t3`.`ProgramId`, `t3`.`AssesmentName`, `t3`.`IsActive`, `t1`.`ProgramName`, `t2`.`StreamName`
FROM `tblquestionpicture` as `t3`
LEFT JOIN `tblprogramtype` as `t1` ON `t3`.`ProgramId` = `t1`.`ProgramId`
LEFT JOIN `tblstreamtype` as `t2` ON `t3`.`StreamTypeId` = `t2`.`StreamTypeId`
ERROR - 2019-06-10 12:16:40 --> Query error: Unknown column 't3.StreamTypeId' in 'field list' - Invalid query: SELECT `t3`.`QuestionImageId`, `t3`.`StreamTypeId`, `t3`.`ProgramId`, `t3`.`AssesmentName`, `t3`.`IsActive`, `t1`.`ProgramName`, `t2`.`StreamName`
FROM `tblquestionpicture` as `t3`
LEFT JOIN `tblprogramtype` as `t1` ON `t3`.`ProgramId` = `t1`.`ProgramId`
LEFT JOIN `tblstreamtype` as `t2` ON `t3`.`StreamTypeId` = `t2`.`StreamTypeId`
ERROR - 2019-06-10 12:16:42 --> Query error: Unknown column 't3.StreamTypeId' in 'field list' - Invalid query: SELECT `t3`.`QuestionImageId`, `t3`.`StreamTypeId`, `t3`.`ProgramId`, `t3`.`AssesmentName`, `t3`.`IsActive`, `t1`.`ProgramName`, `t2`.`StreamName`
FROM `tblquestionpicture` as `t3`
LEFT JOIN `tblprogramtype` as `t1` ON `t3`.`ProgramId` = `t1`.`ProgramId`
LEFT JOIN `tblstreamtype` as `t2` ON `t3`.`StreamTypeId` = `t2`.`StreamTypeId`
ERROR - 2019-06-10 12:16:43 --> Severity: Notice --> Undefined variable: QuestionImageId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 17
ERROR - 2019-06-10 12:16:43 --> Severity: Notice --> Undefined property: stdClass::$AssesmentTypeId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 49
ERROR - 2019-06-10 12:16:43 --> Severity: Notice --> Undefined property: stdClass::$AssesmentTypeId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 49
ERROR - 2019-06-10 12:16:43 --> Severity: Notice --> Undefined property: stdClass::$AssesmentName C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 49
ERROR - 2019-06-10 12:16:43 --> Severity: Notice --> Undefined variable: QuestionImageId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 90
ERROR - 2019-06-10 12:16:48 --> Query error: Unknown column 't3.StreamTypeId' in 'field list' - Invalid query: SELECT `t3`.`QuestionImageId`, `t3`.`StreamTypeId`, `t3`.`ProgramId`, `t3`.`AssesmentName`, `t3`.`IsActive`, `t1`.`ProgramName`, `t2`.`StreamName`
FROM `tblquestionpicture` as `t3`
LEFT JOIN `tblprogramtype` as `t1` ON `t3`.`ProgramId` = `t1`.`ProgramId`
LEFT JOIN `tblstreamtype` as `t2` ON `t3`.`StreamTypeId` = `t2`.`StreamTypeId`
ERROR - 2019-06-10 12:16:51 --> Severity: Notice --> Undefined variable: QuestionImageId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 17
ERROR - 2019-06-10 12:16:51 --> Severity: Notice --> Undefined property: stdClass::$AssesmentTypeId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 49
ERROR - 2019-06-10 12:16:51 --> Severity: Notice --> Undefined property: stdClass::$AssesmentTypeId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 49
ERROR - 2019-06-10 12:16:51 --> Severity: Notice --> Undefined property: stdClass::$AssesmentName C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 49
ERROR - 2019-06-10 12:16:51 --> Severity: Notice --> Undefined variable: QuestionImageId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 90
ERROR - 2019-06-10 12:18:02 --> Severity: Notice --> Undefined variable: QuestionImageId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 17
ERROR - 2019-06-10 12:18:02 --> Severity: Notice --> Undefined property: stdClass::$AssesmentTypeId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 49
ERROR - 2019-06-10 12:18:02 --> Severity: Notice --> Undefined property: stdClass::$AssesmentTypeId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 49
ERROR - 2019-06-10 12:18:02 --> Severity: Notice --> Undefined property: stdClass::$AssesmentName C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 49
ERROR - 2019-06-10 12:18:02 --> Severity: Notice --> Undefined variable: QuestionImageId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 90
ERROR - 2019-06-10 12:18:02 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 12:18:02 --> 404 Page Not Found: QImage/app-assets
ERROR - 2019-06-10 12:18:06 --> Query error: Unknown column 't3.StreamTypeId' in 'field list' - Invalid query: SELECT `t3`.`QuestionImageId`, `t3`.`StreamTypeId`, `t3`.`ProgramId`, `t3`.`AssesmentName`, `t3`.`IsActive`, `t1`.`ProgramName`, `t2`.`StreamName`
FROM `tblquestionpicture` as `t3`
LEFT JOIN `tblprogramtype` as `t1` ON `t3`.`ProgramId` = `t1`.`ProgramId`
LEFT JOIN `tblstreamtype` as `t2` ON `t3`.`StreamTypeId` = `t2`.`StreamTypeId`
ERROR - 2019-06-10 12:18:08 --> Severity: Notice --> Undefined variable: QuestionImageId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 17
ERROR - 2019-06-10 12:18:08 --> Severity: Notice --> Undefined property: stdClass::$AssesmentTypeId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 49
ERROR - 2019-06-10 12:18:08 --> Severity: Notice --> Undefined property: stdClass::$AssesmentTypeId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 49
ERROR - 2019-06-10 12:18:08 --> Severity: Notice --> Undefined property: stdClass::$AssesmentName C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 49
ERROR - 2019-06-10 12:18:08 --> Severity: Notice --> Undefined variable: QuestionImageId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 90
ERROR - 2019-06-10 12:19:52 --> Severity: Notice --> Undefined variable: QuestionImageId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 17
ERROR - 2019-06-10 12:19:52 --> Severity: Notice --> Undefined property: stdClass::$AssesmentTypeId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 50
ERROR - 2019-06-10 12:19:52 --> Severity: Notice --> Undefined property: stdClass::$AssesmentName C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 50
ERROR - 2019-06-10 12:19:52 --> Severity: Notice --> Undefined variable: QuestionImageId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 91
ERROR - 2019-06-10 12:19:52 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 12:19:52 --> 404 Page Not Found: QImage/app-assets
ERROR - 2019-06-10 12:20:44 --> Severity: Notice --> Undefined variable: QuestionImageId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 17
ERROR - 2019-06-10 12:20:44 --> Severity: Notice --> Undefined property: stdClass::$AssesmentTypeId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 50
ERROR - 2019-06-10 12:20:44 --> Severity: Notice --> Undefined property: stdClass::$AssesmentName C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 50
ERROR - 2019-06-10 12:20:44 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 12:20:44 --> 404 Page Not Found: QImage/app-assets
ERROR - 2019-06-10 12:27:35 --> 404 Page Not Found: QImage/app-assets
ERROR - 2019-06-10 12:27:37 --> 404 Page Not Found: QImage/app-assets
ERROR - 2019-06-10 12:31:58 --> Severity: Notice --> Undefined variable: QuestionImageId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 17
ERROR - 2019-06-10 12:31:58 --> Severity: Notice --> Undefined property: stdClass::$AssesmentTypeId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 50
ERROR - 2019-06-10 12:31:58 --> Severity: Notice --> Undefined property: stdClass::$AssesmentName C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 50
ERROR - 2019-06-10 12:31:58 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 12:31:58 --> 404 Page Not Found: QImage/app-assets
ERROR - 2019-06-10 12:33:26 --> Severity: Notice --> Undefined variable: QuestionImageId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 17
ERROR - 2019-06-10 12:33:26 --> Severity: Notice --> Undefined property: stdClass::$AssesmentTypeId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 50
ERROR - 2019-06-10 12:33:26 --> Severity: Notice --> Undefined property: stdClass::$AssesmentName C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 50
ERROR - 2019-06-10 12:33:26 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 12:33:26 --> 404 Page Not Found: QImage/app-assets
ERROR - 2019-06-10 12:33:54 --> Severity: Notice --> Undefined variable: QuestionImageId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 17
ERROR - 2019-06-10 12:33:54 --> Severity: Notice --> Undefined property: stdClass::$AssesmentTypeId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 50
ERROR - 2019-06-10 12:33:54 --> Severity: Notice --> Undefined property: stdClass::$AssesmentName C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 50
ERROR - 2019-06-10 12:33:54 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 12:33:54 --> 404 Page Not Found: QImage/app-assets
ERROR - 2019-06-10 12:43:59 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 12:44:39 --> Severity: Notice --> Undefined variable: QuestionImageId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 17
ERROR - 2019-06-10 12:44:39 --> Severity: Notice --> Undefined property: stdClass::$AssesmentTypeId C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 50
ERROR - 2019-06-10 12:44:39 --> Severity: Notice --> Undefined property: stdClass::$AssesmentName C:\xampp\htdocs\mentor\admin\application\views\QImage\QImageAdd.php 50
ERROR - 2019-06-10 12:44:55 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 12:44:55 --> 404 Page Not Found: Standard/app-assets
ERROR - 2019-06-10 12:54:30 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 12:54:30 --> 404 Page Not Found: Standard/app-assets
ERROR - 2019-06-10 13:04:41 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 13:04:41 --> 404 Page Not Found: Standard/app-assets
ERROR - 2019-06-10 13:07:34 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 13:07:34 --> 404 Page Not Found: Standard/app-assets
ERROR - 2019-06-10 13:07:37 --> 404 Page Not Found: Question/Questionlist
ERROR - 2019-06-10 13:15:06 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 13:15:06 --> 404 Page Not Found: Standard/app-assets
ERROR - 2019-06-10 13:15:06 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-10 13:15:06 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-10 13:29:21 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 13:29:21 --> 404 Page Not Found: Standard/app-assets
ERROR - 2019-06-10 13:29:24 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 13:29:24 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 13:29:24 --> 404 Page Not Found: Default/images
ERROR - 2019-06-10 13:29:24 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-10 13:29:51 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 13:29:51 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-10 13:30:46 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 13:30:46 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-10 13:30:49 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 13:30:50 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-10 14:01:58 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 14:01:58 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-10 14:03:08 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 14:03:08 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-10 14:03:12 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 14:03:30 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 14:03:34 --> 404 Page Not Found: Question/Questionadd
ERROR - 2019-06-10 14:03:39 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 14:03:39 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-10 14:03:42 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 14:03:42 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-10 14:04:36 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 14:04:36 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-10 14:05:13 --> Severity: Notice --> Undefined variable: ProgramId C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 17
ERROR - 2019-06-10 14:05:13 --> Severity: Notice --> Undefined variable: ProgramId C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 40
ERROR - 2019-06-10 14:05:13 --> Severity: Notice --> Undefined variable: streamData C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 44
ERROR - 2019-06-10 14:05:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 44
ERROR - 2019-06-10 14:05:13 --> Severity: Notice --> Undefined variable: ProgramName C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 56
ERROR - 2019-06-10 14:05:13 --> Severity: Notice --> Undefined variable: ProgramDescription C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 61
ERROR - 2019-06-10 14:05:13 --> Severity: Notice --> Undefined variable: ProgramPrice C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 67
ERROR - 2019-06-10 14:05:13 --> Severity: Notice --> Undefined variable: IsActive C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 83
ERROR - 2019-06-10 14:05:13 --> Severity: Notice --> Undefined variable: IsActive C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 90
ERROR - 2019-06-10 14:05:13 --> Severity: Notice --> Undefined variable: ProgramId C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 100
ERROR - 2019-06-10 14:05:13 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 14:05:13 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-10 14:08:38 --> Severity: Notice --> Undefined variable: QuestionId C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 17
ERROR - 2019-06-10 14:08:38 --> Severity: Notice --> Undefined variable: QuestionName C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 56
ERROR - 2019-06-10 14:08:38 --> Severity: Notice --> Undefined variable: IsActive C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 70
ERROR - 2019-06-10 14:08:38 --> Severity: Notice --> Undefined variable: IsActive C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 77
ERROR - 2019-06-10 14:08:38 --> Severity: Notice --> Undefined variable: QuestionId C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 87
ERROR - 2019-06-10 14:08:38 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 14:08:38 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-10 14:09:05 --> Severity: Notice --> Undefined variable: QuestionId C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 17
ERROR - 2019-06-10 14:09:05 --> Severity: Notice --> Undefined variable: QuestionId C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 87
ERROR - 2019-06-10 14:09:05 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 14:09:05 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-10 14:11:59 --> Severity: Notice --> Undefined variable: QuestionId C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 17
ERROR - 2019-06-10 14:11:59 --> Severity: Notice --> Undefined variable: QuestionId C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 40
ERROR - 2019-06-10 14:11:59 --> Severity: Notice --> Undefined variable: AssesmentTypeId C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 47
ERROR - 2019-06-10 14:11:59 --> Severity: Notice --> Undefined variable: AssesmentTypeId C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 47
ERROR - 2019-06-10 14:11:59 --> Severity: Notice --> Undefined variable: AssesmentTypeId C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 47
ERROR - 2019-06-10 14:11:59 --> Severity: Notice --> Undefined variable: QuestionId C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 87
ERROR - 2019-06-10 14:11:59 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 14:11:59 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-10 14:12:57 --> Severity: Notice --> Undefined variable: QuestionId C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 17
ERROR - 2019-06-10 14:12:57 --> Severity: Notice --> Undefined variable: QuestionId C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 40
ERROR - 2019-06-10 14:12:57 --> Severity: Notice --> Undefined variable: AssesmentTypeId C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 47
ERROR - 2019-06-10 14:12:57 --> Severity: Notice --> Undefined variable: AssesmentTypeId C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 47
ERROR - 2019-06-10 14:12:57 --> Severity: Notice --> Undefined variable: AssesmentTypeId C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 47
ERROR - 2019-06-10 14:12:57 --> Severity: Notice --> Undefined variable: QuestionId C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 87
ERROR - 2019-06-10 14:12:57 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 14:12:58 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-10 14:14:54 --> Severity: Notice --> Undefined variable: QuestionId C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 17
ERROR - 2019-06-10 14:14:54 --> Severity: Notice --> Undefined variable: QuestionId C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 40
ERROR - 2019-06-10 14:14:54 --> Severity: Notice --> Undefined variable: AssesmentTypeId C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 47
ERROR - 2019-06-10 14:14:54 --> Severity: Notice --> Undefined variable: AssesmentTypeId C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 47
ERROR - 2019-06-10 14:14:54 --> Severity: Notice --> Undefined variable: AssesmentTypeId C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 47
ERROR - 2019-06-10 14:14:54 --> Severity: Notice --> Undefined variable: QuestionId C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 87
ERROR - 2019-06-10 14:14:54 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 14:14:54 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-10 14:18:37 --> Severity: Notice --> Undefined variable: QuestionId C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 17
ERROR - 2019-06-10 14:18:37 --> Severity: Notice --> Undefined variable: QuestionId C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 40
ERROR - 2019-06-10 14:18:37 --> Severity: Notice --> Undefined variable: AssesmentTypeId C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 47
ERROR - 2019-06-10 14:18:37 --> Severity: Notice --> Undefined property: stdClass::$StreamName C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 47
ERROR - 2019-06-10 14:18:37 --> Severity: Notice --> Undefined variable: AssesmentTypeId C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 47
ERROR - 2019-06-10 14:18:37 --> Severity: Notice --> Undefined property: stdClass::$StreamName C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 47
ERROR - 2019-06-10 14:18:37 --> Severity: Notice --> Undefined variable: AssesmentTypeId C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 47
ERROR - 2019-06-10 14:18:37 --> Severity: Notice --> Undefined property: stdClass::$StreamName C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 47
ERROR - 2019-06-10 14:18:37 --> Severity: Notice --> Undefined variable: QuestionId C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 87
ERROR - 2019-06-10 14:18:37 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 14:18:37 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-10 14:19:06 --> Severity: Notice --> Undefined variable: QuestionId C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 17
ERROR - 2019-06-10 14:19:06 --> Severity: Notice --> Undefined variable: QuestionId C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 40
ERROR - 2019-06-10 14:19:06 --> Severity: Notice --> Undefined property: stdClass::$StreamName C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 47
ERROR - 2019-06-10 14:19:06 --> Severity: Notice --> Undefined property: stdClass::$StreamName C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 47
ERROR - 2019-06-10 14:19:06 --> Severity: Notice --> Undefined property: stdClass::$StreamName C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 47
ERROR - 2019-06-10 14:19:06 --> Severity: Notice --> Undefined variable: QuestionId C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 87
ERROR - 2019-06-10 14:19:06 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 14:19:06 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-10 14:19:34 --> Severity: Notice --> Undefined variable: QuestionId C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 18
ERROR - 2019-06-10 14:19:34 --> Severity: Notice --> Undefined variable: QuestionId C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 41
ERROR - 2019-06-10 14:19:34 --> Severity: Notice --> Undefined property: stdClass::$StreamName C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 48
ERROR - 2019-06-10 14:19:34 --> Severity: Notice --> Undefined property: stdClass::$StreamName C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 48
ERROR - 2019-06-10 14:19:34 --> Severity: Notice --> Undefined property: stdClass::$StreamName C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 48
ERROR - 2019-06-10 14:19:34 --> Severity: Notice --> Undefined variable: QuestionId C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 88
ERROR - 2019-06-10 14:19:34 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-10 14:19:34 --> 404 Page Not Found: Question/app-assets
