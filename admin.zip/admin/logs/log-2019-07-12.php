<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-12 06:42:37 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 06:42:37 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 06:47:15 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 06:47:15 --> 404 Page Not Found: Home/app-assets
ERROR - 2019-07-12 06:47:40 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 06:47:40 --> 404 Page Not Found: Admin/app-assets
ERROR - 2019-07-12 06:48:18 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 06:48:18 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:01:48 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 07:01:48 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 07:01:50 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:01:50 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:02:37 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:02:38 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:02:38 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 07:02:38 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 07:03:13 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:03:13 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:21:48 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:21:48 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:24:29 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:24:29 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:25:49 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:25:49 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:25:49 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 07:25:49 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 07:27:01 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:27:01 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:27:01 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 07:27:01 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 07:27:08 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:27:08 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:27:08 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 07:27:08 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 07:27:21 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:27:28 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:27:28 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 07:27:29 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 07:27:29 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:27:29 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:27:29 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 07:27:29 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 07:28:50 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:28:50 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:28:50 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 07:28:50 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 07:28:52 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:28:52 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:29:41 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:29:42 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:29:44 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:29:44 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:29:48 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:29:48 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:32:15 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:32:15 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:32:33 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:32:33 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:32:33 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 07:32:33 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 07:32:35 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:32:35 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:32:55 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:32:55 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:32:59 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:32:59 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:33:13 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:33:13 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:33:23 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:33:23 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:33:34 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:33:35 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:33:35 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 07:33:35 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 07:34:08 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:34:09 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:34:09 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 07:34:09 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 07:34:53 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:34:53 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:34:53 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 07:34:53 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 07:36:02 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:36:03 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:36:03 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 07:36:03 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 07:36:38 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:36:38 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:37:16 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:37:17 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:37:21 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:37:21 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:37:25 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:37:25 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:37:27 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:37:27 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:37:51 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:37:52 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:37:52 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 07:37:52 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 07:37:53 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:37:53 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:38:11 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:38:11 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:38:11 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 07:38:11 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 07:38:13 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:38:14 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:38:48 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:38:48 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:42:06 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:42:07 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:42:07 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 07:42:07 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 07:42:14 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:42:14 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:42:14 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 07:42:14 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 07:42:41 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:42:41 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:42:41 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 07:42:41 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 07:43:03 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:43:04 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:43:04 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 07:43:04 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 07:43:20 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:43:20 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:43:20 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 07:43:20 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 07:48:04 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:48:04 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:48:04 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 07:48:05 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 07:49:40 --> Severity: Notice --> Undefined variable: ProjectDescription C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 51
ERROR - 2019-07-12 07:49:40 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:49:41 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:49:41 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 07:49:41 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 07:49:43 --> Severity: Notice --> Undefined variable: ProjectDescription C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 51
ERROR - 2019-07-12 07:49:43 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:49:43 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:50:20 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:50:20 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:50:20 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 07:50:20 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 07:50:28 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:50:28 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:50:40 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:50:41 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:50:41 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 07:50:41 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 07:52:31 --> Severity: Notice --> Undefined variable: Projectldesc C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 51
ERROR - 2019-07-12 07:52:31 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:52:32 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:52:32 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 07:52:32 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 07:52:53 --> Severity: Notice --> Undefined variable: Projectldesc C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 51
ERROR - 2019-07-12 07:52:53 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 07:52:53 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 07:52:53 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 07:52:53 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 08:05:17 --> Severity: Notice --> Undefined variable: Projectldesc C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 51
ERROR - 2019-07-12 08:05:17 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 08:05:17 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 08:05:17 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 08:05:17 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 08:05:26 --> Severity: Notice --> Undefined variable: Projectldesc C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 51
ERROR - 2019-07-12 08:05:26 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 08:05:26 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 08:05:26 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 08:05:26 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 08:05:33 --> Severity: Notice --> Undefined variable: Projectldesc C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 51
ERROR - 2019-07-12 08:05:33 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 08:05:33 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 08:05:33 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 08:05:33 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 08:07:08 --> Severity: Notice --> Undefined variable: Projectldesc C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 51
ERROR - 2019-07-12 08:07:08 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 08:07:08 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 08:07:08 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 08:07:08 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 08:07:26 --> Severity: Notice --> Undefined variable: Projectldesc C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 51
ERROR - 2019-07-12 08:07:27 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 08:07:27 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 08:07:27 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 08:07:27 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 08:08:05 --> Severity: Notice --> Undefined variable: Projectldesc C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 51
ERROR - 2019-07-12 08:08:05 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 08:08:05 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 08:08:05 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 08:08:05 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 08:08:41 --> Severity: Notice --> Undefined variable: Projectldesc C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 51
ERROR - 2019-07-12 08:08:41 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 08:08:41 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 08:08:41 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 08:08:41 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 08:16:34 --> Severity: Notice --> Undefined variable: Projectldesc C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 51
ERROR - 2019-07-12 08:16:34 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 08:16:34 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 08:19:18 --> Severity: Notice --> Undefined variable: Projectldesc C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 51
ERROR - 2019-07-12 08:19:18 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 08:19:18 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 08:19:18 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 08:19:18 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 08:19:30 --> Severity: Notice --> Undefined variable: Projectldesc C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 51
ERROR - 2019-07-12 08:19:30 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 08:19:30 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 08:19:30 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 08:19:30 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 08:19:52 --> Severity: Notice --> Undefined variable: Projectldesc C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 60
ERROR - 2019-07-12 08:19:52 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 08:19:52 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 08:19:52 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 08:19:52 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 08:20:22 --> Severity: Notice --> Undefined variable: Projectldesc C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 60
ERROR - 2019-07-12 08:20:22 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 08:20:22 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 08:20:40 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 08:20:41 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 08:20:41 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 08:20:41 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 08:21:21 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 08:21:22 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 08:25:54 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 08:25:54 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 08:29:04 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 08:29:04 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 08:29:04 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 08:29:04 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 08:34:00 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 08:34:00 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 08:34:00 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 08:34:00 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 08:34:55 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 08:34:55 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 08:34:55 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 08:34:55 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 08:36:03 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 08:36:05 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 08:36:05 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 08:36:05 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 08:36:59 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 08:36:59 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 08:36:59 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 08:36:59 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 08:50:59 --> Severity: error --> Exception: syntax error, unexpected 'die' (T_EXIT) C:\xampp\htdocs\realestate\admin\application\controllers\Project.php 95
ERROR - 2019-07-12 08:51:24 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 08:51:24 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 08:52:28 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 08:52:29 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 08:52:29 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 08:52:29 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 08:52:30 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 08:52:30 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 08:55:32 --> Severity: Notice --> Undefined variable: _Files C:\xampp\htdocs\realestate\admin\application\controllers\Project.php 95
ERROR - 2019-07-12 08:56:03 --> Severity: Notice --> Undefined variable: _File C:\xampp\htdocs\realestate\admin\application\controllers\Project.php 95
ERROR - 2019-07-12 08:56:48 --> Severity: Notice --> Undefined property: Project::$project_model C:\xampp\htdocs\realestate\admin\application\controllers\Project.php 96
ERROR - 2019-07-12 08:56:48 --> Severity: error --> Exception: Call to a member function project_insert() on null C:\xampp\htdocs\realestate\admin\application\controllers\Project.php 96
ERROR - 2019-07-12 10:11:55 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\realestate\admin\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-07-12 10:11:55 --> Unable to connect to the database
ERROR - 2019-07-12 10:12:26 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\realestate\admin\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-07-12 10:12:26 --> Unable to connect to the database
ERROR - 2019-07-12 10:12:59 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 10:12:59 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 10:13:07 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 10:13:07 --> 404 Page Not Found: Home/app-assets
ERROR - 2019-07-12 10:13:11 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 10:13:11 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 10:16:52 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 10:16:53 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 10:26:48 --> Query error: Unknown column 'Projectsdesc' in 'field list' - Invalid query: INSERT INTO `tblprojects` (`ProjectTitle`, `Projectsdesc`, `ProjectImage`, `Projectlogo`, `Project_brochure`, `Projectstatus`, `IsActive`, `CreatedOn`) VALUES ('Shree Siddheshwar Holy Home', '“A Splash of Colour Can Get Your Life Flowing”\r\nTrusting Your Feelings and Taking Chances, Losing and Finding Happiness, Appreciating the Memories and Learning from the Past.', '5886Projectimage.jpg', '7349Projectlogo.png', '17183Projectbrochure.jpg', 'Ongoing', 'Active', '2019-07-12')
ERROR - 2019-07-12 10:32:53 --> Severity: Notice --> Undefined property: stdClass::$Price C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectList.php 55
ERROR - 2019-07-12 10:32:53 --> Severity: Notice --> Undefined property: stdClass::$Price C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectList.php 55
ERROR - 2019-07-12 10:32:53 --> Severity: Notice --> Undefined property: stdClass::$Price C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectList.php 55
ERROR - 2019-07-12 10:32:53 --> Severity: Notice --> Undefined property: stdClass::$Price C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectList.php 55
ERROR - 2019-07-12 10:32:53 --> Severity: Notice --> Undefined property: stdClass::$Price C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectList.php 55
ERROR - 2019-07-12 10:32:54 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 10:32:54 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 10:32:54 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 10:32:54 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 10:32:54 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 10:32:54 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 10:35:14 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 10:35:52 --> Severity: Notice --> Undefined property: stdClass::$Price C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectList.php 55
ERROR - 2019-07-12 10:35:52 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 10:35:52 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 10:35:52 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 10:35:52 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 10:37:28 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 10:37:28 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 10:37:28 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 10:37:28 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 10:37:29 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 10:39:25 --> Severity: Notice --> Undefined property: stdClass::$Price C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectList.php 55
ERROR - 2019-07-12 10:39:25 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 10:39:25 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 10:39:25 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 10:39:25 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 10:39:25 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 10:39:25 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 10:40:24 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 10:40:32 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 10:45:31 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 10:45:31 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 10:45:50 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 10:47:00 --> Severity: Notice --> Undefined property: stdClass::$Price C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectList.php 55
ERROR - 2019-07-12 10:47:00 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 10:47:00 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 10:47:00 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 10:47:00 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 10:47:00 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 10:47:00 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 10:54:59 --> Severity: Notice --> Undefined property: stdClass::$Price C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectList.php 54
ERROR - 2019-07-12 10:54:59 --> Severity: Notice --> Undefined variable: ProjectImage C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectList.php 55
ERROR - 2019-07-12 10:54:59 --> Severity: Notice --> Undefined variable: admin C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectList.php 69
ERROR - 2019-07-12 10:54:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectList.php 69
ERROR - 2019-07-12 10:54:59 --> Severity: Notice --> Undefined variable: admin C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectList.php 70
ERROR - 2019-07-12 10:54:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectList.php 70
ERROR - 2019-07-12 10:54:59 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 10:55:00 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 10:55:00 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 10:55:00 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 10:55:24 --> Severity: Notice --> Undefined property: stdClass::$Price C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectList.php 54
ERROR - 2019-07-12 10:55:24 --> Severity: Notice --> Undefined variable: admin C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectList.php 69
ERROR - 2019-07-12 10:55:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectList.php 69
ERROR - 2019-07-12 10:55:24 --> Severity: Notice --> Undefined variable: admin C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectList.php 70
ERROR - 2019-07-12 10:55:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectList.php 70
ERROR - 2019-07-12 10:55:24 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 10:55:24 --> 404 Page Not Found: Upload/project
ERROR - 2019-07-12 10:55:24 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 10:55:24 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 10:55:25 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 10:55:31 --> Severity: Notice --> Undefined variable: admin C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectList.php 69
ERROR - 2019-07-12 10:55:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectList.php 69
ERROR - 2019-07-12 10:55:31 --> Severity: Notice --> Undefined variable: admin C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectList.php 70
ERROR - 2019-07-12 10:55:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectList.php 70
ERROR - 2019-07-12 10:55:31 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 10:55:31 --> 404 Page Not Found: Upload/project
ERROR - 2019-07-12 10:55:31 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 10:55:31 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 10:55:31 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 10:55:31 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 10:55:31 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 10:55:44 --> Severity: Notice --> Undefined variable: admin C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectList.php 69
ERROR - 2019-07-12 10:55:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectList.php 69
ERROR - 2019-07-12 10:55:44 --> Severity: Notice --> Undefined variable: admin C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectList.php 70
ERROR - 2019-07-12 10:55:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectList.php 70
ERROR - 2019-07-12 10:55:44 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 10:55:45 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 10:55:45 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 10:55:45 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 10:55:45 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 10:55:45 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 10:56:27 --> Severity: Notice --> Undefined variable: admin C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectList.php 69
ERROR - 2019-07-12 10:56:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectList.php 69
ERROR - 2019-07-12 10:56:27 --> Severity: Notice --> Undefined variable: admin C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectList.php 70
ERROR - 2019-07-12 10:56:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectList.php 70
ERROR - 2019-07-12 10:56:27 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 10:56:28 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 10:56:28 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 10:56:28 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 10:56:28 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 10:56:28 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 10:56:48 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 10:56:48 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 10:56:48 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 10:56:48 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 10:56:48 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 10:56:48 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 10:57:01 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 10:57:01 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 10:57:01 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 10:57:01 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 10:57:01 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 10:57:01 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 10:57:07 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 10:57:08 --> 404 Page Not Found: Admin/app-assets
ERROR - 2019-07-12 10:58:30 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 10:58:30 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 10:58:30 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 10:58:31 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 10:58:36 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 10:58:37 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 10:58:37 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 10:58:37 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 10:58:37 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 10:58:37 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 10:58:50 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 10:58:51 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 10:58:51 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 10:58:51 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 10:58:51 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 10:58:51 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 10:59:00 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 10:59:00 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 10:59:00 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 10:59:00 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 10:59:00 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 10:59:00 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 10:59:28 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 10:59:29 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 10:59:29 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 10:59:29 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 10:59:29 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 10:59:29 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 11:01:48 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:01:48 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:01:48 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:01:48 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 11:01:48 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 11:01:48 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 11:01:59 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:01:59 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:01:59 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:01:59 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 11:01:59 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 11:01:59 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 11:02:18 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:02:18 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:02:18 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:02:18 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 11:02:20 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:02:20 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:02:20 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:02:20 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 11:02:20 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 11:02:20 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 11:03:03 --> Severity: error --> Exception: syntax error, unexpected '$row' (T_VARIABLE), expecting ',' or ';' C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectList.php 56
ERROR - 2019-07-12 11:03:22 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:03:22 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:03:22 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:03:22 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 11:03:22 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 11:03:22 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 11:03:52 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:03:52 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:03:52 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:03:52 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 11:03:52 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 11:03:52 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 11:04:02 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:04:03 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:04:03 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:04:03 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 11:04:03 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 11:04:03 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 11:04:32 --> Severity: Notice --> Undefined property: stdClass::$Projectstatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectList.php 56
ERROR - 2019-07-12 11:04:32 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:04:32 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:04:32 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:04:32 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 11:04:32 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 11:04:32 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 11:04:43 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:04:44 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:04:44 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:04:44 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 11:04:44 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 11:04:44 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 11:04:57 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:04:57 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:04:57 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:04:57 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 11:04:57 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 11:04:57 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 11:05:05 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:05:06 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:05:06 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:05:06 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 11:05:06 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 11:05:06 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 11:05:12 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:05:13 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:05:13 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:05:13 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 11:05:13 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 11:05:13 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 11:05:59 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:05:59 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:05:59 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:05:59 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 11:05:59 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 11:05:59 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 11:06:17 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:06:17 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:06:17 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:06:18 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 11:06:18 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 11:06:18 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 11:10:22 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:10:23 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:10:23 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:10:23 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 11:10:23 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 11:10:23 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 11:10:35 --> Severity: Notice --> Undefined property: Project::$Project_model C:\xampp\htdocs\realestate\admin\application\controllers\Project.php 82
ERROR - 2019-07-12 11:10:35 --> Severity: error --> Exception: Call to a member function getdata() on null C:\xampp\htdocs\realestate\admin\application\controllers\Project.php 82
ERROR - 2019-07-12 11:11:10 --> Severity: Notice --> Undefined index: ProjectDescription C:\xampp\htdocs\realestate\admin\application\controllers\Project.php 86
ERROR - 2019-07-12 11:11:10 --> Severity: Notice --> Undefined index: Price C:\xampp\htdocs\realestate\admin\application\controllers\Project.php 87
ERROR - 2019-07-12 11:11:10 --> Severity: Notice --> Undefined index: Projectbrochure C:\xampp\htdocs\realestate\admin\application\controllers\Project.php 90
ERROR - 2019-07-12 11:11:10 --> Severity: Notice --> Undefined variable: Projectsdesc C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 45
ERROR - 2019-07-12 11:11:10 --> Severity: Notice --> Undefined variable: Project_brochure C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 103
ERROR - 2019-07-12 11:11:10 --> Severity: Notice --> Undefined variable: Project_brochure C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 110
ERROR - 2019-07-12 11:11:10 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:11:10 --> Severity: Notice --> Undefined variable: Projectsdesc C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 45
ERROR - 2019-07-12 11:11:10 --> Severity: Notice --> Undefined variable: Project_brochure C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 103
ERROR - 2019-07-12 11:11:28 --> Severity: Notice --> Undefined index: Projectbrochure C:\xampp\htdocs\realestate\admin\application\controllers\Project.php 90
ERROR - 2019-07-12 11:11:28 --> Severity: Notice --> Undefined variable: Project_brochure C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 103
ERROR - 2019-07-12 11:11:28 --> Severity: Notice --> Undefined variable: Project_brochure C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 110
ERROR - 2019-07-12 11:11:28 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:11:29 --> Severity: Notice --> Undefined variable: Project_brochure C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 103
ERROR - 2019-07-12 11:11:39 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:11:40 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 11:11:40 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 11:13:23 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:13:23 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 11:13:23 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 11:13:26 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:13:43 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:13:43 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 11:13:43 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 11:14:41 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:14:41 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 11:14:41 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 11:14:47 --> 404 Page Not Found: Admin/Projectlist
ERROR - 2019-07-12 11:15:20 --> 404 Page Not Found: Admin/Projectlist
ERROR - 2019-07-12 11:15:21 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 11:15:21 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 11:15:23 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:15:23 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:15:23 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:15:23 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 11:15:33 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:15:33 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:15:33 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:15:33 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 11:15:33 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 11:15:33 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 11:15:36 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:15:42 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:15:42 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 11:16:04 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:16:04 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:16:04 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:16:04 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 11:16:04 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 11:16:04 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 11:16:21 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:16:21 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:16:21 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:16:21 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 11:16:21 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 11:16:21 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 11:16:24 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:23:45 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:24:18 --> Severity: error --> Exception: Call to undefined method Project_model::project_update() C:\xampp\htdocs\realestate\admin\application\controllers\Project.php 58
ERROR - 2019-07-12 11:40:43 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:40:43 --> 404 Page Not Found: Upload/projectlogo
ERROR - 2019-07-12 11:40:43 --> 404 Page Not Found: Upload/projectimage
ERROR - 2019-07-12 11:40:43 --> 404 Page Not Found: Upload/projectbrochure
ERROR - 2019-07-12 11:40:43 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 11:40:43 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 11:41:11 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:41:11 --> 404 Page Not Found: Upload/projectlogo
ERROR - 2019-07-12 11:41:11 --> 404 Page Not Found: Upload/projectbrochure
ERROR - 2019-07-12 11:41:11 --> 404 Page Not Found: Upload/projectimage
ERROR - 2019-07-12 11:41:11 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 11:41:11 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 11:41:42 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:41:42 --> 404 Page Not Found: Upload/projectlogo
ERROR - 2019-07-12 11:41:42 --> 404 Page Not Found: Upload/projectimage
ERROR - 2019-07-12 11:41:42 --> 404 Page Not Found: Upload/projectbrochure
ERROR - 2019-07-12 11:41:42 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 11:41:42 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 11:41:51 --> 404 Page Not Found: Upload/projectlogo
ERROR - 2019-07-12 11:41:51 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:41:51 --> 404 Page Not Found: Upload/projectimage
ERROR - 2019-07-12 11:41:51 --> 404 Page Not Found: Upload/projectbrochure
ERROR - 2019-07-12 11:41:57 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:41:57 --> 404 Page Not Found: Upload/projectimage
ERROR - 2019-07-12 11:41:57 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:41:57 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:41:59 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 51
ERROR - 2019-07-12 11:41:59 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 52
ERROR - 2019-07-12 11:41:59 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 53
ERROR - 2019-07-12 11:41:59 --> Severity: Notice --> Undefined variable: Projectlogo C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 71
ERROR - 2019-07-12 11:41:59 --> Severity: Notice --> Undefined variable: Project_brochure C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 103
ERROR - 2019-07-12 11:41:59 --> Severity: Notice --> Undefined variable: Project_brochure C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 109
ERROR - 2019-07-12 11:41:59 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:42:27 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 51
ERROR - 2019-07-12 11:42:27 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 52
ERROR - 2019-07-12 11:42:27 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 53
ERROR - 2019-07-12 11:42:27 --> Severity: Notice --> Undefined variable: Project_brochure C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 103
ERROR - 2019-07-12 11:42:27 --> Severity: Notice --> Undefined variable: Project_brochure C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 109
ERROR - 2019-07-12 11:42:28 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:42:28 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 11:42:28 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 11:42:51 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 51
ERROR - 2019-07-12 11:42:51 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 52
ERROR - 2019-07-12 11:42:51 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 53
ERROR - 2019-07-12 11:42:51 --> Severity: Notice --> Undefined variable: Project_brochure C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 103
ERROR - 2019-07-12 11:42:51 --> Severity: Notice --> Undefined variable: Project_brochure C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 109
ERROR - 2019-07-12 11:42:51 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:42:51 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 11:42:51 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 11:42:55 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 51
ERROR - 2019-07-12 11:42:55 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 52
ERROR - 2019-07-12 11:42:55 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 53
ERROR - 2019-07-12 11:42:55 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:42:55 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 11:42:55 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 11:43:11 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 51
ERROR - 2019-07-12 11:43:11 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 52
ERROR - 2019-07-12 11:43:11 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 53
ERROR - 2019-07-12 11:43:11 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:43:11 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 11:43:11 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 11:43:11 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 51
ERROR - 2019-07-12 11:43:11 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 52
ERROR - 2019-07-12 11:43:11 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 53
ERROR - 2019-07-12 11:43:40 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:43:40 --> 404 Page Not Found: Upload/projectimage
ERROR - 2019-07-12 11:43:41 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:43:41 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:43:41 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 11:43:42 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:43:42 --> 404 Page Not Found: Upload/projectlogo
ERROR - 2019-07-12 11:43:43 --> 404 Page Not Found: Upload/projectbrochure
ERROR - 2019-07-12 11:43:43 --> 404 Page Not Found: Upload/projectimage
ERROR - 2019-07-12 11:45:07 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:45:07 --> 404 Page Not Found: Upload/projectlogo
ERROR - 2019-07-12 11:45:07 --> 404 Page Not Found: Upload/projectimage
ERROR - 2019-07-12 11:45:07 --> 404 Page Not Found: Upload/projectbrochure
ERROR - 2019-07-12 11:45:07 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 11:45:07 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 11:45:23 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:45:23 --> 404 Page Not Found: Upload/projectlogo
ERROR - 2019-07-12 11:45:23 --> 404 Page Not Found: Upload/projectimage
ERROR - 2019-07-12 11:45:23 --> 404 Page Not Found: Upload/projectbrochure
ERROR - 2019-07-12 11:45:24 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 11:45:24 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 11:45:52 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:46:17 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:46:17 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 11:46:17 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 11:47:21 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:47:22 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:47:22 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:47:22 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 11:47:22 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 11:47:22 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 11:47:24 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:48:15 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:48:24 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:48:24 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 11:48:44 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:49:33 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:49:33 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 11:49:33 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 11:50:29 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:50:29 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 11:50:29 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 11:51:17 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:51:17 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:51:17 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:51:17 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 11:51:20 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:51:29 --> 404 Page Not Found: Upload/projectimage
ERROR - 2019-07-12 11:51:29 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:51:29 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 11:51:35 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:51:35 --> 404 Page Not Found: Upload/projectimage
ERROR - 2019-07-12 11:51:44 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:51:44 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 11:51:48 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:51:48 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 11:52:21 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:52:21 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:52:21 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:52:21 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 11:52:21 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 11:52:21 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 11:52:22 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 51
ERROR - 2019-07-12 11:52:22 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 52
ERROR - 2019-07-12 11:52:22 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 53
ERROR - 2019-07-12 11:52:22 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:52:22 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 51
ERROR - 2019-07-12 11:52:22 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 52
ERROR - 2019-07-12 11:52:22 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 53
ERROR - 2019-07-12 11:52:30 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:52:30 --> 404 Page Not Found: Admin/app-assets
ERROR - 2019-07-12 11:52:34 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 51
ERROR - 2019-07-12 11:52:34 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 52
ERROR - 2019-07-12 11:52:34 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 53
ERROR - 2019-07-12 11:52:34 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:52:34 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 11:52:35 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:52:36 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 51
ERROR - 2019-07-12 11:52:36 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 52
ERROR - 2019-07-12 11:52:36 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 53
ERROR - 2019-07-12 11:52:36 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:52:36 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 51
ERROR - 2019-07-12 11:52:36 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 52
ERROR - 2019-07-12 11:52:36 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 53
ERROR - 2019-07-12 11:53:11 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 51
ERROR - 2019-07-12 11:53:11 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 52
ERROR - 2019-07-12 11:53:11 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 53
ERROR - 2019-07-12 11:53:11 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:53:12 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 11:53:12 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 11:53:12 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 51
ERROR - 2019-07-12 11:53:12 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 52
ERROR - 2019-07-12 11:53:12 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 53
ERROR - 2019-07-12 11:53:12 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:53:13 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:53:13 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:53:14 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 51
ERROR - 2019-07-12 11:53:14 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 52
ERROR - 2019-07-12 11:53:14 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 53
ERROR - 2019-07-12 11:53:14 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:53:14 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 51
ERROR - 2019-07-12 11:53:14 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 52
ERROR - 2019-07-12 11:53:14 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 53
ERROR - 2019-07-12 11:54:12 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 51
ERROR - 2019-07-12 11:54:12 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 52
ERROR - 2019-07-12 11:54:12 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 53
ERROR - 2019-07-12 11:54:12 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:54:13 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 11:54:13 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 11:54:13 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 51
ERROR - 2019-07-12 11:54:13 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 52
ERROR - 2019-07-12 11:54:13 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 53
ERROR - 2019-07-12 11:54:15 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:54:15 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:54:15 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:54:15 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 11:54:30 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:54:30 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:54:30 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:54:30 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 11:54:30 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 11:54:30 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 11:54:31 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 51
ERROR - 2019-07-12 11:54:31 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 52
ERROR - 2019-07-12 11:54:31 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 53
ERROR - 2019-07-12 11:54:31 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:54:31 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 51
ERROR - 2019-07-12 11:54:31 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 52
ERROR - 2019-07-12 11:54:31 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 53
ERROR - 2019-07-12 11:54:34 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:54:34 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 11:54:47 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:54:47 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:54:47 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:54:47 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 11:54:47 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 11:54:47 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 11:54:51 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:55:13 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:55:13 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 11:55:15 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:55:21 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:55:21 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 11:55:23 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:55:29 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:55:29 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 11:56:04 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:56:04 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:56:04 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:56:04 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 11:56:04 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 11:56:04 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 11:56:11 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:56:11 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:56:11 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:56:11 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 11:56:11 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 11:56:11 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 11:56:13 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:56:13 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:56:13 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:56:13 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 11:57:35 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 51
ERROR - 2019-07-12 11:57:35 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 52
ERROR - 2019-07-12 11:57:35 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 53
ERROR - 2019-07-12 11:57:35 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:57:35 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 51
ERROR - 2019-07-12 11:57:35 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 52
ERROR - 2019-07-12 11:57:35 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 53
ERROR - 2019-07-12 11:58:19 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:58:20 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 11:58:20 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 11:58:46 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 11:58:46 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:58:46 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 11:58:46 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 11:58:53 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 12:00:34 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 12:00:34 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 12:00:34 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 12:00:35 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 12:00:35 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 12:00:35 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 12:00:48 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 12:00:48 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 12:00:51 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 12:05:29 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 12:05:29 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 12:05:29 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 12:05:29 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 12:05:34 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 12:05:39 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 12:05:39 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 12:08:01 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 12:08:01 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 12:08:01 --> 404 Page Not Found: Default/images
ERROR - 2019-07-12 12:08:01 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 12:08:04 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 12:09:14 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 12:09:14 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-12 12:09:28 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-12 12:09:28 --> 404 Page Not Found: User/app-assets
ERROR - 2019-07-12 13:05:17 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 13:05:17 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-12 14:17:29 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-12 14:17:29 --> 404 Page Not Found: Favicon/favicon.ico
