<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-12 05:53:05 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-12 05:53:05 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-12 06:01:37 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 06:01:37 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 06:01:37 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 06:01:37 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-06-12 06:01:37 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 06:02:58 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 06:03:50 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 06:12:03 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 06:43:19 --> 404 Page Not Found: Login/login
ERROR - 2019-06-12 06:44:36 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 06:45:53 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 06:45:59 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 06:46:15 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 06:47:35 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 06:50:02 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 06:50:41 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 06:51:28 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 06:51:59 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 06:51:59 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 06:51:59 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 06:51:59 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-12 06:52:08 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 06:52:14 --> 404 Page Not Found: Standard/Standaradlist
ERROR - 2019-06-12 06:54:14 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 06:54:22 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 06:54:22 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-12 06:55:39 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 06:55:52 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 06:55:58 --> 404 Page Not Found: Standard/Standaradlist
ERROR - 2019-06-12 06:56:25 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 06:56:30 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 06:56:30 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 06:56:30 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 06:56:30 --> 404 Page Not Found: Standard/app-assets
ERROR - 2019-06-12 06:57:08 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 06:57:08 --> 404 Page Not Found: Standard/app-assets
ERROR - 2019-06-12 06:57:12 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 06:57:19 --> Severity: Notice --> Undefined variable: session C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 44
ERROR - 2019-06-12 06:57:19 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 06:57:19 --> 404 Page Not Found: Standard/app-assets
ERROR - 2019-06-12 06:59:13 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 06:59:13 --> 404 Page Not Found: Standard/app-assets
ERROR - 2019-06-12 06:59:16 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 06:59:27 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 07:06:49 --> 404 Page Not Found: Common/index
ERROR - 2019-06-12 07:06:56 --> 404 Page Not Found: Common/login
ERROR - 2019-06-12 07:07:17 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 07:09:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 30
ERROR - 2019-06-12 07:09:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 31
ERROR - 2019-06-12 07:09:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 32
ERROR - 2019-06-12 07:09:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 33
ERROR - 2019-06-12 07:09:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 34
ERROR - 2019-06-12 07:09:23 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 07:09:23 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 07:09:23 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 07:09:23 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-12 07:10:14 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 07:10:14 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 07:10:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 30
ERROR - 2019-06-12 07:10:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 31
ERROR - 2019-06-12 07:10:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 32
ERROR - 2019-06-12 07:10:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 33
ERROR - 2019-06-12 07:10:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 34
ERROR - 2019-06-12 07:10:22 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 07:10:22 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 07:10:22 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 07:10:22 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-12 07:12:42 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 07:12:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 30
ERROR - 2019-06-12 07:12:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 31
ERROR - 2019-06-12 07:12:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 32
ERROR - 2019-06-12 07:12:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 33
ERROR - 2019-06-12 07:12:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 34
ERROR - 2019-06-12 07:12:56 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 07:12:56 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-12 07:13:12 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 07:13:12 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-12 07:13:16 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 07:13:29 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 07:13:35 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 07:13:35 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-12 07:14:31 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 07:16:25 --> Severity: Notice --> Undefined index: EmailAddress C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 30
ERROR - 2019-06-12 07:16:25 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 07:16:25 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 07:16:25 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 07:16:25 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-12 07:17:13 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 07:17:13 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 07:17:13 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 07:17:13 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-12 07:17:13 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-12 07:17:13 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-12 07:17:17 --> 404 Page Not Found: Program/logout.php
ERROR - 2019-06-12 07:17:24 --> Severity: Notice --> Undefined variable: res C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 26
ERROR - 2019-06-12 07:17:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 26
ERROR - 2019-06-12 07:18:13 --> Severity: Notice --> Undefined index: FirstName C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 26
ERROR - 2019-06-12 07:18:27 --> Severity: Notice --> Undefined index: FirstName C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 26
ERROR - 2019-06-12 07:23:10 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 07:23:10 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 07:23:10 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 07:23:10 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-12 07:23:10 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-12 07:23:10 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-12 07:23:31 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 07:23:31 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 07:23:31 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 07:23:31 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-12 07:23:34 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 07:23:41 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 07:23:41 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-12 07:25:20 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 07:25:20 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-12 07:25:55 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 07:26:01 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 07:26:01 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-12 07:28:01 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 07:28:06 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 07:28:06 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-12 07:29:42 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 07:29:48 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 07:29:48 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-12 09:25:29 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 09:25:29 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 09:25:29 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 09:25:29 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-12 09:29:17 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 09:29:17 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 09:29:17 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 09:29:17 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-12 09:57:39 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 09:57:39 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 09:57:39 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 09:57:40 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-12 09:57:44 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 09:57:48 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 09:57:48 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 09:57:48 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 09:57:48 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 09:57:49 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 09:57:49 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 09:57:49 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 09:59:02 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 09:59:14 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 10:01:00 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 10:01:03 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 10:05:01 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 10:05:06 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 10:05:06 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 10:05:06 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 10:05:06 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-12 10:05:10 --> 404 Page Not Found: Program/Login
ERROR - 2019-06-12 10:05:45 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 10:06:24 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 10:06:33 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 10:06:33 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 10:06:33 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 10:06:33 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-12 10:07:30 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 10:07:30 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 10:07:30 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 10:07:30 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-12 10:08:21 --> 404 Page Not Found: Program/Login
ERROR - 2019-06-12 10:10:24 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 10:10:24 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-12 10:10:28 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 10:10:28 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-12 10:11:46 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 10:11:47 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-12 10:12:31 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 10:12:31 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 10:12:31 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 10:12:31 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-12 10:13:13 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 10:13:13 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 10:13:13 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 10:13:13 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-12 10:14:24 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 10:14:25 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 10:14:25 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 10:14:25 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-12 10:14:29 --> 404 Page Not Found: Program/Login
ERROR - 2019-06-12 10:18:08 --> 404 Page Not Found: Program/Login
ERROR - 2019-06-12 10:18:11 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 10:18:11 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-12 10:19:47 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 10:19:48 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-12 10:19:54 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 10:22:54 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:22:54 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:22:55 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:22:55 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:22:55 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:22:55 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:22:55 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:22:55 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:22:55 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:22:55 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:22:55 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:22:55 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:22:55 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:22:55 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:22:55 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:22:55 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:22:55 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:22:55 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:22:55 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:22:55 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:22:56 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:22:56 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:22:56 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:22:56 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:22:56 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:22:56 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:22:56 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:22:56 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:22:57 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:22:57 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:22:57 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:22:57 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:22:57 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:22:57 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:22:57 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:22:57 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:22:57 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:22:57 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:22:57 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:22:57 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:23:02 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:23:02 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:23:02 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:23:02 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:23:02 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:23:02 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:23:03 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:23:03 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:23:03 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:23:03 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:23:03 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:23:03 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:23:03 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:23:03 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:23:03 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:23:03 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:23:03 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:23:03 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:23:03 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:23:03 --> Severity: Notice --> A session had already been started - ignoring session_start() C:\xampp\htdocs\mentor\admin\application\views\common\header.php 51
ERROR - 2019-06-12 10:23:38 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 10:24:17 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 10:27:13 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 10:27:22 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 10:27:22 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 10:27:22 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 10:27:22 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-12 10:27:27 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 10:28:46 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 10:28:51 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 10:28:51 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 10:28:51 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 10:28:51 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-12 10:30:21 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 10:30:21 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-12 10:30:26 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 10:31:55 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 10:31:55 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-12 10:47:08 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-12 10:47:08 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-12 10:48:00 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 10:48:01 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 10:48:01 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 10:48:01 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-12 10:48:01 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-12 10:48:01 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-12 10:55:25 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-12 10:55:25 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-12 10:55:33 --> Query error: Table 'mentor.admin' doesn't exist - Invalid query: SELECT *
FROM `admin`
WHERE `admin_id` = '1'
ERROR - 2019-06-12 10:57:14 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 10:57:15 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 10:57:15 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 10:57:15 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-12 10:57:25 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 10:57:25 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-12 11:01:33 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 11:05:32 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 11:05:32 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-12 11:05:35 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 11:05:47 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 11:05:47 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-12 11:06:31 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 11:06:31 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-12 11:06:33 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 11:06:37 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 11:06:37 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-12 11:08:50 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 11:08:50 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-12 11:08:54 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 11:08:54 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-12 11:08:58 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 11:09:04 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 11:09:04 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-12 11:09:07 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 11:09:10 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 11:09:10 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-12 11:09:16 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 11:09:16 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-12 11:09:22 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 11:09:22 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-12 11:09:39 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 11:09:39 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-06-12 11:09:45 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 11:09:45 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-12 11:09:52 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 11:09:52 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-12 11:09:59 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 11:10:00 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-06-12 11:21:24 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 11:21:24 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 11:21:24 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 12:59:06 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 12:59:15 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 13:00:01 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 13:01:04 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 13:01:26 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 13:03:10 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 13:03:13 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 13:05:55 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 13:06:20 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 13:06:21 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 13:06:21 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 13:06:21 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 13:06:21 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 13:06:21 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 13:06:35 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 13:07:14 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 13:07:45 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 13:10:50 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-12 13:10:50 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 13:10:50 --> 404 Page Not Found: Default/images
ERROR - 2019-06-12 13:10:50 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-12 13:28:32 --> Severity: Notice --> Undefined variable: session C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 44
ERROR - 2019-06-12 13:28:32 --> 404 Page Not Found: Login/login
ERROR - 2019-06-12 13:29:05 --> Severity: Notice --> Undefined variable: session C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 44
ERROR - 2019-06-12 13:29:12 --> Severity: Notice --> Undefined variable: session C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 44
ERROR - 2019-06-12 13:31:48 --> Severity: Notice --> Undefined variable: session C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 44
ERROR - 2019-06-12 13:34:06 --> Severity: Notice --> Undefined variable: session C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 44
ERROR - 2019-06-12 13:35:16 --> Severity: Notice --> Undefined variable: session C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 44
ERROR - 2019-06-12 13:36:43 --> Severity: Notice --> Undefined variable: session C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 44
ERROR - 2019-06-12 13:37:07 --> Severity: Notice --> Undefined variable: session C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 44
ERROR - 2019-06-12 13:37:31 --> Severity: Notice --> Undefined variable: session C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 44
ERROR - 2019-06-12 13:40:09 --> Severity: 4096 --> Object of class CI_Session could not be converted to string C:\xampp\htdocs\mentor\admin\application\views\common\login.php 17
ERROR - 2019-06-12 13:40:48 --> Severity: Notice --> Undefined variable: session C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 44
ERROR - 2019-06-12 13:43:41 --> Severity: Notice --> Undefined variable: session C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 44
ERROR - 2019-06-12 13:44:21 --> Severity: Notice --> Undefined variable: session C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 44
