<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-14 14:33:55 --> 404 Page Not Found: Default/images
ERROR - 2019-06-14 14:33:55 --> 404 Page Not Found: Default/images
ERROR - 2019-06-14 14:33:55 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-14 14:33:55 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-14 14:34:04 --> 404 Page Not Found: Default/images
ERROR - 2019-06-14 14:34:04 --> 404 Page Not Found: Default/images
ERROR - 2019-06-14 14:34:04 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-14 14:34:04 --> 404 Page Not Found: Favicon/favicon.ico
