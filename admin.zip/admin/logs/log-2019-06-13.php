<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-13 05:59:26 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-13 05:59:26 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-13 06:39:10 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 06:39:10 --> 404 Page Not Found: Default/images
ERROR - 2019-06-13 06:39:10 --> 404 Page Not Found: Default/images
ERROR - 2019-06-13 06:39:10 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-13 09:33:00 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-13 09:33:00 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-13 09:33:06 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 09:33:06 --> 404 Page Not Found: Default/images
ERROR - 2019-06-13 09:33:06 --> 404 Page Not Found: Default/images
ERROR - 2019-06-13 09:33:06 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-13 09:33:09 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 09:33:10 --> 404 Page Not Found: Usersession/app-assets
ERROR - 2019-06-13 09:33:18 --> Query error: Unknown column 'ss.user_id' in 'on clause' - Invalid query: SELECT *
FROM `tblusersession` `ss`
JOIN `tbluser` as `us` ON `us`.`UserId`=`ss`.`user_id`
ERROR - 2019-06-13 09:38:25 --> Query error: Table 'mentor.tbluser' doesn't exist - Invalid query: SELECT *
FROM `tbluser`
WHERE `UserId` = '1'
ERROR - 2019-06-13 09:38:29 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:22:23 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:30:18 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:30:25 --> Query error: Unknown column 'Password' in 'where clause' - Invalid query: SELECT *
FROM `tbluser`
WHERE `EmailAddress` = 'mitnp16@gmail.com'
AND `Password` = '12345678'
AND `IsActive` = 1
ERROR - 2019-06-13 10:31:43 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:31:48 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:31:48 --> 404 Page Not Found: Default/images
ERROR - 2019-06-13 10:31:48 --> 404 Page Not Found: Default/images
ERROR - 2019-06-13 10:31:48 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-13 10:31:54 --> Severity: Notice --> Undefined property: stdClass::$Email C:\xampp\htdocs\mentor\admin\application\views\Usersession\UsersessionList.php 54
ERROR - 2019-06-13 10:31:54 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:31:54 --> 404 Page Not Found: Usersession/app-assets
ERROR - 2019-06-13 10:32:12 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:32:20 --> Query error: Unknown column 'streamid' in 'where clause' - Invalid query: SELECT *
FROM `tblstandard`
WHERE `streamid` = '1'
ERROR - 2019-06-13 10:32:33 --> Severity: Notice --> Undefined property: stdClass::$Email C:\xampp\htdocs\mentor\admin\application\views\Usersession\UsersessionList.php 54
ERROR - 2019-06-13 10:32:33 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:32:33 --> Severity: Notice --> Undefined property: stdClass::$Email C:\xampp\htdocs\mentor\admin\application\views\Usersession\UsersessionList.php 54
ERROR - 2019-06-13 10:33:39 --> Severity: Notice --> Undefined property: stdClass::$Email C:\xampp\htdocs\mentor\admin\application\views\Usersession\UsersessionList.php 54
ERROR - 2019-06-13 10:33:39 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:33:40 --> Severity: Notice --> Undefined property: stdClass::$Email C:\xampp\htdocs\mentor\admin\application\views\Usersession\UsersessionList.php 54
ERROR - 2019-06-13 10:33:40 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:33:42 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:33:53 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:33:54 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:33:54 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:33:54 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:36:16 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:36:20 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:36:21 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:36:21 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:36:21 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:36:21 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:36:21 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:36:21 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:36:22 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:36:22 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:36:22 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:36:22 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:36:22 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:36:38 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:36:38 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:36:38 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:36:38 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:37:14 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:37:18 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:37:20 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:38:32 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:39:19 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:39:22 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:39:23 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:39:23 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:39:23 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:39:23 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:39:23 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:39:23 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:39:24 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:39:26 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:39:27 --> 404 Page Not Found: Default/assets
ERROR - 2019-06-13 10:39:27 --> 404 Page Not Found: Default/assets
ERROR - 2019-06-13 10:39:27 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-13 10:39:27 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-13 10:41:38 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:41:38 --> 404 Page Not Found: Default/assets
ERROR - 2019-06-13 10:41:38 --> 404 Page Not Found: Default/assets
ERROR - 2019-06-13 10:41:41 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:41:41 --> 404 Page Not Found: Default/images
ERROR - 2019-06-13 10:41:41 --> 404 Page Not Found: Default/images
ERROR - 2019-06-13 10:41:42 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:41:46 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:41:46 --> 404 Page Not Found: Default/assets
ERROR - 2019-06-13 10:41:46 --> 404 Page Not Found: Default/assets
ERROR - 2019-06-13 10:41:48 --> Query error: Unknown column 'streamid' in 'where clause' - Invalid query: SELECT *
FROM `tblstandard`
WHERE `streamid` = '1'
ERROR - 2019-06-13 10:42:01 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:42:22 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:42:26 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:42:26 --> 404 Page Not Found: Default/assets
ERROR - 2019-06-13 10:42:26 --> 404 Page Not Found: Default/assets
ERROR - 2019-06-13 10:42:28 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:42:50 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:42:50 --> 404 Page Not Found: Default/assets
ERROR - 2019-06-13 10:42:50 --> 404 Page Not Found: Default/assets
ERROR - 2019-06-13 10:43:03 --> Query error: Unknown column 'streamid' in 'where clause' - Invalid query: SELECT *
FROM `tblstandard`
WHERE `streamid` = '1'
ERROR - 2019-06-13 10:43:15 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:43:32 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:43:32 --> 404 Page Not Found: Default/assets
ERROR - 2019-06-13 10:43:32 --> 404 Page Not Found: Default/assets
ERROR - 2019-06-13 10:44:52 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:44:52 --> 404 Page Not Found: Standard/app-assets
ERROR - 2019-06-13 10:44:58 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:44:58 --> 404 Page Not Found: Stream/app-assets
ERROR - 2019-06-13 10:45:00 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:45:00 --> 404 Page Not Found: Stream/app-assets
ERROR - 2019-06-13 10:45:02 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:45:02 --> 404 Page Not Found: Stream/app-assets
ERROR - 2019-06-13 10:45:31 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:45:35 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:45:35 --> 404 Page Not Found: Standard/app-assets
ERROR - 2019-06-13 10:48:16 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:48:16 --> 404 Page Not Found: Standard/app-assets
ERROR - 2019-06-13 10:48:20 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:50:03 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:50:11 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:50:13 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 10:50:48 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-13 12:02:47 --> 404 Page Not Found: Default/images
ERROR - 2019-06-13 12:02:47 --> 404 Page Not Found: Default/images
ERROR - 2019-06-13 12:03:21 --> Query error: Unknown column 'EmailAddress' in 'where clause' - Invalid query: SELECT *
FROM `tbluser`
WHERE `EmailAddress` = 'mitnp16@gmail.com'
AND `Password` = '123456789'
AND `IsActive` = 1
ERROR - 2019-06-13 12:04:25 --> Query error: Unknown column 'Password' in 'where clause' - Invalid query: SELECT *
FROM `tbluser`
WHERE `Email` = 'mitnp16@gmail.com'
AND `Password` = '123456789'
AND `IsActive` = 1
ERROR - 2019-06-13 12:05:54 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-13 12:05:54 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-13 12:06:01 --> Severity: Notice --> Undefined variable: session C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 44
ERROR - 2019-06-13 12:06:08 --> Severity: Notice --> Undefined variable: session C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 44
