<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-17 13:03:21 --> 404 Page Not Found: Default/images
ERROR - 2019-06-17 13:03:22 --> 404 Page Not Found: Default/images
ERROR - 2019-06-17 13:03:22 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-17 13:03:22 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-17 13:03:43 --> 404 Page Not Found: Default/images
ERROR - 2019-06-17 13:03:43 --> 404 Page Not Found: Default/images
ERROR - 2019-06-17 15:00:08 --> Severity: Notice --> Use of undefined constant VIEWPATH - assumed 'VIEWPATH' C:\xampp\htdocs\mentor\admin\system\core\Common.php 196
ERROR - 2019-06-17 15:00:08 --> Severity: Notice --> Use of undefined constant VIEWPATH - assumed 'VIEWPATH' C:\xampp\htdocs\mentor\admin\system\core\Exceptions.php 162
ERROR - 2019-06-17 15:00:08 --> Severity: Warning --> include(VIEWPATHerrors\html\error_general.php): failed to open stream: No such file or directory C:\xampp\htdocs\mentor\admin\system\core\Exceptions.php 182
ERROR - 2019-06-17 15:00:08 --> Severity: Warning --> include(): Failed opening 'VIEWPATHerrors\html\error_general.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\mentor\admin\system\core\Exceptions.php 182
ERROR - 2019-06-17 15:00:11 --> Severity: Notice --> Use of undefined constant VIEWPATH - assumed 'VIEWPATH' C:\xampp\htdocs\mentor\admin\system\core\Common.php 196
ERROR - 2019-06-17 15:00:11 --> Severity: Notice --> Use of undefined constant VIEWPATH - assumed 'VIEWPATH' C:\xampp\htdocs\mentor\admin\system\core\Exceptions.php 162
ERROR - 2019-06-17 15:00:11 --> Severity: Warning --> include(VIEWPATHerrors\html\error_general.php): failed to open stream: No such file or directory C:\xampp\htdocs\mentor\admin\system\core\Exceptions.php 182
ERROR - 2019-06-17 15:00:11 --> Severity: Warning --> include(): Failed opening 'VIEWPATHerrors\html\error_general.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\mentor\admin\system\core\Exceptions.php 182
ERROR - 2019-06-17 15:04:19 --> Severity: Notice --> Use of undefined constant VIEWPATH - assumed 'VIEWPATH' C:\xampp\htdocs\mentor\admin\system\core\Common.php 196
ERROR - 2019-06-17 15:04:19 --> Severity: Notice --> Use of undefined constant VIEWPATH - assumed 'VIEWPATH' C:\xampp\htdocs\mentor\admin\system\core\Exceptions.php 162
ERROR - 2019-06-17 15:04:19 --> Severity: Warning --> include(VIEWPATHerrors\html\error_general.php): failed to open stream: No such file or directory C:\xampp\htdocs\mentor\admin\system\core\Exceptions.php 182
ERROR - 2019-06-17 15:04:19 --> Severity: Warning --> include(): Failed opening 'VIEWPATHerrors\html\error_general.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\mentor\admin\system\core\Exceptions.php 182
ERROR - 2019-06-17 15:04:20 --> Severity: Notice --> Use of undefined constant VIEWPATH - assumed 'VIEWPATH' C:\xampp\htdocs\mentor\admin\system\core\Common.php 196
ERROR - 2019-06-17 15:04:20 --> Severity: Notice --> Use of undefined constant VIEWPATH - assumed 'VIEWPATH' C:\xampp\htdocs\mentor\admin\system\core\Exceptions.php 162
ERROR - 2019-06-17 15:04:20 --> Severity: Warning --> include(VIEWPATHerrors\html\error_general.php): failed to open stream: No such file or directory C:\xampp\htdocs\mentor\admin\system\core\Exceptions.php 182
ERROR - 2019-06-17 15:04:20 --> Severity: Warning --> include(): Failed opening 'VIEWPATHerrors\html\error_general.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\mentor\admin\system\core\Exceptions.php 182
ERROR - 2019-06-17 15:04:35 --> Severity: Warning --> include(\errors\html\error_general.php): failed to open stream: No such file or directory C:\xampp\htdocs\mentor\admin\system\core\Exceptions.php 182
ERROR - 2019-06-17 15:04:35 --> Severity: Warning --> include(): Failed opening '\errors\html\error_general.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\mentor\admin\system\core\Exceptions.php 182
