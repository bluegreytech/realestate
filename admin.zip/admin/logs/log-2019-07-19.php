<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-19 07:31:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\realestate\admin\application\models\Api_model.php 3504
ERROR - 2019-07-19 07:31:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\realestate\admin\application\models\Api_model.php 3505
ERROR - 2019-07-19 07:33:46 --> Severity: Notice --> Undefined property: stdClass::$user_id C:\xampp\htdocs\realestate\admin\application\models\Api_model.php 3499
ERROR - 2019-07-19 07:33:46 --> Query error: Unknown column 'UserId' in 'where clause' - Invalid query: UPDATE `tbluser` SET `forget_password_code` = '64aBl'
WHERE `UserId` IS NULL
ERROR - 2019-07-19 07:58:54 --> Query error: Table 'realstatesdb.site_setting' doesn't exist - Invalid query: SELECT *
FROM `site_setting`
ERROR - 2019-07-19 07:59:24 --> Query error: Unknown column 'password' in 'field list' - Invalid query: UPDATE `tbluser` SET `password` = '827ccb0eea8a706c4c34a16891f84e7b', `ResetPasswordCode` = ''
WHERE `UsersId` = '8'
ERROR - 2019-07-19 07:59:38 --> Query error: Unknown column 'Password' in 'field list' - Invalid query: UPDATE `tbluser` SET `Password` = '827ccb0eea8a706c4c34a16891f84e7b', `ResetPasswordCode` = ''
WHERE `UsersId` = '8'
ERROR - 2019-07-19 10:28:27 --> Severity: error --> Exception: syntax error, unexpected 'print_r' (T_STRING), expecting ';' or '{' C:\xampp\htdocs\realestate\admin\application\models\Api_model.php 1822
ERROR - 2019-07-19 10:29:09 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO), expecting ';' or '{' C:\xampp\htdocs\realestate\admin\application\models\Api_model.php 1822
ERROR - 2019-07-19 10:29:40 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE), expecting ';' or '{' C:\xampp\htdocs\realestate\admin\application\models\Api_model.php 1825
ERROR - 2019-07-19 10:30:51 --> Severity: error --> Exception: syntax error, unexpected '$user_id' (T_VARIABLE), expecting ';' or '{' C:\xampp\htdocs\realestate\admin\application\models\Api_model.php 1826
ERROR - 2019-07-19 10:32:48 --> Query error: Unknown column 'profile_image' in 'field list' - Invalid query: UPDATE `tbluser` SET `FullName` = 'Binny Rai', `UserContact` = '01223456789', `EmailAddress` = 'binny1@yopmail.com', `profile_image` = '6635user.jpg'
WHERE `UsersId` = '8'
ERROR - 2019-07-19 10:34:37 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-19 10:34:37 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-19 10:44:06 --> 404 Page Not Found: Default/images
ERROR - 2019-07-19 10:44:06 --> 404 Page Not Found: Default/images
ERROR - 2019-07-19 11:51:50 --> 404 Page Not Found: Default/images
ERROR - 2019-07-19 11:51:50 --> 404 Page Not Found: Default/images
ERROR - 2019-07-19 12:13:14 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' C:\xampp\htdocs\realestate\admin\application\models\Api_model.php 1533
ERROR - 2019-07-19 12:14:18 --> Query error: Unknown column 'password' in 'field list' - Invalid query: UPDATE `tbluser` SET `password` = '0e7517141fb53f21ee439b355b5a1d0a'
WHERE `UsersId` = '3'
AND `UserPassword` = 'e6e061838856bf47e1de730719fb2609'
ERROR - 2019-07-19 13:06:04 --> Severity: error --> Exception: Too few arguments to function Home::change_password(), 0 passed in C:\xampp\htdocs\realestate\admin\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\realestate\admin\application\controllers\Home.php 221
ERROR - 2019-07-19 13:06:37 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\realestate\admin\application\controllers\Home.php 227
ERROR - 2019-07-19 13:06:37 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-19 13:06:37 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-19 13:07:35 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-19 13:07:35 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-19 13:08:43 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-19 13:08:43 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-19 13:38:03 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-19 13:38:03 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-19 13:38:21 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-19 13:38:21 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-19 13:38:43 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-19 13:38:43 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-19 13:41:40 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-19 13:41:40 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-19 14:00:26 --> Severity: Notice --> Undefined property: Home::$home_model C:\xampp\htdocs\realestate\admin\application\controllers\Home.php 251
ERROR - 2019-07-19 14:00:26 --> Severity: error --> Exception: Call to a member function updateAdminPassword() on null C:\xampp\htdocs\realestate\admin\application\controllers\Home.php 251
ERROR - 2019-07-19 14:00:36 --> Severity: Notice --> Undefined property: Home::$login_model C:\xampp\htdocs\realestate\admin\application\controllers\Home.php 251
ERROR - 2019-07-19 14:00:36 --> Severity: error --> Exception: Call to a member function updateAdminPassword() on null C:\xampp\htdocs\realestate\admin\application\controllers\Home.php 251
ERROR - 2019-07-19 14:13:39 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-19 14:13:39 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-19 14:13:41 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-19 14:13:41 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-19 14:15:50 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-19 14:15:51 --> 404 Page Not Found: Favicon/favicon.ico
