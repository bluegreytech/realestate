<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-19 06:52:39 --> 404 Page Not Found: Default/images
ERROR - 2019-06-19 06:52:39 --> 404 Page Not Found: Default/images
ERROR - 2019-06-19 06:52:39 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-19 06:52:39 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-19 06:53:28 --> Severity: Notice --> Undefined variable: datasession C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 47
ERROR - 2019-06-19 06:57:13 --> Severity: Notice --> Undefined variable: datasession C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 47
ERROR - 2019-06-19 06:57:19 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 06:57:19 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-19 06:57:27 --> Severity: Notice --> Undefined property: stdClass::$gender C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 106
ERROR - 2019-06-19 06:57:27 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 107
ERROR - 2019-06-19 06:57:28 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 06:57:28 --> 404 Page Not Found: Login/app-assets
ERROR - 2019-06-19 06:57:31 --> Severity: Notice --> Undefined property: stdClass::$gender C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 106
ERROR - 2019-06-19 06:57:31 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 107
ERROR - 2019-06-19 06:58:05 --> Severity: Notice --> Undefined property: stdClass::$gender C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 106
ERROR - 2019-06-19 06:58:05 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 107
ERROR - 2019-06-19 06:58:11 --> Severity: Notice --> Undefined property: stdClass::$gender C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 106
ERROR - 2019-06-19 06:58:11 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 107
ERROR - 2019-06-19 06:58:11 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 06:58:12 --> 404 Page Not Found: Login/app-assets
ERROR - 2019-06-19 07:04:31 --> Severity: Notice --> Undefined property: stdClass::$gender C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 106
ERROR - 2019-06-19 07:04:31 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 107
ERROR - 2019-06-19 07:04:31 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 07:04:32 --> 404 Page Not Found: Login/app-assets
ERROR - 2019-06-19 07:05:17 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 07:05:17 --> 404 Page Not Found: Login/app-assets
ERROR - 2019-06-19 07:05:17 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-19 07:05:17 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-19 07:10:07 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 07:10:08 --> 404 Page Not Found: Login/app-assets
ERROR - 2019-06-19 07:10:08 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-19 07:10:08 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-19 07:12:22 --> Severity: Notice --> Undefined variable: first_name C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 37
ERROR - 2019-06-19 07:12:22 --> Severity: Notice --> Undefined variable: last_name C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 41
ERROR - 2019-06-19 07:12:22 --> Severity: Notice --> Undefined variable: email C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 45
ERROR - 2019-06-19 07:12:22 --> Severity: Notice --> Undefined variable: phone C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 49
ERROR - 2019-06-19 07:12:22 --> Severity: Notice --> Undefined variable: gender C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 54
ERROR - 2019-06-19 07:12:22 --> Severity: Notice --> Undefined variable: gender C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 58
ERROR - 2019-06-19 07:12:23 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 07:12:23 --> 404 Page Not Found: Login/app-assets
ERROR - 2019-06-19 07:12:23 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-19 07:12:23 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-19 07:13:01 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 07:13:01 --> 404 Page Not Found: Login/app-assets
ERROR - 2019-06-19 07:13:01 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-19 07:13:01 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-19 07:13:17 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 07:13:17 --> 404 Page Not Found: Login/app-assets
ERROR - 2019-06-19 07:13:17 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-19 07:13:17 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-19 07:18:22 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 07:18:22 --> 404 Page Not Found: Login/app-assets
ERROR - 2019-06-19 07:18:22 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-19 07:18:22 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-19 07:19:22 --> Severity: error --> Exception: syntax error, unexpected 'if' (T_IF), expecting ',' or ';' C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 87
ERROR - 2019-06-19 07:19:27 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 07:19:27 --> 404 Page Not Found: Login/app-assets
ERROR - 2019-06-19 07:19:50 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 07:19:50 --> 404 Page Not Found: Login/app-assets
ERROR - 2019-06-19 07:27:10 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 07:27:10 --> 404 Page Not Found: Login/app-assets
ERROR - 2019-06-19 07:27:49 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 07:27:49 --> 404 Page Not Found: Login/app-assets
ERROR - 2019-06-19 07:27:50 --> Could not find the language line "form_validation_adminmail_check"
ERROR - 2019-06-19 07:27:50 --> Severity: Notice --> Undefined variable: email C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 45
ERROR - 2019-06-19 07:27:51 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 07:28:08 --> Could not find the language line "form_validation_adminmail_check"
ERROR - 2019-06-19 07:28:08 --> Severity: Notice --> Undefined variable: email C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 45
ERROR - 2019-06-19 07:28:09 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 07:28:09 --> Severity: Notice --> Undefined variable: email C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 45
ERROR - 2019-06-19 07:28:12 --> Severity: Notice --> Undefined variable: email C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 45
ERROR - 2019-06-19 07:28:12 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 07:28:12 --> Severity: Notice --> Undefined variable: email C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 45
ERROR - 2019-06-19 07:28:35 --> Severity: Notice --> Undefined variable: email C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 45
ERROR - 2019-06-19 07:28:35 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 07:28:35 --> Severity: Notice --> Undefined variable: email C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 45
ERROR - 2019-06-19 07:28:38 --> Severity: Notice --> Undefined variable: email C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 45
ERROR - 2019-06-19 07:28:38 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 07:28:38 --> Severity: Notice --> Undefined variable: email C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 45
ERROR - 2019-06-19 07:29:10 --> Severity: Notice --> Undefined variable: email C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 45
ERROR - 2019-06-19 07:29:10 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 07:29:11 --> Severity: Notice --> Undefined variable: email C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 45
ERROR - 2019-06-19 07:29:29 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 07:30:19 --> Could not find the language line "form_validation_adminmail_check"
ERROR - 2019-06-19 07:30:19 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 07:31:25 --> Could not find the language line "form_validation_adminmail_check"
ERROR - 2019-06-19 07:33:31 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 07:33:31 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-19 07:33:31 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-19 07:34:04 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 07:34:05 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-19 07:34:05 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-19 07:34:33 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 07:34:34 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-19 07:34:34 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-19 07:36:40 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 07:36:41 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-19 07:36:41 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-19 07:38:05 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-19 07:38:05 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-19 07:40:37 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 07:40:38 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-19 07:40:38 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-19 07:41:44 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 07:41:45 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-19 07:41:45 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-19 07:41:51 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 07:41:52 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-19 07:41:52 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-19 07:42:37 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 07:42:37 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-19 07:42:38 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-19 07:43:10 --> Query error: Unknown column 'first_name' in 'field list' - Invalid query: UPDATE `tbluser` SET `email` = NULL, `first_name` = 'binny', `last_name` = 'Rai', `phone` = '1234567890', `gender` = 'male'
WHERE `UserId` = '1'
ERROR - 2019-06-19 07:43:44 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 07:43:44 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-19 07:43:44 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-19 07:43:47 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 07:43:56 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 07:43:57 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-19 07:43:57 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-19 07:44:02 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 07:44:12 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 07:44:33 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 07:44:33 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-19 07:44:33 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-19 07:44:42 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 07:44:42 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-19 07:44:42 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-19 07:44:46 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 07:44:47 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-19 07:44:47 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-19 07:45:13 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 07:45:13 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-19 07:45:13 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-19 07:46:18 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 07:46:18 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-19 07:46:18 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-19 07:46:29 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 07:46:37 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 07:46:43 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 07:46:53 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 08:06:44 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 08:06:45 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-19 08:06:45 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-19 08:06:48 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 08:10:47 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 08:10:48 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-19 08:10:48 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-19 08:10:51 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 08:10:58 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 08:10:59 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-19 08:10:59 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-19 08:11:03 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 08:11:59 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 08:11:59 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-19 08:11:59 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-19 08:12:33 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 08:12:33 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-19 08:12:33 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-19 08:13:21 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-19 08:13:22 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-19 08:13:22 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-19 08:54:49 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-19 08:54:49 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-19 08:57:19 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-19 08:57:19 --> 404 Page Not Found: Favicon/favicon.ico
