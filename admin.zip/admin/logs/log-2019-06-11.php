<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-11 05:45:51 --> Severity: Notice --> Undefined variable: QuestionId C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 18
ERROR - 2019-06-11 05:45:51 --> Severity: Notice --> Undefined variable: QuestionId C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 41
ERROR - 2019-06-11 05:45:51 --> Severity: Notice --> Undefined property: stdClass::$StreamName C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 48
ERROR - 2019-06-11 05:45:51 --> Severity: Notice --> Undefined property: stdClass::$StreamName C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 48
ERROR - 2019-06-11 05:45:51 --> Severity: Notice --> Undefined property: stdClass::$StreamName C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 48
ERROR - 2019-06-11 05:45:51 --> Severity: Notice --> Undefined variable: QuestionId C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 88
ERROR - 2019-06-11 05:45:52 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-11 05:45:52 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-11 05:46:28 --> Severity: Notice --> Undefined variable: QuestionId C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 41
ERROR - 2019-06-11 05:46:28 --> Severity: Notice --> Undefined property: stdClass::$StreamName C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 48
ERROR - 2019-06-11 05:46:28 --> Severity: Notice --> Undefined property: stdClass::$StreamName C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 48
ERROR - 2019-06-11 05:46:28 --> Severity: Notice --> Undefined property: stdClass::$StreamName C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 48
ERROR - 2019-06-11 05:46:28 --> Severity: Notice --> Undefined variable: QuestionId C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 88
ERROR - 2019-06-11 05:46:28 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 05:46:28 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-11 05:47:11 --> Severity: Notice --> Undefined property: stdClass::$StreamName C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 48
ERROR - 2019-06-11 05:47:11 --> Severity: Notice --> Undefined property: stdClass::$StreamName C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 48
ERROR - 2019-06-11 05:47:11 --> Severity: Notice --> Undefined property: stdClass::$StreamName C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 48
ERROR - 2019-06-11 05:47:11 --> Severity: Notice --> Undefined variable: QuestionId C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 88
ERROR - 2019-06-11 05:47:11 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 05:47:11 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-11 05:48:03 --> Severity: Notice --> Undefined property: stdClass::$StreamName C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 48
ERROR - 2019-06-11 05:48:03 --> Severity: Notice --> Undefined property: stdClass::$StreamName C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 48
ERROR - 2019-06-11 05:48:03 --> Severity: Notice --> Undefined property: stdClass::$StreamName C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 48
ERROR - 2019-06-11 05:48:03 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 05:48:03 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-11 05:50:27 --> Severity: Notice --> Undefined property: stdClass::$StreamName C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 48
ERROR - 2019-06-11 05:50:27 --> Severity: Notice --> Undefined property: stdClass::$StreamName C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 48
ERROR - 2019-06-11 05:50:27 --> Severity: Notice --> Undefined property: stdClass::$StreamName C:\xampp\htdocs\mentor\admin\application\views\Question\QuestionAdd.php 48
ERROR - 2019-06-11 05:50:27 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 05:50:27 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-11 05:51:35 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 05:51:35 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-11 05:52:10 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 05:52:10 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-11 05:52:33 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 05:52:33 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-11 05:54:03 --> Query error: Column 'StreamTypeId' cannot be null - Invalid query: INSERT INTO `tblprogramtype` (`StreamTypeId`, `ProgramName`, `ProgramDescription`, `IsActive`, `CreatedBy`) VALUES (NULL, NULL, NULL, '1', 1)
ERROR - 2019-06-11 05:54:43 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 05:54:43 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-11 05:54:49 --> Query error: Column 'StreamTypeId' cannot be null - Invalid query: INSERT INTO `tblprogramtype` (`StreamTypeId`, `ProgramName`, `ProgramDescription`, `IsActive`, `CreatedBy`) VALUES (NULL, NULL, NULL, '1', 1)
ERROR - 2019-06-11 05:56:31 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 05:56:31 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-11 05:56:41 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 05:56:41 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-11 05:56:47 --> Query error: Column 'StreamTypeId' cannot be null - Invalid query: INSERT INTO `tblprogramtype` (`StreamTypeId`, `ProgramName`, `ProgramDescription`, `IsActive`, `CreatedBy`) VALUES (NULL, NULL, NULL, '1', 1)
ERROR - 2019-06-11 05:57:16 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 05:57:16 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-11 05:58:35 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 05:58:35 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-11 05:58:52 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 05:58:52 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-11 05:58:58 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 05:58:58 --> 404 Page Not Found: Default/images
ERROR - 2019-06-11 05:58:58 --> 404 Page Not Found: Default/images
ERROR - 2019-06-11 05:58:58 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-11 05:59:47 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 05:59:47 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-11 05:59:59 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 06:00:04 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 06:00:08 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 06:00:11 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 06:00:27 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 06:00:27 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-11 06:04:58 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 06:04:58 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-11 06:07:24 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 06:07:24 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-11 06:07:41 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 06:07:41 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-11 06:07:53 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 06:07:53 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-11 06:08:04 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 06:08:04 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-11 06:08:49 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 06:08:49 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-11 06:09:39 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 06:09:39 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-11 06:09:42 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 06:09:42 --> 404 Page Not Found: Default/images
ERROR - 2019-06-11 06:09:42 --> 404 Page Not Found: Default/images
ERROR - 2019-06-11 06:09:44 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 06:11:19 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 06:11:24 --> 404 Page Not Found: %20Question/%20Questionlist
ERROR - 2019-06-11 06:12:14 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 06:12:14 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-11 06:12:17 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 06:12:18 --> 404 Page Not Found: Default/images
ERROR - 2019-06-11 06:12:18 --> 404 Page Not Found: Default/images
ERROR - 2019-06-11 06:12:20 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 06:12:28 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 06:12:28 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-11 06:13:41 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 06:13:41 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-11 06:13:42 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 06:13:42 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-11 06:13:43 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 06:13:45 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 06:14:17 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 06:14:19 --> Query error: Unknown column 'ProgramName' in 'field list' - Invalid query: UPDATE `tblquestion` SET `AssesmentTypeId` = '1', `ProgramName` = NULL, `QuestionName` = 'mitesh', `IsActive` = '0'
WHERE `QuestionId` = '1'
ERROR - 2019-06-11 06:14:44 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 06:14:46 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 06:14:46 --> 404 Page Not Found: Default/images
ERROR - 2019-06-11 06:14:46 --> 404 Page Not Found: Default/images
ERROR - 2019-06-11 06:14:46 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-11 06:14:53 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 06:14:55 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 06:14:55 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-11 06:14:58 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 06:15:01 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 06:15:01 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-11 06:23:59 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 06:26:30 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 06:26:33 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 06:26:33 --> 404 Page Not Found: Default/images
ERROR - 2019-06-11 06:26:33 --> 404 Page Not Found: Default/images
ERROR - 2019-06-11 06:26:34 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 06:26:40 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 06:26:50 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 06:26:52 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 06:26:52 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-11 06:26:55 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 06:26:57 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 06:26:57 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-11 06:27:43 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 06:27:44 --> 404 Page Not Found: Question/PQuestionlist
ERROR - 2019-06-11 06:27:56 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 06:27:56 --> 404 Page Not Found: Default/images
ERROR - 2019-06-11 06:27:56 --> 404 Page Not Found: Default/images
ERROR - 2019-06-11 06:27:56 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-11 06:28:05 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 06:28:06 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 06:28:06 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-11 07:11:50 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:11:50 --> 404 Page Not Found: Standard/app-assets
ERROR - 2019-06-11 07:13:14 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:13:14 --> 404 Page Not Found: Default/images
ERROR - 2019-06-11 07:13:14 --> 404 Page Not Found: Default/images
ERROR - 2019-06-11 07:13:55 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:13:55 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-11 07:19:20 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:19:20 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-11 07:19:22 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:19:22 --> 404 Page Not Found: Default/images
ERROR - 2019-06-11 07:19:22 --> 404 Page Not Found: Default/images
ERROR - 2019-06-11 07:19:40 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:19:40 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:19:41 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:19:41 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:19:41 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:19:41 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:19:41 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:19:55 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:19:55 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-11 07:19:58 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:20:57 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:20:59 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:20:59 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-11 07:21:05 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:21:54 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:24:20 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:25:35 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:26:12 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:26:18 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:26:18 --> 404 Page Not Found: Standard/app-assets
ERROR - 2019-06-11 07:26:21 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:26:21 --> 404 Page Not Found: Standard/app-assets
ERROR - 2019-06-11 07:27:25 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:27:25 --> 404 Page Not Found: Standard/app-assets
ERROR - 2019-06-11 07:27:32 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:27:32 --> 404 Page Not Found: Stream/app-assets
ERROR - 2019-06-11 07:27:34 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:28:01 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:29:03 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:29:07 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:29:07 --> 404 Page Not Found: Userrole/app-assets
ERROR - 2019-06-11 07:29:09 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:30:23 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:30:26 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:30:33 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:30:35 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:31:21 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:32:47 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:33:39 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:33:41 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:33:41 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-11 07:34:20 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:34:20 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-11 07:34:22 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:34:22 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-11 07:35:12 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:35:12 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-11 07:35:14 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:35:14 --> 404 Page Not Found: Rate/app-assets
ERROR - 2019-06-11 07:35:29 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:35:29 --> 404 Page Not Found: Standard/app-assets
ERROR - 2019-06-11 07:35:43 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:35:43 --> 404 Page Not Found: Standard/app-assets
ERROR - 2019-06-11 07:35:56 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:35:56 --> 404 Page Not Found: Standard/app-assets
ERROR - 2019-06-11 07:35:59 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:35:59 --> 404 Page Not Found: Stream/app-assets
ERROR - 2019-06-11 07:36:04 --> 404 Page Not Found: Stream/quoteinquiry_list.php
ERROR - 2019-06-11 07:36:09 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:36:09 --> 404 Page Not Found: Userrole/app-assets
ERROR - 2019-06-11 07:52:59 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:52:59 --> 404 Page Not Found: Userrole/app-assets
ERROR - 2019-06-11 07:53:04 --> 404 Page Not Found: Questionanswer/Questionansweradd
ERROR - 2019-06-11 07:53:07 --> 404 Page Not Found: Questionanswer/Questionanswerlist
ERROR - 2019-06-11 07:53:59 --> 404 Page Not Found: Questionanswer/Questionanswerlist
ERROR - 2019-06-11 07:56:01 --> Query error: Unknown column 't2.QuestionName' in 'field list' - Invalid query: SELECT `t1`.`QuestionAnswerId`, `t1`.`QuestionId`, `t1`.`QuestionAnswer`, `t1`.`QuestionAnswerRateId`, `t1`.`IsActive`, `t2`.`QuestionName`, `t3`.`AnswerRate`
FROM `tblquestionanswer` as `t1`
LEFT JOIN `tblassesmenttype` as `t2` ON `t1`.`QuestionId` = `t2`.`QuestionId`
LEFT JOIN `tblassesmenttype` as `t3` ON `t1`.`QuestionAnswerRateId` = `t3`.`QuestionAnswerRateId`
ERROR - 2019-06-11 07:56:45 --> Severity: Notice --> Undefined property: stdClass::$AssesmentName C:\xampp\htdocs\mentor\admin\application\views\Questionanswer\QuestionanswerList.php 52
ERROR - 2019-06-11 07:56:45 --> Severity: Notice --> Undefined property: stdClass::$AssesmentName C:\xampp\htdocs\mentor\admin\application\views\Questionanswer\QuestionanswerList.php 52
ERROR - 2019-06-11 07:56:45 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:56:45 --> 404 Page Not Found: Default/images
ERROR - 2019-06-11 07:56:45 --> 404 Page Not Found: Default/images
ERROR - 2019-06-11 07:56:46 --> 404 Page Not Found: Questionanswer/app-assets
ERROR - 2019-06-11 07:59:23 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 07:59:23 --> 404 Page Not Found: Default/images
ERROR - 2019-06-11 07:59:23 --> 404 Page Not Found: Default/images
ERROR - 2019-06-11 07:59:23 --> 404 Page Not Found: Questionanswer/app-assets
ERROR - 2019-06-11 08:00:04 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 08:00:04 --> 404 Page Not Found: Default/images
ERROR - 2019-06-11 08:00:04 --> 404 Page Not Found: Default/images
ERROR - 2019-06-11 08:00:04 --> 404 Page Not Found: Questionanswer/app-assets
ERROR - 2019-06-11 08:00:10 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 08:00:55 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 08:00:55 --> 404 Page Not Found: Questionanswer/app-assets
ERROR - 2019-06-11 08:00:58 --> 404 Page Not Found: Question/Editquestionanswer
ERROR - 2019-06-11 08:08:05 --> 404 Page Not Found: Questionanswer/Questionansweradd
ERROR - 2019-06-11 08:11:41 --> 404 Page Not Found: Questionanswer/Questionansweradd
ERROR - 2019-06-11 08:13:24 --> 404 Page Not Found: Questionanswer/Questionansweradd
ERROR - 2019-06-11 08:15:30 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 08:15:30 --> 404 Page Not Found: Questionanswer/app-assets
ERROR - 2019-06-11 08:15:37 --> 404 Page Not Found: Questionanswer/Questionansweradd
ERROR - 2019-06-11 08:16:00 --> 404 Page Not Found: Questionanswer/Questionansweradd
ERROR - 2019-06-11 08:16:34 --> 404 Page Not Found: Questionanswer/Questionansweradd
ERROR - 2019-06-11 08:16:48 --> 404 Page Not Found: Questionanswer/Questionansweradd
ERROR - 2019-06-11 08:17:14 --> 404 Page Not Found: Questionanswer/Questionansweradd
ERROR - 2019-06-11 08:17:42 --> 404 Page Not Found: Questionanswer/Questionansweradd
ERROR - 2019-06-11 08:17:45 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 08:17:45 --> 404 Page Not Found: Questionanswer/app-assets
ERROR - 2019-06-11 08:17:47 --> 404 Page Not Found: Questionanswer/Questionansweradd
ERROR - 2019-06-11 08:18:28 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 08:20:42 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 08:23:22 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 08:30:13 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 08:30:16 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 08:30:16 --> 404 Page Not Found: Default/images
ERROR - 2019-06-11 08:30:16 --> 404 Page Not Found: Default/images
ERROR - 2019-06-11 08:30:17 --> Severity: Notice --> Undefined variable: questionData C:\xampp\htdocs\mentor\admin\application\views\Questionanswer\QuestionanswerAdd.php 45
ERROR - 2019-06-11 08:30:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mentor\admin\application\views\Questionanswer\QuestionanswerAdd.php 45
ERROR - 2019-06-11 08:30:17 --> Severity: Notice --> Undefined variable: questionrateData C:\xampp\htdocs\mentor\admin\application\views\Questionanswer\QuestionanswerAdd.php 67
ERROR - 2019-06-11 08:30:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mentor\admin\application\views\Questionanswer\QuestionanswerAdd.php 67
ERROR - 2019-06-11 08:30:17 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 08:30:18 --> Severity: Notice --> Undefined variable: questionData C:\xampp\htdocs\mentor\admin\application\views\Questionanswer\QuestionanswerAdd.php 45
ERROR - 2019-06-11 08:30:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mentor\admin\application\views\Questionanswer\QuestionanswerAdd.php 45
ERROR - 2019-06-11 08:30:18 --> Severity: Notice --> Undefined variable: questionrateData C:\xampp\htdocs\mentor\admin\application\views\Questionanswer\QuestionanswerAdd.php 67
ERROR - 2019-06-11 08:30:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mentor\admin\application\views\Questionanswer\QuestionanswerAdd.php 67
ERROR - 2019-06-11 08:31:42 --> Severity: Notice --> Undefined variable: questionData C:\xampp\htdocs\mentor\admin\application\views\Questionanswer\QuestionanswerAdd.php 45
ERROR - 2019-06-11 08:31:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mentor\admin\application\views\Questionanswer\QuestionanswerAdd.php 45
ERROR - 2019-06-11 08:31:42 --> Severity: Notice --> Undefined variable: questionrateData C:\xampp\htdocs\mentor\admin\application\views\Questionanswer\QuestionanswerAdd.php 67
ERROR - 2019-06-11 08:31:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mentor\admin\application\views\Questionanswer\QuestionanswerAdd.php 67
ERROR - 2019-06-11 08:31:42 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 08:31:42 --> Severity: Notice --> Undefined variable: questionData C:\xampp\htdocs\mentor\admin\application\views\Questionanswer\QuestionanswerAdd.php 45
ERROR - 2019-06-11 08:31:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mentor\admin\application\views\Questionanswer\QuestionanswerAdd.php 45
ERROR - 2019-06-11 08:31:42 --> Severity: Notice --> Undefined variable: questionrateData C:\xampp\htdocs\mentor\admin\application\views\Questionanswer\QuestionanswerAdd.php 67
ERROR - 2019-06-11 08:31:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mentor\admin\application\views\Questionanswer\QuestionanswerAdd.php 67
ERROR - 2019-06-11 08:32:08 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 08:32:22 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 08:32:22 --> 404 Page Not Found: Questionanswer/app-assets
ERROR - 2019-06-11 08:34:05 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 08:34:36 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`mentor`.`tblquestionanswer`, CONSTRAINT `tblquestionanswer_ibfk_1` FOREIGN KEY (`QuestionId`) REFERENCES `tblquestion` (`QuestionId`) ON DELETE CASCADE ON UPDATE CASCADE) - Invalid query: INSERT INTO `tblquestionanswer` (`QuestionId`, `QuestionAnswer`, `QuestionAnswerRateId`, `IsActive`, `CreatedBy`) VALUES ('3', 'yyyyyyyyyy', '', '0', 1)
ERROR - 2019-06-11 08:35:36 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 08:36:43 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 08:36:51 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`mentor`.`tblquestionanswer`, CONSTRAINT `tblquestionanswer_ibfk_1` FOREIGN KEY (`QuestionId`) REFERENCES `tblquestion` (`QuestionId`) ON DELETE CASCADE ON UPDATE CASCADE) - Invalid query: INSERT INTO `tblquestionanswer` (`QuestionId`, `QuestionAnswer`, `QuestionAnswerRateId`, `IsActive`, `CreatedBy`) VALUES ('3', 'yyyyyyyyyy', '', '1', 1)
ERROR - 2019-06-11 08:37:43 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 08:37:49 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 08:37:49 --> 404 Page Not Found: Default/images
ERROR - 2019-06-11 08:37:49 --> 404 Page Not Found: Default/images
ERROR - 2019-06-11 08:37:49 --> 404 Page Not Found: Questionanswer/app-assets
ERROR - 2019-06-11 08:38:21 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 08:38:25 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 08:38:26 --> 404 Page Not Found: Questionanswer/app-assets
ERROR - 2019-06-11 09:20:38 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:21:22 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:21:24 --> Query error: Column 'QuestionId' cannot be null - Invalid query: INSERT INTO `tblquestionanswer` (`QuestionId`, `QuestionAnswer`, `QuestionAnswerRateId`, `IsActive`, `CreatedBy`) VALUES (NULL, '', '', '1', 1)
ERROR - 2019-06-11 09:22:42 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:22:42 --> 404 Page Not Found: Questionanswer/app-assets
ERROR - 2019-06-11 09:23:38 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:23:38 --> 404 Page Not Found: Questionanswer/app-assets
ERROR - 2019-06-11 09:24:04 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:24:05 --> 404 Page Not Found: Questionanswer/app-assets
ERROR - 2019-06-11 09:25:06 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:25:06 --> 404 Page Not Found: Questionanswer/app-assets
ERROR - 2019-06-11 09:26:00 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:26:00 --> 404 Page Not Found: Questionanswer/app-assets
ERROR - 2019-06-11 09:26:47 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:26:47 --> 404 Page Not Found: Questionanswer/app-assets
ERROR - 2019-06-11 09:26:49 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:26:49 --> 404 Page Not Found: Questionanswer/app-assets
ERROR - 2019-06-11 09:27:30 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:27:30 --> 404 Page Not Found: Questionanswer/app-assets
ERROR - 2019-06-11 09:29:15 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:29:15 --> 404 Page Not Found: Questionanswer/app-assets
ERROR - 2019-06-11 09:29:55 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:29:55 --> 404 Page Not Found: Questionanswer/app-assets
ERROR - 2019-06-11 09:31:03 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:31:03 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:31:03 --> 404 Page Not Found: Questionanswer/app-assets
ERROR - 2019-06-11 09:31:04 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-11 09:31:04 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-11 09:36:42 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:36:42 --> 404 Page Not Found: Questionanswer/app-assets
ERROR - 2019-06-11 09:38:18 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:38:18 --> 404 Page Not Found: Questionanswer/app-assets
ERROR - 2019-06-11 09:38:18 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-11 09:38:18 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-11 09:39:09 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:39:09 --> 404 Page Not Found: Questionanswer/app-assets
ERROR - 2019-06-11 09:39:09 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-11 09:39:09 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-11 09:39:23 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:39:23 --> 404 Page Not Found: Questionanswer/app-assets
ERROR - 2019-06-11 09:39:23 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-11 09:39:23 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-11 09:39:42 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:39:42 --> 404 Page Not Found: Questionanswer/app-assets
ERROR - 2019-06-11 09:39:42 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-11 09:39:42 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-11 09:41:16 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:41:16 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-11 09:43:26 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:43:26 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-11 09:44:10 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:44:10 --> 404 Page Not Found: Assesment/app-assets
ERROR - 2019-06-11 09:44:24 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:44:24 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-11 09:44:44 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:44:44 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-11 09:44:47 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:44:47 --> 404 Page Not Found: Default/images
ERROR - 2019-06-11 09:44:47 --> 404 Page Not Found: Default/images
ERROR - 2019-06-11 09:44:47 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-11 09:45:15 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:45:15 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-11 09:45:17 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:45:17 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-11 09:45:20 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:45:20 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-11 09:46:06 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:46:06 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-11 09:46:07 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:46:29 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:46:54 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:48:12 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:48:21 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:48:26 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:48:26 --> 404 Page Not Found: Questionanswer/app-assets
ERROR - 2019-06-11 09:50:13 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:50:14 --> 404 Page Not Found: Questionanswer/app-assets
ERROR - 2019-06-11 09:50:43 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:50:43 --> 404 Page Not Found: Questionanswer/app-assets
ERROR - 2019-06-11 09:51:11 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:51:11 --> 404 Page Not Found: Questionanswer/app-assets
ERROR - 2019-06-11 09:51:19 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:51:19 --> 404 Page Not Found: Rate/app-assets
ERROR - 2019-06-11 09:51:21 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:51:21 --> 404 Page Not Found: Rate/app-assets
ERROR - 2019-06-11 09:51:27 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:51:27 --> 404 Page Not Found: Rate/app-assets
ERROR - 2019-06-11 09:52:58 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:52:58 --> 404 Page Not Found: Rate/app-assets
ERROR - 2019-06-11 09:53:00 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:54:00 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:54:01 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-11 09:54:01 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-11 09:54:47 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:54:56 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:54:56 --> 404 Page Not Found: Standard/app-assets
ERROR - 2019-06-11 09:56:14 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:56:14 --> 404 Page Not Found: Standard/app-assets
ERROR - 2019-06-11 09:56:18 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:56:18 --> 404 Page Not Found: Rate/app-assets
ERROR - 2019-06-11 09:56:32 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:56:32 --> 404 Page Not Found: Rate/app-assets
ERROR - 2019-06-11 09:56:39 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:56:39 --> 404 Page Not Found: Standard/app-assets
ERROR - 2019-06-11 09:57:22 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:57:22 --> 404 Page Not Found: Standard/app-assets
ERROR - 2019-06-11 09:57:45 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:57:45 --> 404 Page Not Found: Stream/app-assets
ERROR - 2019-06-11 09:58:23 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 09:58:24 --> 404 Page Not Found: Stream/app-assets
ERROR - 2019-06-11 10:00:18 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 10:00:18 --> 404 Page Not Found: Stream/app-assets
ERROR - 2019-06-11 10:00:23 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 10:00:23 --> 404 Page Not Found: Userrole/app-assets
ERROR - 2019-06-11 10:52:24 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 10:52:25 --> 404 Page Not Found: Default/images
ERROR - 2019-06-11 10:52:25 --> 404 Page Not Found: Default/images
ERROR - 2019-06-11 10:52:25 --> 404 Page Not Found: Standard/app-assets
ERROR - 2019-06-11 10:52:27 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 10:52:27 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-11 10:52:32 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 10:52:32 --> 404 Page Not Found: Rate/app-assets
ERROR - 2019-06-11 10:52:36 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 10:52:36 --> 404 Page Not Found: Standard/app-assets
ERROR - 2019-06-11 10:52:40 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 10:52:40 --> 404 Page Not Found: Question/app-assets
ERROR - 2019-06-11 10:52:45 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 10:52:45 --> 404 Page Not Found: Questionanswer/app-assets
ERROR - 2019-06-11 10:52:47 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 10:54:45 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 10:54:45 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-11 10:54:45 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-11 10:55:08 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 10:55:09 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-11 10:55:09 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-11 10:57:05 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 10:57:05 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-11 10:57:05 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-11 10:58:23 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 10:58:24 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-11 10:58:24 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-11 10:59:04 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 10:59:05 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-11 10:59:05 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-11 11:00:44 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 11:00:45 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-11 11:00:45 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-11 11:00:49 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 11:03:15 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 11:03:15 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-11 11:03:15 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-11 11:06:02 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 11:06:02 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-11 11:06:02 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-11 11:06:04 --> Query error: Column 'QuestionId' cannot be null - Invalid query: INSERT INTO `tblquestionanswer` (`QuestionId`, `QuestionAnswer`, `QuestionAnswerRateId`, `IsActive`, `CreatedBy`) VALUES (NULL, '', NULL, '1', 1)
ERROR - 2019-06-11 11:06:16 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 11:06:17 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-11 11:06:17 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-11 11:07:14 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 11:07:14 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-11 11:07:14 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-11 11:07:53 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 11:07:53 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-11 11:07:53 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-11 11:09:18 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 11:09:18 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-11 11:09:18 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-11 11:16:35 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 11:16:51 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 11:23:25 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 11:25:12 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 11:26:09 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 11:29:54 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 11:39:59 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 11:39:59 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-11 11:40:01 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 11:40:01 --> 404 Page Not Found: Default/images
ERROR - 2019-06-11 11:40:01 --> 404 Page Not Found: Default/images
ERROR - 2019-06-11 11:40:20 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 11:40:45 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 11:42:19 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 11:43:01 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 11:43:26 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 11:43:47 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 11:45:26 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 11:45:30 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 11:46:32 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 11:46:37 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 11:47:34 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 11:47:40 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 11:51:36 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 11:51:43 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 11:55:08 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 11:56:11 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 11:57:31 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 11:57:50 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 12:00:36 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 12:00:41 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 12:01:49 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 12:02:14 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 12:02:27 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 12:02:27 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-11 12:02:27 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-11 12:02:36 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 12:02:42 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 12:05:40 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 12:05:40 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-11 12:05:40 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-11 12:05:46 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 12:07:13 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 12:07:13 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-11 12:07:13 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-11 12:07:35 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 12:07:42 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 12:15:40 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 12:15:45 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 12:16:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 44
ERROR - 2019-06-11 12:17:12 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 12:17:20 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 12:17:47 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 12:17:48 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 12:17:52 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 12:40:52 --> 404 Page Not Found: Blog/index
ERROR - 2019-06-11 12:41:08 --> Severity: Notice --> Undefined variable: Blog C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 17
ERROR - 2019-06-11 12:41:08 --> Severity: Notice --> Undefined variable: ProgramId C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 40
ERROR - 2019-06-11 12:41:08 --> Severity: Notice --> Undefined variable: streamData C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 44
ERROR - 2019-06-11 12:41:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 44
ERROR - 2019-06-11 12:41:08 --> Severity: Notice --> Undefined variable: ProgramName C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 56
ERROR - 2019-06-11 12:41:08 --> Severity: Notice --> Undefined variable: ProgramDescription C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 61
ERROR - 2019-06-11 12:41:08 --> Severity: Notice --> Undefined variable: ProgramPrice C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 67
ERROR - 2019-06-11 12:41:08 --> Severity: Notice --> Undefined variable: IsActive C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 78
ERROR - 2019-06-11 12:41:08 --> Severity: Notice --> Undefined variable: ProgramId C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 122
ERROR - 2019-06-11 12:41:08 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 12:41:08 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-06-11 12:42:10 --> Severity: Notice --> Undefined variable: ProgramId C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 41
ERROR - 2019-06-11 12:42:10 --> Severity: Notice --> Undefined variable: streamData C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 45
ERROR - 2019-06-11 12:42:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 45
ERROR - 2019-06-11 12:42:10 --> Severity: Notice --> Undefined variable: ProgramName C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 57
ERROR - 2019-06-11 12:42:10 --> Severity: Notice --> Undefined variable: ProgramDescription C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 62
ERROR - 2019-06-11 12:42:10 --> Severity: Notice --> Undefined variable: ProgramPrice C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 68
ERROR - 2019-06-11 12:42:10 --> Severity: Notice --> Undefined variable: IsActive C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 79
ERROR - 2019-06-11 12:42:10 --> Severity: Notice --> Undefined variable: ProgramId C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 123
ERROR - 2019-06-11 12:42:10 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 12:42:10 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-06-11 12:48:39 --> Severity: Notice --> Undefined variable: IsActive C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 74
ERROR - 2019-06-11 12:48:39 --> Severity: Notice --> Undefined variable: ProgramId C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 118
ERROR - 2019-06-11 12:48:39 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 12:48:39 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-06-11 12:49:22 --> Severity: Notice --> Undefined variable: IsActive C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 74
ERROR - 2019-06-11 12:49:22 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 12:49:23 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-06-11 12:50:55 --> Severity: Notice --> Undefined variable: IsActive C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 74
ERROR - 2019-06-11 12:50:55 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 12:50:55 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-06-11 12:51:08 --> Severity: Notice --> Undefined variable: IsActive C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 74
ERROR - 2019-06-11 12:51:08 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 12:51:08 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-06-11 12:52:42 --> Severity: Notice --> Undefined variable: IsActive C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 74
ERROR - 2019-06-11 12:52:42 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 12:52:42 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-06-11 12:54:05 --> Severity: Notice --> Undefined variable: IsActive C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 74
ERROR - 2019-06-11 12:54:05 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 12:54:06 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-06-11 12:54:28 --> Severity: Notice --> Undefined variable: IsActive C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 74
ERROR - 2019-06-11 12:54:28 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 12:54:28 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-06-11 12:55:46 --> Severity: Notice --> Undefined variable: IsActive C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 74
ERROR - 2019-06-11 12:55:46 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 12:55:46 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-06-11 12:58:14 --> Severity: Notice --> Undefined variable: IsActive C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 74
ERROR - 2019-06-11 12:58:14 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 12:58:14 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-06-11 13:08:21 --> Severity: Notice --> Undefined variable: IsActive C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 74
ERROR - 2019-06-11 13:08:21 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 13:08:21 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-06-11 13:09:19 --> Severity: Notice --> Undefined variable: IsActive C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 74
ERROR - 2019-06-11 13:09:19 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 13:09:19 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-06-11 13:10:01 --> Severity: Notice --> Undefined variable: IsActive C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 74
ERROR - 2019-06-11 13:10:01 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 13:10:01 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-06-11 13:11:12 --> 404 Page Not Found: Blog/Bloglist
ERROR - 2019-06-11 13:15:30 --> 404 Page Not Found: Blog/Bloglist
ERROR - 2019-06-11 13:15:34 --> 404 Page Not Found: Blog/Bloglist
ERROR - 2019-06-11 13:16:00 --> 404 Page Not Found: Blog/Bloglist
ERROR - 2019-06-11 13:16:01 --> 404 Page Not Found: Blog/Bloglist
ERROR - 2019-06-11 13:16:15 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 13:16:15 --> 404 Page Not Found: Default/images
ERROR - 2019-06-11 13:16:15 --> 404 Page Not Found: Default/images
ERROR - 2019-06-11 13:16:15 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-06-11 13:17:54 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 13:17:54 --> 404 Page Not Found: Default/images
ERROR - 2019-06-11 13:17:54 --> 404 Page Not Found: Default/images
ERROR - 2019-06-11 13:17:54 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-06-11 13:17:57 --> Severity: Notice --> Undefined variable: Blog C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 18
ERROR - 2019-06-11 13:17:57 --> Severity: Notice --> Undefined variable: Blog C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 34
ERROR - 2019-06-11 13:17:57 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 13:17:57 --> Severity: Notice --> Undefined variable: Blog C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 18
ERROR - 2019-06-11 13:17:57 --> Severity: Notice --> Undefined variable: Blog C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 34
ERROR - 2019-06-11 13:18:59 --> Severity: Notice --> Undefined variable: Blog C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 18
ERROR - 2019-06-11 13:18:59 --> Severity: Notice --> Undefined variable: Blog C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 34
ERROR - 2019-06-11 13:18:59 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 13:19:00 --> Severity: Notice --> Undefined variable: Blog C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 18
ERROR - 2019-06-11 13:19:00 --> Severity: Notice --> Undefined variable: Blog C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 34
ERROR - 2019-06-11 13:20:23 --> Severity: Notice --> Undefined variable: Blog C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 18
ERROR - 2019-06-11 13:20:23 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 13:20:24 --> Severity: Notice --> Undefined variable: Blog C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 18
ERROR - 2019-06-11 13:20:53 --> Severity: Notice --> Undefined variable: Blog C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 18
ERROR - 2019-06-11 13:20:53 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 13:20:53 --> Severity: Notice --> Undefined variable: Blog C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 18
ERROR - 2019-06-11 13:21:45 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 13:22:47 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 13:23:10 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 13:23:15 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 13:23:15 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-06-11 13:23:21 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 13:23:26 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 13:23:26 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-06-11 13:38:24 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 13:38:24 --> 404 Page Not Found: Default/images
ERROR - 2019-06-11 13:38:24 --> 404 Page Not Found: Default/images
ERROR - 2019-06-11 13:38:25 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-06-11 13:38:32 --> 404 Page Not Found: Blog/ABlogtadd
ERROR - 2019-06-11 13:38:54 --> Severity: Notice --> Undefined variable: BlogId C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 18
ERROR - 2019-06-11 13:38:54 --> Severity: Notice --> Undefined variable: BlogId C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 38
ERROR - 2019-06-11 13:38:54 --> Severity: Notice --> Undefined variable: FirstName C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 41
ERROR - 2019-06-11 13:38:54 --> Severity: Notice --> Undefined variable: UserImage C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 46
ERROR - 2019-06-11 13:38:54 --> Severity: Notice --> Undefined variable: BlogTitle C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 51
ERROR - 2019-06-11 13:38:54 --> Severity: Notice --> Undefined variable: BlogDescription C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 58
ERROR - 2019-06-11 13:38:54 --> Severity: Notice --> Undefined variable: BlogImage C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 63
ERROR - 2019-06-11 13:38:54 --> Severity: Notice --> Undefined variable: IsActive C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 74
ERROR - 2019-06-11 13:38:54 --> Severity: Notice --> Undefined variable: BlogId C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 118
ERROR - 2019-06-11 13:38:54 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 13:38:54 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-06-11 13:38:59 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 13:38:59 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-06-11 13:39:02 --> Severity: Notice --> Undefined variable: BlogId C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 18
ERROR - 2019-06-11 13:39:02 --> Severity: Notice --> Undefined variable: BlogId C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 38
ERROR - 2019-06-11 13:39:02 --> Severity: Notice --> Undefined variable: FirstName C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 41
ERROR - 2019-06-11 13:39:02 --> Severity: Notice --> Undefined variable: UserImage C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 46
ERROR - 2019-06-11 13:39:02 --> Severity: Notice --> Undefined variable: BlogTitle C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 51
ERROR - 2019-06-11 13:39:02 --> Severity: Notice --> Undefined variable: BlogDescription C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 58
ERROR - 2019-06-11 13:39:02 --> Severity: Notice --> Undefined variable: BlogImage C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 63
ERROR - 2019-06-11 13:39:02 --> Severity: Notice --> Undefined variable: IsActive C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 74
ERROR - 2019-06-11 13:39:02 --> Severity: Notice --> Undefined variable: BlogId C:\xampp\htdocs\mentor\admin\application\views\Blog\BlogAdd.php 118
ERROR - 2019-06-11 13:39:02 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 13:39:02 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-06-11 13:41:16 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 13:41:16 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-06-11 13:41:44 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 13:41:46 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 13:41:57 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 13:47:02 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 13:47:15 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 13:48:04 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 13:48:04 --> 404 Page Not Found: Default/images
ERROR - 2019-06-11 13:48:04 --> 404 Page Not Found: Default/images
ERROR - 2019-06-11 13:48:04 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-06-11 14:18:43 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 14:18:44 --> 404 Page Not Found: Default/images
ERROR - 2019-06-11 14:18:44 --> 404 Page Not Found: Default/images
ERROR - 2019-06-11 14:18:44 --> 404 Page Not Found: Blog/app-assets
ERROR - 2019-06-11 14:18:45 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 14:19:27 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 14:19:48 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-11 14:19:49 --> 404 Page Not Found: Blog/app-assets
