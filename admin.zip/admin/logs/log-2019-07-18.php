<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-18 06:30:28 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 06:30:28 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 06:30:37 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 06:30:38 --> 404 Page Not Found: Home/app-assets
ERROR - 2019-07-18 06:30:48 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 06:30:48 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 06:30:48 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 06:30:48 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 06:47:18 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 06:47:18 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 06:47:18 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 06:47:18 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 06:47:25 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 06:51:51 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 06:51:51 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 06:51:51 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 06:51:51 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 06:51:51 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 06:51:51 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 06:52:04 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 06:52:13 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 06:52:13 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 06:52:13 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 06:52:13 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 06:55:21 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 06:55:22 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 06:55:22 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 06:55:22 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 06:55:22 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 06:55:22 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 06:55:28 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 06:55:28 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 06:55:44 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 06:55:44 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 06:55:44 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 06:55:44 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 06:55:44 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 06:55:44 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 06:55:55 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 06:55:55 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 06:55:55 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 06:55:55 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 06:55:55 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 06:55:55 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 06:55:59 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 06:55:59 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 06:56:02 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 06:56:02 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 06:56:02 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 06:56:02 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 06:56:02 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 06:56:02 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 06:57:24 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 06:57:24 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 06:57:24 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 06:57:24 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 06:57:24 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 06:57:24 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 06:57:54 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 06:57:54 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 06:57:54 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 06:57:54 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 06:57:54 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 06:57:54 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 06:58:15 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 06:58:15 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 06:58:15 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 06:58:15 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 06:58:15 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 06:58:15 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 06:58:24 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 06:58:25 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 06:58:25 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 06:58:25 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 06:58:25 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 06:58:25 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 06:58:47 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 06:58:47 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 06:58:47 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 06:58:47 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 06:58:47 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 06:58:47 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 06:58:54 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 06:58:54 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 06:59:16 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 06:59:16 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 06:59:16 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 06:59:16 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 06:59:16 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 06:59:16 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 06:59:55 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 07:00:05 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 07:00:05 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 07:00:05 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 07:00:05 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 07:34:52 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 07:34:53 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 07:35:17 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 51
ERROR - 2019-07-18 07:35:17 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 57
ERROR - 2019-07-18 07:35:17 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 07:35:18 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 07:35:18 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 07:35:18 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 07:56:26 --> Severity: Notice --> Undefined variable: PlanlayoutId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 36
ERROR - 2019-07-18 07:56:26 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 51
ERROR - 2019-07-18 07:56:26 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 57
ERROR - 2019-07-18 07:56:26 --> Severity: Notice --> Undefined variable: PlanlayoutImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 142
ERROR - 2019-07-18 07:56:26 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 07:56:26 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 07:56:26 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 07:56:26 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 08:09:04 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 51
ERROR - 2019-07-18 08:09:04 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 57
ERROR - 2019-07-18 08:09:04 --> Severity: Notice --> Undefined variable: PlanlayoutImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 142
ERROR - 2019-07-18 08:09:04 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:09:04 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 08:09:04 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 08:09:04 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 08:09:06 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:09:06 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 08:09:06 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 08:09:38 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:09:38 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 08:09:38 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 08:09:38 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 08:09:38 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 08:09:39 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:09:44 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:09:44 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 08:10:19 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:10:19 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 08:10:37 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:10:37 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 08:10:37 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 08:10:37 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 08:10:37 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 08:10:37 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 08:10:49 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:10:49 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 08:10:49 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 08:10:49 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 08:10:49 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 08:10:49 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 08:10:51 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:11:02 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:11:02 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 08:11:02 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 08:11:04 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:11:04 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 08:11:04 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 08:11:13 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:11:13 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 08:11:13 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 08:11:13 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 08:11:15 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 51
ERROR - 2019-07-18 08:11:15 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 57
ERROR - 2019-07-18 08:11:15 --> Severity: Notice --> Undefined variable: PlanlayoutImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 142
ERROR - 2019-07-18 08:11:15 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:11:15 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 51
ERROR - 2019-07-18 08:11:15 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 57
ERROR - 2019-07-18 08:11:15 --> Severity: Notice --> Undefined variable: PlanlayoutImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 142
ERROR - 2019-07-18 08:11:26 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:11:28 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 51
ERROR - 2019-07-18 08:11:28 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 57
ERROR - 2019-07-18 08:11:28 --> Severity: Notice --> Undefined variable: PlanlayoutImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 142
ERROR - 2019-07-18 08:11:28 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:11:28 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 51
ERROR - 2019-07-18 08:11:28 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 57
ERROR - 2019-07-18 08:11:28 --> Severity: Notice --> Undefined variable: PlanlayoutImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 142
ERROR - 2019-07-18 08:11:29 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:11:30 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 51
ERROR - 2019-07-18 08:11:30 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 57
ERROR - 2019-07-18 08:11:30 --> Severity: Notice --> Undefined variable: PlanlayoutImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 142
ERROR - 2019-07-18 08:11:30 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:11:30 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 51
ERROR - 2019-07-18 08:11:30 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 57
ERROR - 2019-07-18 08:11:30 --> Severity: Notice --> Undefined variable: PlanlayoutImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 142
ERROR - 2019-07-18 08:14:12 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 51
ERROR - 2019-07-18 08:14:12 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 57
ERROR - 2019-07-18 08:14:12 --> Severity: Notice --> Undefined variable: PlanlayoutImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 142
ERROR - 2019-07-18 08:14:12 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:14:13 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 08:14:13 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 51
ERROR - 2019-07-18 08:14:13 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 57
ERROR - 2019-07-18 08:14:13 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 08:14:13 --> Severity: Notice --> Undefined variable: PlanlayoutImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 142
ERROR - 2019-07-18 08:15:37 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 51
ERROR - 2019-07-18 08:15:37 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 57
ERROR - 2019-07-18 08:15:37 --> Severity: Notice --> Undefined variable: PlanlayoutImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 142
ERROR - 2019-07-18 08:15:37 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:15:37 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 08:15:37 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 51
ERROR - 2019-07-18 08:15:37 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 08:15:37 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 57
ERROR - 2019-07-18 08:15:37 --> Severity: Notice --> Undefined variable: PlanlayoutImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 142
ERROR - 2019-07-18 08:18:15 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 51
ERROR - 2019-07-18 08:18:15 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 57
ERROR - 2019-07-18 08:18:15 --> Severity: Notice --> Undefined variable: PlanlayoutImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 142
ERROR - 2019-07-18 08:18:15 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:18:16 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 08:18:16 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 08:18:16 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 51
ERROR - 2019-07-18 08:18:16 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 57
ERROR - 2019-07-18 08:18:16 --> Severity: Notice --> Undefined variable: PlanlayoutImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 142
ERROR - 2019-07-18 08:18:22 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 51
ERROR - 2019-07-18 08:18:22 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 57
ERROR - 2019-07-18 08:18:22 --> Severity: Notice --> Undefined variable: PlanlayoutImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 142
ERROR - 2019-07-18 08:18:22 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:18:22 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 08:18:22 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 08:18:22 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 51
ERROR - 2019-07-18 08:18:22 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 57
ERROR - 2019-07-18 08:18:22 --> Severity: Notice --> Undefined variable: PlanlayoutImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 142
ERROR - 2019-07-18 08:18:32 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 51
ERROR - 2019-07-18 08:18:32 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 57
ERROR - 2019-07-18 08:18:32 --> Severity: Notice --> Undefined variable: PlanlayoutImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 142
ERROR - 2019-07-18 08:18:32 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:18:32 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 08:18:32 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 08:18:32 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 51
ERROR - 2019-07-18 08:18:32 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 57
ERROR - 2019-07-18 08:18:32 --> Severity: Notice --> Undefined variable: PlanlayoutImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 142
ERROR - 2019-07-18 08:19:34 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 51
ERROR - 2019-07-18 08:19:34 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 57
ERROR - 2019-07-18 08:19:34 --> Severity: Notice --> Undefined variable: PlanlayoutImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 142
ERROR - 2019-07-18 08:19:34 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:19:34 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 08:19:34 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 08:19:34 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 51
ERROR - 2019-07-18 08:19:34 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 57
ERROR - 2019-07-18 08:19:34 --> Severity: Notice --> Undefined variable: PlanlayoutImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 142
ERROR - 2019-07-18 08:21:02 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 51
ERROR - 2019-07-18 08:21:02 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 57
ERROR - 2019-07-18 08:21:02 --> Severity: Notice --> Undefined variable: PlanlayoutImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 142
ERROR - 2019-07-18 08:21:02 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:21:02 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 08:21:02 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 51
ERROR - 2019-07-18 08:21:02 --> Severity: Notice --> Undefined variable: LogoImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 57
ERROR - 2019-07-18 08:21:02 --> Severity: Notice --> Undefined variable: PlanlayoutImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 142
ERROR - 2019-07-18 08:21:03 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 08:24:01 --> Severity: Notice --> Undefined property: stdClass::$SpecificationId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 43
ERROR - 2019-07-18 08:24:01 --> Severity: Notice --> Undefined property: stdClass::$SpecificationId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 43
ERROR - 2019-07-18 08:24:01 --> Severity: Notice --> Undefined property: stdClass::$SpecificationId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 43
ERROR - 2019-07-18 08:24:01 --> Severity: Notice --> Undefined variable: PlanlayoutImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 142
ERROR - 2019-07-18 08:24:01 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:24:01 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 08:24:01 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 08:24:01 --> Severity: Notice --> Undefined property: stdClass::$SpecificationId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 43
ERROR - 2019-07-18 08:24:01 --> Severity: Notice --> Undefined property: stdClass::$SpecificationId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 43
ERROR - 2019-07-18 08:24:01 --> Severity: Notice --> Undefined property: stdClass::$SpecificationId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 43
ERROR - 2019-07-18 08:24:01 --> Severity: Notice --> Undefined variable: PlanlayoutImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 142
ERROR - 2019-07-18 08:25:47 --> Severity: Notice --> Undefined property: stdClass::$SpecificationId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 43
ERROR - 2019-07-18 08:25:47 --> Severity: Notice --> Undefined property: stdClass::$SpecificationId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 43
ERROR - 2019-07-18 08:25:47 --> Severity: Notice --> Undefined property: stdClass::$SpecificationId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 43
ERROR - 2019-07-18 08:25:47 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:25:47 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 08:25:47 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 08:25:47 --> Severity: Notice --> Undefined property: stdClass::$SpecificationId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 43
ERROR - 2019-07-18 08:25:47 --> Severity: Notice --> Undefined property: stdClass::$SpecificationId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 43
ERROR - 2019-07-18 08:25:47 --> Severity: Notice --> Undefined property: stdClass::$SpecificationId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 43
ERROR - 2019-07-18 08:26:29 --> Severity: Notice --> Undefined property: stdClass::$SpecificationId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 43
ERROR - 2019-07-18 08:26:29 --> Severity: Notice --> Undefined property: stdClass::$SpecificationId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 43
ERROR - 2019-07-18 08:26:29 --> Severity: Notice --> Undefined property: stdClass::$SpecificationId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 43
ERROR - 2019-07-18 08:26:30 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:26:30 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 08:26:30 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 08:26:30 --> Severity: Notice --> Undefined property: stdClass::$SpecificationId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 43
ERROR - 2019-07-18 08:26:30 --> Severity: Notice --> Undefined property: stdClass::$SpecificationId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 43
ERROR - 2019-07-18 08:26:30 --> Severity: Notice --> Undefined property: stdClass::$SpecificationId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 43
ERROR - 2019-07-18 08:27:11 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:27:12 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 08:27:12 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 08:27:25 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:27:25 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 08:27:25 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 08:29:46 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:29:46 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 08:29:46 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 08:29:59 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:29:59 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 08:29:59 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 08:34:49 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:34:49 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 08:34:49 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 08:37:09 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:37:09 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 08:37:09 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 08:37:23 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:37:24 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 08:37:24 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 08:37:36 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:37:36 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 08:37:36 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 08:38:57 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:39:36 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:39:37 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 08:39:37 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 08:39:48 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:39:48 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 08:39:48 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 08:40:12 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:40:12 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 08:40:12 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 08:46:36 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:46:36 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 08:46:36 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 08:51:42 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:51:42 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 08:51:42 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 08:56:11 --> Severity: error --> Exception: Call to undefined method Project_model::getspecificaftion() C:\xampp\htdocs\realestate\admin\application\controllers\Project.php 432
ERROR - 2019-07-18 08:56:43 --> Severity: Notice --> Undefined property: stdClass::$planlayout_image C:\xampp\htdocs\realestate\admin\application\views\Project\List_specification.php 58
ERROR - 2019-07-18 08:56:43 --> Severity: Notice --> Undefined property: stdClass::$planlayout_id C:\xampp\htdocs\realestate\admin\application\views\Project\List_specification.php 77
ERROR - 2019-07-18 08:56:43 --> Severity: Notice --> Undefined property: stdClass::$planlayout_id C:\xampp\htdocs\realestate\admin\application\views\Project\List_specification.php 78
ERROR - 2019-07-18 08:56:43 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:56:43 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 08:56:43 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 08:56:43 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 08:56:43 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 08:56:43 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 08:57:50 --> Severity: Notice --> Undefined property: stdClass::$planlayout_id C:\xampp\htdocs\realestate\admin\application\views\Project\List_specification.php 77
ERROR - 2019-07-18 08:57:50 --> Severity: Notice --> Undefined property: stdClass::$planlayout_id C:\xampp\htdocs\realestate\admin\application\views\Project\List_specification.php 78
ERROR - 2019-07-18 08:57:50 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:57:50 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 08:57:50 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 08:57:50 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 08:57:50 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 08:57:50 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 08:58:48 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:58:48 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 08:58:48 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 08:58:48 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 08:58:48 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 08:58:48 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 08:58:50 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:58:50 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 08:58:50 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 08:58:50 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 08:58:50 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 08:58:50 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 08:59:01 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:59:01 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 08:59:01 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 08:59:01 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 08:59:01 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 08:59:01 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 08:59:21 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 08:59:22 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 08:59:22 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 08:59:22 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 08:59:22 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 08:59:22 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 08:59:24 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 09:00:23 --> Severity: Notice --> Undefined variable: PlanlayoutId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 18
ERROR - 2019-07-18 09:00:23 --> Severity: Notice --> Undefined variable: PlanlayoutId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 39
ERROR - 2019-07-18 09:00:23 --> Severity: Notice --> Undefined variable: PlanlayoutImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 58
ERROR - 2019-07-18 09:00:23 --> Severity: Notice --> Undefined variable: PlanlayoutImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 64
ERROR - 2019-07-18 09:00:23 --> Severity: Notice --> Undefined variable: PlanlayoutId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 111
ERROR - 2019-07-18 09:00:23 --> Severity: Notice --> Undefined variable: PlanlayoutImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 149
ERROR - 2019-07-18 09:00:23 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 09:00:23 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 09:00:23 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 09:00:23 --> Severity: Notice --> Undefined variable: PlanlayoutId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 18
ERROR - 2019-07-18 09:00:23 --> Severity: Notice --> Undefined variable: PlanlayoutId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 39
ERROR - 2019-07-18 09:00:23 --> Severity: Notice --> Undefined variable: PlanlayoutImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 58
ERROR - 2019-07-18 09:00:23 --> Severity: Notice --> Undefined variable: PlanlayoutImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 64
ERROR - 2019-07-18 09:00:23 --> Severity: Notice --> Undefined variable: PlanlayoutId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 111
ERROR - 2019-07-18 09:00:23 --> Severity: Notice --> Undefined variable: PlanlayoutImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 149
ERROR - 2019-07-18 09:01:55 --> Severity: Notice --> Undefined variable: PlanlayoutId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 18
ERROR - 2019-07-18 09:01:55 --> Severity: Notice --> Undefined variable: PlanlayoutId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 39
ERROR - 2019-07-18 09:01:55 --> Severity: Notice --> Undefined variable: PlanlayoutImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 58
ERROR - 2019-07-18 09:01:55 --> Severity: Notice --> Undefined variable: PlanlayoutImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 64
ERROR - 2019-07-18 09:01:55 --> Severity: Notice --> Undefined variable: PlanlayoutId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 111
ERROR - 2019-07-18 09:01:55 --> Severity: Notice --> Undefined variable: PlanlayoutImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 149
ERROR - 2019-07-18 09:01:55 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 09:01:55 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 09:01:55 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 09:01:55 --> Severity: Notice --> Undefined variable: PlanlayoutId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 18
ERROR - 2019-07-18 09:01:55 --> Severity: Notice --> Undefined variable: PlanlayoutId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 39
ERROR - 2019-07-18 09:01:55 --> Severity: Notice --> Undefined variable: PlanlayoutImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 58
ERROR - 2019-07-18 09:01:55 --> Severity: Notice --> Undefined variable: PlanlayoutImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 64
ERROR - 2019-07-18 09:01:55 --> Severity: Notice --> Undefined variable: PlanlayoutId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 111
ERROR - 2019-07-18 09:01:55 --> Severity: Notice --> Undefined variable: PlanlayoutImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 149
ERROR - 2019-07-18 09:02:22 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 09:02:23 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 09:02:23 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 09:04:07 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 09:04:07 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 09:04:07 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 09:04:28 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 09:04:28 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 09:04:28 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 09:06:47 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 09:06:47 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 09:06:47 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 09:06:47 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 09:06:51 --> Severity: Notice --> Undefined variable: SpecificationTitle C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 49
ERROR - 2019-07-18 09:06:51 --> Severity: Notice --> Undefined variable: SpecificationDesc C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 53
ERROR - 2019-07-18 09:06:51 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 09:06:51 --> Severity: Notice --> Undefined variable: SpecificationTitle C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 49
ERROR - 2019-07-18 09:06:51 --> Severity: Notice --> Undefined variable: SpecificationDesc C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 53
ERROR - 2019-07-18 09:07:55 --> Severity: Notice --> Undefined variable: SpecificationTitle C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 49
ERROR - 2019-07-18 09:07:55 --> Severity: Notice --> Undefined variable: SpecificationDesc C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 53
ERROR - 2019-07-18 09:07:55 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 09:07:55 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 09:07:55 --> Severity: Notice --> Undefined variable: SpecificationTitle C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 49
ERROR - 2019-07-18 09:07:55 --> Severity: Notice --> Undefined variable: SpecificationDesc C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 53
ERROR - 2019-07-18 09:07:55 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 09:09:10 --> Severity: Notice --> Undefined variable: SpecificationTitle C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 49
ERROR - 2019-07-18 09:09:10 --> Severity: Notice --> Undefined variable: SpecificationDesc C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 53
ERROR - 2019-07-18 09:09:10 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 09:09:10 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 09:09:10 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 09:09:10 --> Severity: Notice --> Undefined variable: SpecificationTitle C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 49
ERROR - 2019-07-18 09:09:10 --> Severity: Notice --> Undefined variable: SpecificationDesc C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 53
ERROR - 2019-07-18 09:09:27 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 09:10:23 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 09:10:23 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 09:10:23 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 09:10:23 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 09:10:23 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 09:10:23 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 09:10:25 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 09:10:27 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 09:10:28 --> Severity: Notice --> Undefined variable: SpecificationTitle C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 49
ERROR - 2019-07-18 09:10:28 --> Severity: Notice --> Undefined variable: SpecificationDesc C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 53
ERROR - 2019-07-18 09:10:28 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 09:10:28 --> Severity: Notice --> Undefined variable: SpecificationTitle C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 49
ERROR - 2019-07-18 09:10:28 --> Severity: Notice --> Undefined variable: SpecificationDesc C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 53
ERROR - 2019-07-18 09:10:50 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 09:10:51 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 09:10:51 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 09:10:54 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 09:10:55 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 09:10:55 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 09:11:01 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 09:11:44 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 09:11:44 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 09:11:44 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 09:11:45 --> Severity: Notice --> Undefined variable: spectitle C:\xampp\htdocs\realestate\admin\application\views\Project\List_specification.php 56
ERROR - 2019-07-18 09:11:45 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 09:11:46 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 09:11:46 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 09:11:46 --> Severity: Notice --> Undefined variable: spectitle C:\xampp\htdocs\realestate\admin\application\views\Project\List_specification.php 56
ERROR - 2019-07-18 09:12:13 --> Severity: Notice --> Undefined variable: spectitle C:\xampp\htdocs\realestate\admin\application\views\Project\List_specification.php 56
ERROR - 2019-07-18 09:12:13 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 09:12:14 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 09:12:14 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 09:12:14 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 09:12:14 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 09:12:14 --> Severity: Notice --> Undefined variable: spectitle C:\xampp\htdocs\realestate\admin\application\views\Project\List_specification.php 56
ERROR - 2019-07-18 09:12:31 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 09:12:31 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 09:12:31 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 09:12:31 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 09:12:31 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 09:12:37 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 09:12:37 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 09:12:37 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 09:12:37 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 09:12:37 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 09:12:40 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 09:13:08 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 09:13:08 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 09:13:08 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 09:13:08 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 09:13:12 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 09:13:52 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 09:13:53 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 09:13:53 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 09:13:53 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 09:14:02 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 09:14:24 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 09:14:24 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 09:14:24 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 09:14:24 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 09:14:29 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 09:31:42 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 09:31:42 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 09:31:42 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 09:31:48 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 09:31:48 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 09:31:48 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 09:31:50 --> Severity: Notice --> Undefined variable: logo_image C:\xampp\htdocs\realestate\admin\application\views\Project\Add_specification.php 65
ERROR - 2019-07-18 09:31:50 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 09:31:55 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 09:31:55 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 09:31:55 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 09:35:42 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 09:35:42 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 09:35:42 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 09:35:42 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 09:37:09 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 09:37:09 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 09:37:09 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 09:37:09 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 09:37:09 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 09:37:09 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 09:37:17 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 09:37:46 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 09:37:46 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 09:37:46 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 09:37:46 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 09:37:54 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 09:38:16 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 09:38:17 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 09:38:17 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 09:38:17 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 10:50:54 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 10:54:12 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 10:54:12 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 10:54:12 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 10:54:12 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 11:00:38 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 11:00:53 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 11:00:53 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 11:00:53 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 11:00:53 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 11:06:38 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 11:06:38 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 11:06:38 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 11:06:38 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 11:06:38 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 11:06:38 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 11:09:09 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 11:09:09 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 11:09:09 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 11:09:10 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 11:09:10 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 11:09:10 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 11:09:34 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 11:09:35 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 11:09:35 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 11:09:35 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 11:10:22 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 11:10:22 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 11:10:22 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 11:10:22 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 11:10:52 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 11:10:52 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 11:10:52 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 11:10:52 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 11:26:30 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; Api has a deprecated constructor C:\xampp\htdocs\realestate\admin\application\controllers\Api.php 6
ERROR - 2019-07-18 11:27:42 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; Api has a deprecated constructor C:\xampp\htdocs\realestate\admin\application\controllers\Api.php 6
ERROR - 2019-07-18 11:28:05 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; Api has a deprecated constructor C:\xampp\htdocs\realestate\admin\application\controllers\Api.php 7
ERROR - 2019-07-18 11:28:16 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; Api has a deprecated constructor C:\xampp\htdocs\realestate\admin\application\controllers\Api.php 7
ERROR - 2019-07-18 11:29:45 --> Severity: error --> Exception: syntax error, unexpected 'require' (T_REQUIRE) C:\xampp\htdocs\realestate\admin\application\controllers\Api.php 5
ERROR - 2019-07-18 11:32:49 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; Api has a deprecated constructor C:\xampp\htdocs\realestate\admin\application\controllers\Api.php 7
ERROR - 2019-07-18 11:32:50 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; Api has a deprecated constructor C:\xampp\htdocs\realestate\admin\application\controllers\Api.php 7
ERROR - 2019-07-18 11:32:50 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; Api has a deprecated constructor C:\xampp\htdocs\realestate\admin\application\controllers\Api.php 7
ERROR - 2019-07-18 11:32:56 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; Api has a deprecated constructor C:\xampp\htdocs\realestate\admin\application\controllers\Api.php 7
ERROR - 2019-07-18 11:33:20 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; Api has a deprecated constructor C:\xampp\htdocs\realestate\admin\application\controllers\Api.php 7
ERROR - 2019-07-18 11:33:44 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; Api has a deprecated constructor C:\xampp\htdocs\realestate\admin\application\controllers\Api.php 6
ERROR - 2019-07-18 11:33:44 --> Unable to load the requested class: Format
ERROR - 2019-07-18 11:34:47 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; Api has a deprecated constructor C:\xampp\htdocs\realestate\admin\application\controllers\Api.php 6
ERROR - 2019-07-18 11:34:47 --> Unable to load the requested class: Format
ERROR - 2019-07-18 11:35:06 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; Api has a deprecated constructor C:\xampp\htdocs\realestate\admin\application\controllers\Api.php 6
ERROR - 2019-07-18 11:36:45 --> Unable to load the requested class: Format
ERROR - 2019-07-18 11:37:33 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; Api_model has a deprecated constructor C:\xampp\htdocs\realestate\admin\application\models\Api_model.php 2
ERROR - 2019-07-18 11:37:33 --> Severity: error --> Exception: Unable to locate the model you have specified: Home_model C:\xampp\htdocs\realestate\admin\system\core\Loader.php 348
ERROR - 2019-07-18 11:40:29 --> Severity: error --> Exception: Unable to locate the model you have specified: Home_model C:\xampp\htdocs\realestate\admin\system\core\Loader.php 348
ERROR - 2019-07-18 12:41:17 --> Query error: Unknown column 'email' in 'where clause' - Invalid query: select EmailAddress from tbluser where email = 'binny@yopmail.com'
ERROR - 2019-07-18 12:45:16 --> Query error: Unknown column 'full_name' in 'field list' - Invalid query: INSERT INTO `tbluser` (`full_name`, `email`, `mobileno`, `password`) VALUES ('binny', 'binny@yopmail.com', '1234567890', '827ccb0eea8a706c4c34a16891f84e7b')
ERROR - 2019-07-18 12:46:56 --> Query error: Unknown column 'user_id' in 'where clause' - Invalid query: SELECT *
FROM `tbluser`
WHERE `user_id` = 4
ERROR - 2019-07-18 12:56:35 --> Query error: Unknown column 'UserId' in 'where clause' - Invalid query: SELECT *
FROM `tbluser`
WHERE `UserId` = 5
ERROR - 2019-07-18 13:21:05 --> Severity: Notice --> Undefined variable: unhcr_no C:\xampp\htdocs\realestate\admin\application\models\Api_model.php 3820
ERROR - 2019-07-18 13:21:05 --> Query error: Unknown column 'password' in 'where clause' - Invalid query: SELECT *
FROM `tbluser`
WHERE `UserContact` IS NULL
AND `password` = '827ccb0eea8a706c4c34a16891f84e7b'
ERROR - 2019-07-18 13:21:39 --> Severity: Notice --> Undefined variable: unhcr_no C:\xampp\htdocs\realestate\admin\application\models\Api_model.php 3820
ERROR - 2019-07-18 13:21:39 --> Query error: Unknown column 'password' in 'where clause' - Invalid query: SELECT *
FROM `tbluser`
WHERE `UserContact` IS NULL
AND `password` = '827ccb0eea8a706c4c34a16891f84e7b'
ERROR - 2019-07-18 13:21:55 --> Query error: Unknown column 'password' in 'where clause' - Invalid query: SELECT *
FROM `tbluser`
WHERE `UserContact` = '1234567890'
AND `password` = '827ccb0eea8a706c4c34a16891f84e7b'
ERROR - 2019-07-18 13:22:17 --> Severity: Notice --> Undefined index: UserId C:\xampp\htdocs\realestate\admin\application\models\Api_model.php 3838
ERROR - 2019-07-18 13:28:21 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 13:28:21 --> 404 Page Not Found: Upload/projectlogo
ERROR - 2019-07-18 13:28:22 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 13:28:22 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 13:28:22 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 13:28:22 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 13:28:23 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 13:32:08 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 13:32:08 --> 404 Page Not Found: Upload/projectlogo
ERROR - 2019-07-18 13:32:08 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 13:32:08 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 13:32:08 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 13:32:12 --> 404 Page Not Found: Upload/projectlogo
ERROR - 2019-07-18 13:32:12 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 13:34:12 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 13:34:12 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 13:34:15 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 13:34:16 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 13:34:16 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 13:34:16 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-18 13:34:16 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 13:34:16 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 14:16:33 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 14:16:34 --> 404 Page Not Found: Admin/app-assets
ERROR - 2019-07-18 14:16:34 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 14:16:34 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 14:20:31 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 14:20:31 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 14:20:31 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 14:20:58 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 14:20:58 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 14:20:58 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 14:21:00 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 14:21:00 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 14:21:00 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 14:21:28 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 14:21:29 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 14:21:29 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 14:21:52 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 14:21:54 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 14:21:54 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 14:21:54 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 14:21:55 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 14:21:55 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 14:21:55 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 14:22:09 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 14:22:10 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 14:22:10 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 14:22:11 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 14:22:11 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 14:22:11 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 14:22:50 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 14:22:51 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 14:22:51 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 14:23:14 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 14:23:15 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 14:23:15 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 14:23:30 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 14:23:30 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 14:23:58 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 14:23:58 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 14:25:59 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 14:25:59 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 14:27:59 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 14:27:59 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 14:29:38 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 14:29:38 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 14:31:14 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 14:31:14 --> 404 Page Not Found: Home/app-assets
ERROR - 2019-07-18 14:31:55 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 14:31:55 --> 404 Page Not Found: Home/app-assets
ERROR - 2019-07-18 14:33:10 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 14:33:48 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 14:33:48 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 14:33:58 --> 404 Page Not Found: Register-simplehtml/index
ERROR - 2019-07-18 14:34:23 --> 404 Page Not Found: Register-simplehtml/index
ERROR - 2019-07-18 14:34:38 --> 404 Page Not Found: Register-simplehtml/index
ERROR - 2019-07-18 14:34:39 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 14:34:39 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 14:34:40 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 14:34:40 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 14:35:03 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 14:35:03 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 14:35:56 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 14:36:11 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 14:36:11 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 14:36:19 --> 404 Page Not Found: Admin/index
ERROR - 2019-07-18 14:36:34 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 14:36:34 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 14:36:53 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 14:36:53 --> 404 Page Not Found: Home/app-assets
ERROR - 2019-07-18 14:36:56 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 14:36:56 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 14:36:56 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 14:36:56 --> 404 Page Not Found: Admin/app-assets
ERROR - 2019-07-18 14:37:14 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 14:39:59 --> 404 Page Not Found: Default/images
ERROR - 2019-07-18 14:40:42 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 14:40:42 --> 404 Page Not Found: Home/app-assets
ERROR - 2019-07-18 14:41:32 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 14:41:32 --> 404 Page Not Found: Home/app-assets
ERROR - 2019-07-18 14:41:32 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 14:41:32 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 14:42:07 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 14:42:07 --> 404 Page Not Found: Home/app-assets
ERROR - 2019-07-18 14:42:07 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 14:42:07 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 14:43:10 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-18 14:43:10 --> 404 Page Not Found: Home/app-assets
ERROR - 2019-07-18 14:43:10 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 14:43:11 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 14:43:41 --> 404 Page Not Found: Images/logo
ERROR - 2019-07-18 14:43:42 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 14:43:42 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 14:44:12 --> 404 Page Not Found: Images/logo
ERROR - 2019-07-18 14:44:13 --> 404 Page Not Found: Images/logo
ERROR - 2019-07-18 14:44:13 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 14:44:13 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 14:44:44 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 14:44:44 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 14:45:06 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 14:45:06 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 14:45:59 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 14:45:59 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 14:51:22 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 14:51:22 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 14:52:44 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 14:52:44 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 14:52:56 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 14:52:56 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 14:53:33 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 14:53:33 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 14:53:57 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-18 14:58:30 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-18 14:58:30 --> 404 Page Not Found: Favicon/favicon.ico
