<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-18 06:41:53 --> Severity: Notice --> Use of undefined constant VIEWPATH - assumed 'VIEWPATH' C:\xampp\htdocs\mentor\admin\system\core\Common.php 196
ERROR - 2019-06-18 06:41:53 --> Severity: Notice --> Use of undefined constant VIEWPATH - assumed 'VIEWPATH' C:\xampp\htdocs\mentor\admin\system\core\Exceptions.php 162
ERROR - 2019-06-18 06:41:53 --> Severity: Warning --> include(VIEWPATHerrors\html\error_general.php): failed to open stream: No such file or directory C:\xampp\htdocs\mentor\admin\system\core\Exceptions.php 182
ERROR - 2019-06-18 06:41:53 --> Severity: Warning --> include(): Failed opening 'VIEWPATHerrors\html\error_general.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\mentor\admin\system\core\Exceptions.php 182
ERROR - 2019-06-18 10:51:11 --> 404 Page Not Found: Ogin/index
ERROR - 2019-06-18 10:51:15 --> Severity: error --> Exception: syntax error, unexpected '"IsActive"' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 25
ERROR - 2019-06-18 10:51:18 --> Severity: error --> Exception: syntax error, unexpected '"IsActive"' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 25
ERROR - 2019-06-18 10:52:19 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-18 10:52:19 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-18 10:52:49 --> Severity: Notice --> Undefined variable: session C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 45
ERROR - 2019-06-18 10:52:58 --> Severity: Notice --> Undefined variable: session C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 45
ERROR - 2019-06-18 10:53:22 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-18 10:53:22 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-18 10:54:46 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-18 10:54:46 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-18 10:58:04 --> Severity: Notice --> Undefined property: stdClass::$EmailAddress C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 34
ERROR - 2019-06-18 10:58:04 --> 404 Page Not Found: Default/images
ERROR - 2019-06-18 10:58:04 --> 404 Page Not Found: Default/images
ERROR - 2019-06-18 10:58:05 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-18 10:58:05 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-18 10:58:32 --> 404 Page Not Found: Default/images
ERROR - 2019-06-18 10:58:32 --> 404 Page Not Found: Default/images
ERROR - 2019-06-18 10:58:32 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-18 10:58:32 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-18 10:58:44 --> 404 Page Not Found: Default/images
ERROR - 2019-06-18 10:58:44 --> 404 Page Not Found: Default/images
ERROR - 2019-06-18 10:58:44 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-18 10:58:45 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-18 11:00:04 --> 404 Page Not Found: Default/images
ERROR - 2019-06-18 11:00:04 --> 404 Page Not Found: Default/images
ERROR - 2019-06-18 11:00:04 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-18 11:00:04 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-18 11:00:57 --> 404 Page Not Found: Default/images
ERROR - 2019-06-18 11:00:57 --> 404 Page Not Found: Default/images
ERROR - 2019-06-18 11:00:57 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-18 11:00:57 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-18 11:01:03 --> 404 Page Not Found: Logout/index
ERROR - 2019-06-18 11:01:52 --> Severity: Notice --> Undefined property: stdClass::$EmailAddress C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 34
ERROR - 2019-06-18 11:02:29 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-18 11:02:29 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-18 11:02:36 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-18 11:02:36 --> 404 Page Not Found: Default/images
ERROR - 2019-06-18 11:02:36 --> 404 Page Not Found: Default/images
ERROR - 2019-06-18 11:02:36 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-18 11:02:36 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-18 11:02:36 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-18 11:08:14 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-18 11:08:14 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-18 11:08:31 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-18 11:08:32 --> 404 Page Not Found: Default/images
ERROR - 2019-06-18 11:08:32 --> 404 Page Not Found: Default/images
ERROR - 2019-06-18 11:08:32 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-18 11:09:05 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-18 11:09:06 --> 404 Page Not Found: Default/images
ERROR - 2019-06-18 11:09:06 --> 404 Page Not Found: Default/images
ERROR - 2019-06-18 11:09:06 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-18 11:09:06 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-18 11:09:06 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-18 11:09:17 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-18 11:09:18 --> 404 Page Not Found: Default/images
ERROR - 2019-06-18 11:09:18 --> 404 Page Not Found: Default/images
ERROR - 2019-06-18 11:09:18 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-18 11:09:18 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-18 11:09:18 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-18 11:09:27 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-18 11:09:27 --> 404 Page Not Found: Default/images
ERROR - 2019-06-18 11:09:27 --> 404 Page Not Found: Default/images
ERROR - 2019-06-18 11:09:27 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-18 11:09:27 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-18 11:09:27 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-18 11:09:39 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-18 11:09:39 --> 404 Page Not Found: Default/images
ERROR - 2019-06-18 11:09:39 --> 404 Page Not Found: Default/images
ERROR - 2019-06-18 11:09:39 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-18 11:09:39 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-18 11:09:39 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-18 11:14:56 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-18 11:14:57 --> 404 Page Not Found: Default/images
ERROR - 2019-06-18 11:14:57 --> 404 Page Not Found: Default/images
ERROR - 2019-06-18 11:14:57 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-18 11:14:57 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-18 11:14:57 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-18 11:15:09 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-18 11:15:10 --> 404 Page Not Found: Default/images
ERROR - 2019-06-18 11:15:10 --> 404 Page Not Found: Default/images
ERROR - 2019-06-18 11:15:10 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-18 11:15:10 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-18 11:15:10 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-18 11:15:19 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-18 11:15:19 --> 404 Page Not Found: Default/images
ERROR - 2019-06-18 11:15:19 --> 404 Page Not Found: Default/images
ERROR - 2019-06-18 11:15:20 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-18 11:15:20 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-18 11:15:20 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-18 11:16:15 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-18 11:16:16 --> 404 Page Not Found: Default/images
ERROR - 2019-06-18 11:16:16 --> 404 Page Not Found: Default/images
ERROR - 2019-06-18 11:16:16 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-18 11:16:16 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-18 11:16:16 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-18 11:19:21 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-18 11:19:21 --> 404 Page Not Found: Default/images
ERROR - 2019-06-18 11:19:22 --> 404 Page Not Found: Default/images
ERROR - 2019-06-18 11:19:22 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-18 11:19:22 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-18 11:19:22 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-18 11:20:07 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-18 11:20:07 --> 404 Page Not Found: Default/images
ERROR - 2019-06-18 11:20:07 --> 404 Page Not Found: Default/images
ERROR - 2019-06-18 11:20:08 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-18 11:20:08 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-18 11:20:08 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-18 11:20:20 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-18 11:20:20 --> 404 Page Not Found: Default/images
ERROR - 2019-06-18 11:20:20 --> 404 Page Not Found: Default/images
ERROR - 2019-06-18 11:20:20 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-18 11:20:20 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-18 11:20:20 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-18 11:20:45 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-18 11:20:46 --> 404 Page Not Found: Default/images
ERROR - 2019-06-18 11:20:46 --> 404 Page Not Found: Default/images
ERROR - 2019-06-18 11:20:46 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-18 11:20:46 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-18 11:20:46 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-18 11:20:59 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-18 11:21:00 --> 404 Page Not Found: Default/images
ERROR - 2019-06-18 11:21:00 --> 404 Page Not Found: Default/images
ERROR - 2019-06-18 11:21:00 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-18 11:21:00 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-18 11:21:00 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-18 11:21:18 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-18 11:21:18 --> 404 Page Not Found: Default/images
ERROR - 2019-06-18 11:21:18 --> 404 Page Not Found: Default/images
ERROR - 2019-06-18 11:21:18 --> 404 Page Not Found: Program/app-assets
ERROR - 2019-06-18 11:21:20 --> 404 Page Not Found: Login/profile
ERROR - 2019-06-18 11:23:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 101
ERROR - 2019-06-18 11:23:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 102
ERROR - 2019-06-18 11:23:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 103
ERROR - 2019-06-18 11:23:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 113
ERROR - 2019-06-18 11:25:16 --> Severity: Notice --> Undefined property: stdClass::$email C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 101
ERROR - 2019-06-18 11:25:16 --> Severity: Notice --> Undefined property: stdClass::$first_name C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 102
ERROR - 2019-06-18 11:25:16 --> Severity: Notice --> Undefined property: stdClass::$last_name C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 103
ERROR - 2019-06-18 11:25:16 --> Severity: Notice --> Undefined property: stdClass::$profile_image C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 113
ERROR - 2019-06-18 11:25:45 --> Severity: Notice --> Undefined property: stdClass::$first_name C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 102
ERROR - 2019-06-18 11:25:45 --> Severity: Notice --> Undefined property: stdClass::$last_name C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 103
ERROR - 2019-06-18 11:25:45 --> Severity: Notice --> Undefined property: stdClass::$profile_image C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 113
ERROR - 2019-06-18 11:26:53 --> Severity: Notice --> Undefined property: stdClass::$profile_image C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 104
ERROR - 2019-06-18 11:28:26 --> Severity: Notice --> Undefined variable: StandardId C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 17
ERROR - 2019-06-18 11:28:26 --> Severity: Notice --> Undefined variable: streamData C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 41
ERROR - 2019-06-18 11:28:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 41
ERROR - 2019-06-18 11:28:26 --> Severity: Notice --> Undefined variable: StandardId C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 52
ERROR - 2019-06-18 11:28:26 --> Severity: Notice --> Undefined variable: Standard C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 53
ERROR - 2019-06-18 11:28:26 --> Severity: Notice --> Undefined variable: IsActive C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 55
ERROR - 2019-06-18 11:28:26 --> Severity: Notice --> Undefined variable: StandardId C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 101
ERROR - 2019-06-18 11:28:26 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-18 11:28:27 --> 404 Page Not Found: Login/app-assets
ERROR - 2019-06-18 11:28:27 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-18 11:28:27 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-18 11:29:30 --> Severity: Notice --> Undefined variable: streamData C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 41
ERROR - 2019-06-18 11:29:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 41
ERROR - 2019-06-18 11:29:30 --> Severity: Notice --> Undefined variable: StandardId C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 52
ERROR - 2019-06-18 11:29:30 --> Severity: Notice --> Undefined variable: Standard C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 53
ERROR - 2019-06-18 11:29:30 --> Severity: Notice --> Undefined variable: IsActive C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 55
ERROR - 2019-06-18 11:29:30 --> Severity: Notice --> Undefined variable: StandardId C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 101
ERROR - 2019-06-18 11:29:30 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-18 11:29:31 --> 404 Page Not Found: Login/app-assets
ERROR - 2019-06-18 11:29:31 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-18 11:29:31 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-18 11:29:59 --> Severity: Notice --> Undefined variable: streamData C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 41
ERROR - 2019-06-18 11:29:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 41
ERROR - 2019-06-18 11:29:59 --> Severity: Notice --> Undefined variable: StandardId C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 52
ERROR - 2019-06-18 11:29:59 --> Severity: Notice --> Undefined variable: Standard C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 53
ERROR - 2019-06-18 11:29:59 --> Severity: Notice --> Undefined variable: IsActive C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 55
ERROR - 2019-06-18 11:29:59 --> Severity: Notice --> Undefined variable: StandardId C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 101
ERROR - 2019-06-18 11:29:59 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-18 11:30:00 --> 404 Page Not Found: Login/app-assets
ERROR - 2019-06-18 11:30:00 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-18 11:30:00 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-18 11:30:20 --> Severity: Notice --> Undefined variable: streamData C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 39
ERROR - 2019-06-18 11:30:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 39
ERROR - 2019-06-18 11:30:20 --> Severity: Notice --> Undefined variable: StandardId C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 50
ERROR - 2019-06-18 11:30:20 --> Severity: Notice --> Undefined variable: Standard C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 51
ERROR - 2019-06-18 11:30:20 --> Severity: Notice --> Undefined variable: IsActive C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 53
ERROR - 2019-06-18 11:30:20 --> Severity: Notice --> Undefined variable: StandardId C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 99
ERROR - 2019-06-18 11:30:20 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-18 11:30:21 --> 404 Page Not Found: Login/app-assets
ERROR - 2019-06-18 11:30:21 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-18 11:30:21 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-18 11:31:42 --> Severity: Notice --> Undefined variable: StandardId C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 39
ERROR - 2019-06-18 11:31:42 --> Severity: Notice --> Undefined variable: Standard C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 40
ERROR - 2019-06-18 11:31:42 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-18 11:31:43 --> 404 Page Not Found: Login/app-assets
ERROR - 2019-06-18 11:31:43 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-18 11:31:43 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-18 11:31:53 --> Severity: Notice --> Undefined variable: Standard C:\xampp\htdocs\mentor\admin\application\views\common\profile.php 40
ERROR - 2019-06-18 11:31:54 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-18 11:31:54 --> 404 Page Not Found: Login/app-assets
ERROR - 2019-06-18 11:31:54 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-18 11:31:54 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-18 11:32:01 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-18 11:32:02 --> 404 Page Not Found: Login/app-assets
ERROR - 2019-06-18 11:32:02 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-18 11:32:02 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-18 11:33:16 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-18 11:33:17 --> 404 Page Not Found: Login/app-assets
ERROR - 2019-06-18 11:33:17 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-18 11:33:17 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-18 11:33:39 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-18 11:33:40 --> 404 Page Not Found: Login/app-assets
ERROR - 2019-06-18 11:33:40 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-18 11:33:40 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-18 11:33:54 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-18 11:33:55 --> 404 Page Not Found: Login/app-assets
ERROR - 2019-06-18 11:33:55 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-18 11:33:55 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-18 11:34:19 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-18 11:34:20 --> 404 Page Not Found: Login/app-assets
ERROR - 2019-06-18 11:34:20 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-18 11:34:20 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-18 11:35:39 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-18 11:35:40 --> 404 Page Not Found: Login/app-assets
ERROR - 2019-06-18 11:35:40 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-18 11:35:40 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-18 11:41:05 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-18 11:41:06 --> 404 Page Not Found: Login/app-assets
ERROR - 2019-06-18 11:41:06 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-18 11:41:06 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-18 11:41:24 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-18 11:41:25 --> 404 Page Not Found: Login/app-assets
ERROR - 2019-06-18 11:41:25 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-18 11:41:25 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-18 11:41:32 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-18 11:41:33 --> 404 Page Not Found: Login/app-assets
ERROR - 2019-06-18 11:41:33 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-18 11:41:33 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-18 11:44:04 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-18 11:44:04 --> 404 Page Not Found: Login/app-assets
ERROR - 2019-06-18 11:44:04 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-18 11:44:04 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-18 11:44:41 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-18 11:44:42 --> 404 Page Not Found: Login/app-assets
ERROR - 2019-06-18 11:44:42 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-18 11:44:42 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-18 11:45:02 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-18 11:45:03 --> 404 Page Not Found: Login/app-assets
ERROR - 2019-06-18 11:45:03 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-18 11:45:03 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-18 11:45:48 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-18 11:45:49 --> 404 Page Not Found: Login/app-assets
ERROR - 2019-06-18 11:45:49 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-06-18 11:45:49 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-06-18 11:46:08 --> 404 Page Not Found: Login/app-assets
ERROR - 2019-06-18 11:46:16 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-18 11:46:17 --> 404 Page Not Found: Login/app-assets
ERROR - 2019-06-18 11:48:27 --> Severity: Notice --> Undefined property: stdClass::$gender C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 106
ERROR - 2019-06-18 11:48:27 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 107
ERROR - 2019-06-18 11:48:27 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-18 11:48:28 --> 404 Page Not Found: Login/app-assets
ERROR - 2019-06-18 11:48:55 --> Severity: Notice --> Undefined property: stdClass::$gender C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 106
ERROR - 2019-06-18 11:48:55 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\mentor\admin\application\controllers\Login.php 107
ERROR - 2019-06-18 11:48:55 --> 404 Page Not Found: App-assets/images
ERROR - 2019-06-18 11:48:56 --> 404 Page Not Found: Login/app-assets
