<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-23 06:32:41 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-23 06:32:41 --> 404 Page Not Found: Favicon/favicon.ico
