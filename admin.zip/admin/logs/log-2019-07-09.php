<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-09 14:06:28 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'mentor' C:\xampp\htdocs\mentor\admin\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-07-09 14:06:28 --> Unable to connect to the database
ERROR - 2019-07-09 14:08:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'mentor' C:\xampp\htdocs\realestate\admin\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-07-09 14:08:36 --> Unable to connect to the database
ERROR - 2019-07-09 14:10:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'mentor' C:\xampp\htdocs\realestate\admin\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-07-09 14:10:02 --> Unable to connect to the database
ERROR - 2019-07-09 14:10:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'realestate' C:\xampp\htdocs\realestate\admin\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-07-09 14:10:25 --> Unable to connect to the database
ERROR - 2019-07-09 14:10:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'realestate' C:\xampp\htdocs\realestate\admin\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-07-09 14:10:56 --> Unable to connect to the database
ERROR - 2019-07-09 14:10:57 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'realestate' C:\xampp\htdocs\realestate\admin\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-07-09 14:10:57 --> Unable to connect to the database
ERROR - 2019-07-09 14:10:57 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'realestate' C:\xampp\htdocs\realestate\admin\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-07-09 14:10:57 --> Unable to connect to the database
ERROR - 2019-07-09 14:11:12 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'realestatedb' C:\xampp\htdocs\realestate\admin\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-07-09 14:11:12 --> Unable to connect to the database
ERROR - 2019-07-09 14:11:15 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'realestatedb' C:\xampp\htdocs\realestate\admin\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-07-09 14:11:15 --> Unable to connect to the database
ERROR - 2019-07-09 14:15:45 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-09 14:15:45 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-09 14:19:10 --> Severity: Notice --> Undefined variable: datasession C:\xampp\htdocs\realestate\admin\application\controllers\Login.php 45
ERROR - 2019-07-09 14:20:48 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-09 14:20:48 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-09 14:20:55 --> Severity: Notice --> Undefined variable: datasession C:\xampp\htdocs\realestate\admin\application\controllers\Login.php 45
ERROR - 2019-07-09 14:24:22 --> Severity: Notice --> Undefined variable: datasession C:\xampp\htdocs\realestate\admin\application\controllers\Login.php 45
ERROR - 2019-07-09 14:24:39 --> Severity: Notice --> Undefined variable: datasession C:\xampp\htdocs\realestate\admin\application\controllers\Login.php 45
ERROR - 2019-07-09 14:25:41 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-09 14:25:41 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-09 14:29:25 --> Severity: Notice --> Undefined property: stdClass::$Email C:\xampp\htdocs\realestate\admin\application\controllers\Login.php 32
ERROR - 2019-07-09 14:29:25 --> Severity: Notice --> Undefined property: stdClass::$UserId C:\xampp\htdocs\realestate\admin\application\controllers\Login.php 33
ERROR - 2019-07-09 14:29:25 --> Severity: Notice --> Undefined property: stdClass::$FirstName C:\xampp\htdocs\realestate\admin\application\controllers\Login.php 34
ERROR - 2019-07-09 14:30:02 --> 404 Page Not Found: Admin/dashboard
ERROR - 2019-07-09 14:30:15 --> 404 Page Not Found: Admin/dashboard
ERROR - 2019-07-09 14:30:19 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-09 14:30:19 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-09 14:30:25 --> 404 Page Not Found: Home/dashboard
ERROR - 2019-07-09 14:31:05 --> 404 Page Not Found: Home/dashboard
ERROR - 2019-07-09 14:37:58 --> 404 Page Not Found: Default/images
ERROR - 2019-07-09 14:37:58 --> 404 Page Not Found: Default/images
ERROR - 2019-07-09 14:37:58 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-09 14:37:58 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-09 14:51:23 --> 404 Page Not Found: Default/images
ERROR - 2019-07-09 14:51:23 --> 404 Page Not Found: Default/images
ERROR - 2019-07-09 14:51:23 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-09 14:51:23 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-09 14:52:14 --> 404 Page Not Found: Default/images
ERROR - 2019-07-09 14:52:14 --> 404 Page Not Found: Default/images
ERROR - 2019-07-09 14:52:14 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-09 14:52:14 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-09 14:52:37 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-09 14:52:37 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-09 14:53:16 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-09 14:53:16 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-09 14:54:12 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-09 14:54:13 --> 404 Page Not Found: Home/app-assets
ERROR - 2019-07-09 14:54:13 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-09 14:54:13 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-09 14:54:28 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\realestate\admin\application\views\common\footer.php 10
ERROR - 2019-07-09 14:54:28 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-09 14:54:29 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-09 14:54:29 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-09 14:54:39 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-09 14:54:39 --> 404 Page Not Found: Home/app-assets
ERROR - 2019-07-09 14:54:39 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-09 14:54:39 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-09 14:54:53 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-09 14:54:54 --> 404 Page Not Found: Home/app-assets
ERROR - 2019-07-09 14:54:54 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-09 14:54:54 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-09 14:55:26 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-09 14:55:26 --> 404 Page Not Found: Home/app-assets
ERROR - 2019-07-09 14:55:26 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-09 14:55:26 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-09 14:55:35 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-09 14:55:36 --> 404 Page Not Found: Home/app-assets
ERROR - 2019-07-09 14:55:36 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-09 14:55:36 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-09 14:56:29 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-09 14:56:30 --> 404 Page Not Found: Home/app-assets
ERROR - 2019-07-09 14:56:30 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-09 14:56:30 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-09 14:56:46 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-09 14:56:47 --> 404 Page Not Found: Home/app-assets
ERROR - 2019-07-09 14:56:47 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-09 14:56:47 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-09 15:01:36 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-09 15:01:37 --> 404 Page Not Found: Home/app-assets
ERROR - 2019-07-09 15:01:37 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-09 15:01:37 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-09 15:01:42 --> 404 Page Not Found: Admin/index
ERROR - 2019-07-09 15:02:20 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-09 15:02:21 --> 404 Page Not Found: Home/app-assets
ERROR - 2019-07-09 15:02:21 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-09 15:02:21 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-09 15:03:27 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-09 15:03:27 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-09 15:03:28 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-09 15:03:29 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-09 15:03:29 --> 404 Page Not Found: Home/app-assets
ERROR - 2019-07-09 15:03:29 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-09 15:03:29 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-09 15:05:34 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-09 15:05:34 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-09 15:05:34 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-09 15:06:29 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-09 15:06:30 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-09 15:06:30 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-09 15:07:30 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-09 15:07:31 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-09 15:07:31 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-09 15:07:33 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-09 15:07:33 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-09 15:07:34 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-09 15:07:34 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-09 15:09:11 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-09 15:09:12 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-09 15:09:12 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-09 15:09:28 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-09 15:09:28 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-09 15:10:46 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-09 15:10:46 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-09 15:12:04 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-09 15:12:04 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-09 15:12:20 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-09 15:12:20 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-09 15:12:27 --> Severity: Notice --> Undefined variable: datasession C:\xampp\htdocs\realestate\admin\application\controllers\Login.php 45
ERROR - 2019-07-09 15:12:34 --> Query error: Unknown column 'UserId' in 'where clause' - Invalid query: SELECT *
FROM `tbluser`
WHERE `UserId` = '1'
ERROR - 2019-07-09 15:12:59 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\realestate\admin\application\views\common\footer.php 12
ERROR - 2019-07-09 15:13:00 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-09 15:13:00 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-09 15:13:38 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\realestate\admin\application\views\common\footer.php 12
ERROR - 2019-07-09 15:15:23 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\realestate\admin\application\views\common\footer.php 12
ERROR - 2019-07-09 15:15:25 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\realestate\admin\application\views\common\footer.php 12
ERROR - 2019-07-09 15:15:25 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-09 15:15:26 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-09 15:15:27 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\realestate\admin\application\views\common\footer.php 12
ERROR - 2019-07-09 15:15:27 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\realestate\admin\application\views\common\footer.php 12
ERROR - 2019-07-09 15:15:27 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\realestate\admin\application\views\common\footer.php 12
ERROR - 2019-07-09 15:15:28 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-09 15:15:28 --> 404 Page Not Found: Favicon/favicon.ico
