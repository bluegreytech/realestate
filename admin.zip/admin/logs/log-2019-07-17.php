<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-17 06:42:13 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 06:42:13 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 06:42:20 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 06:42:20 --> 404 Page Not Found: Home/app-assets
ERROR - 2019-07-17 06:57:26 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 06:57:27 --> 404 Page Not Found: Home/app-assets
ERROR - 2019-07-17 07:36:10 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 07:36:10 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 07:36:10 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 07:36:10 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 07:36:10 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 07:36:10 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 07:36:13 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 07:59:10 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 07:59:10 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 07:59:10 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 07:59:10 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 07:59:10 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 07:59:11 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 07:59:13 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 08:00:47 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 08:00:47 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 08:00:47 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 08:02:20 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 08:02:21 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 08:02:21 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 08:08:09 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 08:09:01 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 08:11:31 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 08:50:23 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 08:50:23 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 08:50:23 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 09:01:39 --> Query error: Unknown column 'Projectldesc' in 'field list' - Invalid query: INSERT INTO `tblprojects` (`ProjectTitle`, `Projectsdesc`, `Projectldesc`, `ProjectImage`, `Projectlogo`, `Project_brochure`, `Projectstatus`, `IsActive`, `CreatedOn`) VALUES ('Shree Siddheswer Homes', '“You See A Dream, We Create…”\r\nA House is Not Just A Place to Live in. The Ambiance, Interior & Exterior Spaces, The Neighborhood, the Comforts and Amenities Define The Quality of Life And Create a Definite Line of Premium Living.', '<ul>\r\n	<li>Garden with Sitting Facility</li>\r\n	<li>Club House</li>\r\n	<li>AC Gym</li>\r\n	<li>Children Play Area</li>\r\n	<li>Indoor Game &ndash; Table Tennis &ndash; Chase</li>\r\n	<li>Senior Citizen Sitting</li>\r\n	<li>Jogging Track</li>\r\n</ul>\r\n\r\n<ul>\r\n	<li>Allotted Parking</li>\r\n	<li>Internal RCC Road with Fully Paved Parking Area</li>\r\n	<li>Street Lights Throughout Camus</li>\r\n	<li>Eco Friendly Surrounding Environment.</li>\r\n	<li>Standard Quality Passenger Elevator.</li>\r\n	<li>24 hours Water Supply.</li>\r\n</ul>\r\n\r\n<ul>\r\n	<li>Designer Entry Gate with Surrounding Compound</li>\r\n	<li>24&times;7 Security with Security Cabin</li>\r\n	<li>Anti Termite Treatment to The Building.</li>\r\n	<li>Elegant Name &amp; Number Plate to Each Unit</li>\r\n	<li>Heat &amp; Water Proofing Treatment on the Terrace.</li>\r\n</ul>', '5765Projectimage.jpg', '90551Projectlogo.png', '99820Projectbrochure.jpg', 'Past', 'Active', '2019-07-17')
ERROR - 2019-07-17 09:06:42 --> Query error: Unknown column 'Projectsdesc' in 'field list' - Invalid query: INSERT INTO `tblprojects` (`ProjectTitle`, `Projectsdesc`, `Projectldesc`, `ProjectImage`, `Projectlogo`, `Project_brochure`, `Projectstatus`, `IsActive`, `CreatedOn`) VALUES ('Shree Siddheswer Homes', '“You See A Dream, We Create…”\r\nA House is Not Just A Place to Live in. The Ambiance, Interior & Exterior Spaces, The Neighborhood, the Comforts and Amenities Define The Quality of Life And Create a Definite Line of Premium Living.', '<ul>\r\n	<li>Garden with Sitting Facility</li>\r\n	<li>Club House</li>\r\n	<li>AC Gym</li>\r\n	<li>Children Play Area</li>\r\n	<li>Indoor Game &ndash; Table Tennis &ndash; Chase</li>\r\n	<li>Senior Citizen Sitting</li>\r\n	<li>Jogging Track</li>\r\n</ul>\r\n\r\n<ul>\r\n	<li>Allotted Parking</li>\r\n	<li>Internal RCC Road with Fully Paved Parking Area</li>\r\n	<li>Street Lights Throughout Camus</li>\r\n	<li>Eco Friendly Surrounding Environment.</li>\r\n	<li>Standard Quality Passenger Elevator.</li>\r\n	<li>24 hours Water Supply.</li>\r\n</ul>\r\n\r\n<ul>\r\n	<li>Designer Entry Gate with Surrounding Compound</li>\r\n	<li>24&times;7 Security with Security Cabin</li>\r\n	<li>Anti Termite Treatment to The Building.</li>\r\n	<li>Elegant Name &amp; Number Plate to Each Unit</li>\r\n	<li>Heat &amp; Water Proofing Treatment on the Terrace.</li>\r\n</ul>', '37742Projectimage.jpg', '2752Projectlogo.png', '6166Projectbrochure.jpg', 'Past', 'Active', '2019-07-17')
ERROR - 2019-07-17 09:07:22 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 09:07:22 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 09:07:22 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 09:07:22 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 09:07:22 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 09:07:22 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 09:07:28 --> Severity: Notice --> Undefined variable: Projectldesc C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 59
ERROR - 2019-07-17 09:07:28 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 09:07:28 --> Severity: Notice --> Undefined variable: Projectldesc C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 59
ERROR - 2019-07-17 09:08:06 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 09:08:06 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 09:08:06 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 10:35:00 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 10:35:01 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:35:01 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:35:01 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 10:35:52 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 10:35:52 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:35:52 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:35:52 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 10:39:42 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 10:39:42 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:39:42 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:39:42 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 10:41:36 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 10:41:37 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:41:37 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:41:37 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 10:41:37 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 10:41:37 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 10:46:47 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 10:46:47 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:46:47 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:46:47 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 10:46:47 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 10:46:47 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 10:47:19 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 10:47:19 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:47:19 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:47:19 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 10:47:19 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 10:47:19 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 10:47:21 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 10:47:21 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 10:47:23 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 10:47:23 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 10:48:09 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 10:48:09 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:48:09 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:48:09 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 10:48:09 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 10:48:09 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 10:48:24 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 10:48:24 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:48:24 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:48:24 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 10:48:24 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 10:48:24 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 10:48:32 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 10:48:32 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:48:32 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:48:33 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 10:48:33 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 10:48:33 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 10:48:45 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 10:48:45 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:48:45 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:48:45 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 10:48:45 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 10:48:45 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 10:49:46 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 10:49:47 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:49:48 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:49:48 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 10:49:48 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 10:49:48 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 10:50:00 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 10:50:01 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:50:01 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:50:01 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 10:50:01 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 10:50:01 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 10:50:26 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 10:50:27 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:50:27 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:50:27 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 10:50:27 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 10:50:27 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 10:50:53 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 10:50:54 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:50:54 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:50:54 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 10:50:54 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 10:50:54 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 10:51:53 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 10:51:53 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:51:53 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:51:53 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 10:51:53 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 10:51:53 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 10:52:06 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 10:52:06 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:52:06 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:52:06 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 10:52:06 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 10:52:06 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 10:52:17 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 10:52:17 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:52:17 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:52:17 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 10:52:17 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 10:52:17 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 10:52:36 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 10:52:36 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:52:36 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:52:36 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 10:52:36 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 10:52:36 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 10:52:42 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 10:52:43 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:52:43 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:52:43 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 10:52:43 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 10:52:43 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 10:57:19 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 10:57:19 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:57:19 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:57:19 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 10:57:19 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 10:57:19 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 10:57:40 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 10:57:40 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:57:40 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:57:40 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 10:57:40 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 10:57:40 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 10:57:54 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 10:57:54 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:57:54 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:57:54 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 10:57:54 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 10:57:54 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 10:57:57 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 10:57:57 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 10:58:07 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 10:58:07 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:58:07 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:58:07 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 10:58:07 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 10:58:07 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 10:58:39 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 10:58:39 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:58:39 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 10:58:39 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 11:02:37 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 11:02:37 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 11:02:37 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 11:02:37 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 11:02:37 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 11:02:37 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 11:02:41 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 11:02:41 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 11:02:41 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 11:02:41 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 11:03:23 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 11:03:24 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 11:03:24 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 11:03:24 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 11:03:25 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 11:03:26 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 11:03:26 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 11:03:26 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 11:03:26 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 11:03:26 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 11:04:33 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 11:04:34 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 11:04:34 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 11:04:34 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 11:04:34 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 11:04:34 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 11:08:10 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 11:08:10 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 11:08:10 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 11:08:10 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 11:08:10 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 11:08:10 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 11:08:48 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 11:08:49 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 11:08:49 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 11:08:49 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 11:08:49 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 11:08:49 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 11:09:13 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 11:09:13 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 11:09:13 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 11:09:13 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 11:09:13 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 11:09:13 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 11:10:05 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 11:10:05 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 11:10:06 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 11:10:06 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 11:10:06 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 11:10:06 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 11:10:13 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 11:10:14 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 11:10:14 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 11:10:14 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 11:10:14 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 11:10:14 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 11:21:19 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 11:21:20 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 11:21:20 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 11:21:20 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 11:21:20 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 11:21:20 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 11:21:24 --> 404 Page Not Found: Project/list_gallery
ERROR - 2019-07-17 11:22:06 --> 404 Page Not Found: Project/list_gallery
ERROR - 2019-07-17 11:22:31 --> 404 Page Not Found: Project/list_gallery
ERROR - 2019-07-17 11:28:49 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 11:28:50 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 11:28:50 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 11:28:50 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 11:28:50 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 11:28:50 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 11:29:04 --> Query error: Table 'realstatesdb.tblgallery' doesn't exist - Invalid query: SELECT *
FROM `tblgallery`
WHERE `Is_deleted` = '0'
ERROR - 2019-07-17 11:37:03 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 11:37:04 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 11:37:04 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 11:37:04 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 11:37:04 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 11:37:04 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 11:41:23 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 11:41:23 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 11:41:23 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 11:41:23 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 11:41:23 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 11:41:23 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 11:42:12 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 11:42:12 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 11:42:12 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 11:42:12 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 11:42:12 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 11:42:12 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 11:49:24 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 11:49:24 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 11:49:27 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 11:49:27 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 11:49:27 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 11:49:27 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 11:50:09 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 11:50:10 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 11:50:10 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 11:50:10 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 11:50:10 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 11:50:10 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 11:50:11 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 11:51:23 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 11:51:23 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 11:51:23 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 11:51:36 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 11:51:37 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 11:51:37 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 11:53:33 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 47
ERROR - 2019-07-17 11:53:33 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 11:53:33 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 11:53:33 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 11:53:33 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 47
ERROR - 2019-07-17 11:53:57 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 11:53:58 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 11:53:58 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 11:54:18 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 11:54:18 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 11:54:18 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 11:56:10 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 11:56:10 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 11:56:10 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 11:58:06 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 39
ERROR - 2019-07-17 11:58:06 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 57
ERROR - 2019-07-17 11:58:06 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 104
ERROR - 2019-07-17 11:58:06 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 11:58:06 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 11:58:06 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 39
ERROR - 2019-07-17 11:58:06 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 57
ERROR - 2019-07-17 11:58:06 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 104
ERROR - 2019-07-17 11:58:06 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 12:00:16 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 39
ERROR - 2019-07-17 12:00:16 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 57
ERROR - 2019-07-17 12:00:16 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 104
ERROR - 2019-07-17 12:00:17 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 12:00:17 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 12:00:17 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 12:00:17 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 39
ERROR - 2019-07-17 12:00:17 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 57
ERROR - 2019-07-17 12:00:17 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 104
ERROR - 2019-07-17 12:03:01 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 39
ERROR - 2019-07-17 12:03:01 --> Severity: Notice --> Undefined variable: project C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 44
ERROR - 2019-07-17 12:03:01 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 63
ERROR - 2019-07-17 12:03:01 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 110
ERROR - 2019-07-17 12:03:01 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 12:03:01 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 12:03:01 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 12:03:01 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 39
ERROR - 2019-07-17 12:03:01 --> Severity: Notice --> Undefined variable: project C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 44
ERROR - 2019-07-17 12:03:01 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 63
ERROR - 2019-07-17 12:03:01 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 110
ERROR - 2019-07-17 12:03:51 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 39
ERROR - 2019-07-17 12:03:51 --> Severity: Notice --> Undefined variable: project C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 44
ERROR - 2019-07-17 12:03:51 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 63
ERROR - 2019-07-17 12:03:51 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 110
ERROR - 2019-07-17 12:03:51 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 12:03:51 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 12:03:51 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 39
ERROR - 2019-07-17 12:03:51 --> Severity: Notice --> Undefined variable: project C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 44
ERROR - 2019-07-17 12:03:51 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 63
ERROR - 2019-07-17 12:03:51 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 110
ERROR - 2019-07-17 12:03:51 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 12:05:04 --> Severity: Notice --> Undefined variable: ProjectId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 18
ERROR - 2019-07-17 12:05:04 --> Severity: Notice --> Undefined variable: project C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 44
ERROR - 2019-07-17 12:05:05 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 12:05:05 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 12:05:05 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 12:05:05 --> Severity: Notice --> Undefined variable: ProjectId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 18
ERROR - 2019-07-17 12:05:05 --> Severity: Notice --> Undefined variable: project C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 44
ERROR - 2019-07-17 12:05:18 --> Severity: Notice --> Undefined variable: project C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 44
ERROR - 2019-07-17 12:05:18 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 12:05:18 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 12:05:18 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 12:05:18 --> Severity: Notice --> Undefined variable: project C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 44
ERROR - 2019-07-17 12:09:30 --> Severity: Notice --> Undefined variable: project C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 44
ERROR - 2019-07-17 12:09:30 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 12:09:30 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 12:09:30 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 12:09:30 --> Severity: Notice --> Undefined variable: project C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 44
ERROR - 2019-07-17 12:12:52 --> Severity: Notice --> Undefined variable: project C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 44
ERROR - 2019-07-17 12:12:52 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 12:12:52 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 12:12:52 --> Severity: Notice --> Undefined variable: project C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 44
ERROR - 2019-07-17 12:12:52 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 12:12:53 --> Severity: Notice --> Undefined variable: project C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 44
ERROR - 2019-07-17 12:12:53 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 12:12:53 --> Severity: Notice --> Undefined variable: project C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 44
ERROR - 2019-07-17 12:12:53 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 12:12:53 --> Severity: Notice --> Undefined variable: project C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 44
ERROR - 2019-07-17 12:12:53 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 12:12:54 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 12:12:54 --> Severity: Notice --> Undefined variable: project C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 44
ERROR - 2019-07-17 12:12:54 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 12:14:10 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 12:14:10 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 12:14:10 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 12:14:10 --> 404 Page Not Found: User/app-assets
ERROR - 2019-07-17 12:14:13 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 12:16:09 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 12:16:09 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 12:16:09 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 12:16:09 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 12:16:10 --> Severity: Notice --> Undefined variable: project C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 44
ERROR - 2019-07-17 12:16:10 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 12:16:11 --> Severity: Notice --> Undefined variable: project C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 44
ERROR - 2019-07-17 12:17:00 --> Severity: Notice --> Undefined variable: project C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 44
ERROR - 2019-07-17 12:17:00 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 12:17:00 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 12:17:00 --> Severity: Notice --> Undefined variable: project C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 44
ERROR - 2019-07-17 12:17:00 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 12:17:33 --> Severity: Notice --> Undefined variable: project C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 44
ERROR - 2019-07-17 12:17:33 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 12:17:34 --> Severity: Notice --> Undefined variable: project C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 44
ERROR - 2019-07-17 12:18:37 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 12:18:37 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 12:18:37 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 12:18:45 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 12:18:46 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 12:18:46 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 12:23:12 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 12:23:12 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 12:23:12 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 12:23:40 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 12:23:41 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 12:23:41 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 12:24:03 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 12:24:04 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 12:24:04 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 12:36:10 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 12:36:10 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 12:36:10 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 12:36:19 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 12:36:19 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 12:36:19 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 12:36:24 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 12:36:24 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 12:36:24 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 12:36:25 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 12:36:25 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 12:36:25 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 12:36:37 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 12:36:37 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 12:36:37 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 12:36:37 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 12:36:37 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 12:36:39 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 12:39:51 --> Query error: Unknown column 'CreatedOn' in 'field list' - Invalid query: INSERT INTO `tblgallery` (`project_id`, `gallery_image`, `IsActive`, `CreatedOn`) VALUES ('7', '46867GalleryImages.jpg', 'Active', '2019-07-17  12:39:51')
ERROR - 2019-07-17 12:40:22 --> Severity: Notice --> Undefined property: stdClass::$ProjectTitle C:\xampp\htdocs\realestate\admin\application\views\Project\List_gallery.php 52
ERROR - 2019-07-17 12:40:22 --> Severity: Notice --> Undefined property: stdClass::$ProjectImage C:\xampp\htdocs\realestate\admin\application\views\Project\List_gallery.php 54
ERROR - 2019-07-17 12:40:22 --> Severity: Notice --> Undefined property: stdClass::$ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\List_gallery.php 61
ERROR - 2019-07-17 12:40:22 --> Severity: Notice --> Undefined property: stdClass::$ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\List_gallery.php 64
ERROR - 2019-07-17 12:40:22 --> Severity: Notice --> Undefined property: stdClass::$ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\List_gallery.php 67
ERROR - 2019-07-17 12:40:22 --> Severity: Notice --> Undefined property: stdClass::$ProjectId C:\xampp\htdocs\realestate\admin\application\views\Project\List_gallery.php 85
ERROR - 2019-07-17 12:40:22 --> Severity: Notice --> Undefined property: stdClass::$ProjectId C:\xampp\htdocs\realestate\admin\application\views\Project\List_gallery.php 86
ERROR - 2019-07-17 12:40:22 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 12:40:22 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 12:40:22 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 12:40:22 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 12:44:15 --> Severity: Notice --> Undefined property: stdClass::$ProjectTitle C:\xampp\htdocs\realestate\admin\application\views\Project\List_gallery.php 53
ERROR - 2019-07-17 12:44:15 --> Severity: Notice --> Undefined property: stdClass::$ProjectImage C:\xampp\htdocs\realestate\admin\application\views\Project\List_gallery.php 55
ERROR - 2019-07-17 12:44:15 --> Severity: Notice --> Undefined property: stdClass::$ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\List_gallery.php 62
ERROR - 2019-07-17 12:44:15 --> Severity: Notice --> Undefined property: stdClass::$ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\List_gallery.php 65
ERROR - 2019-07-17 12:44:15 --> Severity: Notice --> Undefined property: stdClass::$ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\List_gallery.php 68
ERROR - 2019-07-17 12:44:15 --> Severity: Notice --> Undefined property: stdClass::$ProjectId C:\xampp\htdocs\realestate\admin\application\views\Project\List_gallery.php 86
ERROR - 2019-07-17 12:44:15 --> Severity: Notice --> Undefined property: stdClass::$ProjectId C:\xampp\htdocs\realestate\admin\application\views\Project\List_gallery.php 87
ERROR - 2019-07-17 12:44:15 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 12:44:15 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 12:44:15 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 12:44:15 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 12:44:34 --> Severity: Notice --> Undefined property: stdClass::$ProjectImage C:\xampp\htdocs\realestate\admin\application\views\Project\List_gallery.php 55
ERROR - 2019-07-17 12:44:34 --> Severity: Notice --> Undefined property: stdClass::$ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\List_gallery.php 62
ERROR - 2019-07-17 12:44:34 --> Severity: Notice --> Undefined property: stdClass::$ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\List_gallery.php 65
ERROR - 2019-07-17 12:44:34 --> Severity: Notice --> Undefined property: stdClass::$ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\List_gallery.php 68
ERROR - 2019-07-17 12:44:34 --> Severity: Notice --> Undefined property: stdClass::$ProjectId C:\xampp\htdocs\realestate\admin\application\views\Project\List_gallery.php 86
ERROR - 2019-07-17 12:44:34 --> Severity: Notice --> Undefined property: stdClass::$ProjectId C:\xampp\htdocs\realestate\admin\application\views\Project\List_gallery.php 87
ERROR - 2019-07-17 12:44:34 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 12:44:35 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 12:44:35 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 12:44:35 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 12:45:08 --> Severity: Notice --> Undefined property: stdClass::$ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\List_gallery.php 62
ERROR - 2019-07-17 12:45:08 --> Severity: Notice --> Undefined property: stdClass::$ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\List_gallery.php 65
ERROR - 2019-07-17 12:45:08 --> Severity: Notice --> Undefined property: stdClass::$ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\List_gallery.php 68
ERROR - 2019-07-17 12:45:08 --> Severity: Notice --> Undefined property: stdClass::$ProjectId C:\xampp\htdocs\realestate\admin\application\views\Project\List_gallery.php 86
ERROR - 2019-07-17 12:45:08 --> Severity: Notice --> Undefined property: stdClass::$ProjectId C:\xampp\htdocs\realestate\admin\application\views\Project\List_gallery.php 87
ERROR - 2019-07-17 12:45:08 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 12:45:08 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 12:45:08 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 12:45:08 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 12:45:18 --> Severity: Notice --> Undefined property: stdClass::$ProjectId C:\xampp\htdocs\realestate\admin\application\views\Project\List_gallery.php 75
ERROR - 2019-07-17 12:45:18 --> Severity: Notice --> Undefined property: stdClass::$ProjectId C:\xampp\htdocs\realestate\admin\application\views\Project\List_gallery.php 76
ERROR - 2019-07-17 12:45:19 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 12:45:19 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 12:45:19 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 12:45:19 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 12:45:19 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 12:45:19 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 12:46:02 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 12:46:02 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 12:46:02 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 12:46:02 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 12:46:02 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 12:46:02 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 12:46:56 --> 404 Page Not Found: Project/editgallery
ERROR - 2019-07-17 12:47:15 --> 404 Page Not Found: Project/editgallery
ERROR - 2019-07-17 12:47:16 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 12:47:16 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 12:49:47 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 12:49:47 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 12:49:47 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 12:49:47 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 12:49:53 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 12:49:53 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 12:49:53 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 12:49:53 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 12:49:53 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 12:49:53 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 12:49:55 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 12:50:06 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 12:50:06 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 13:02:50 --> Severity: Notice --> Undefined variable: ProjectId C:\xampp\htdocs\realestate\admin\application\controllers\Project.php 183
ERROR - 2019-07-17 13:02:50 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:02:50 --> Severity: Notice --> Undefined variable: ProjectId C:\xampp\htdocs\realestate\admin\application\controllers\Project.php 183
ERROR - 2019-07-17 13:02:55 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 13:02:55 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 13:03:52 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:03:52 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 13:03:52 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 13:03:52 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 13:03:52 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 13:03:52 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 13:03:54 --> Severity: Notice --> Undefined variable: ProjectId C:\xampp\htdocs\realestate\admin\application\controllers\Project.php 183
ERROR - 2019-07-17 13:03:54 --> Severity: Notice --> Undefined variable: ProjectTitle C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 41
ERROR - 2019-07-17 13:03:54 --> Severity: Notice --> Undefined variable: Projectsdesc C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 45
ERROR - 2019-07-17 13:03:54 --> Severity: Notice --> Undefined variable: Projectldesc C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 59
ERROR - 2019-07-17 13:03:54 --> Severity: Notice --> Undefined variable: Projectlogo C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 70
ERROR - 2019-07-17 13:03:54 --> Severity: Notice --> Undefined variable: Projectlogo C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 76
ERROR - 2019-07-17 13:03:54 --> Severity: Notice --> Undefined variable: ProjectImage C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 86
ERROR - 2019-07-17 13:03:54 --> Severity: Notice --> Undefined variable: ProjectImage C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 92
ERROR - 2019-07-17 13:03:54 --> Severity: Notice --> Undefined variable: Project_brochure C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 102
ERROR - 2019-07-17 13:03:54 --> Severity: Notice --> Undefined variable: Project_brochure C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 108
ERROR - 2019-07-17 13:03:54 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:03:54 --> Severity: Notice --> Undefined variable: ProjectId C:\xampp\htdocs\realestate\admin\application\controllers\Project.php 183
ERROR - 2019-07-17 13:03:55 --> Severity: Notice --> Undefined variable: ProjectTitle C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 41
ERROR - 2019-07-17 13:03:55 --> Severity: Notice --> Undefined variable: Projectsdesc C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 45
ERROR - 2019-07-17 13:03:55 --> Severity: Notice --> Undefined variable: Projectldesc C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 59
ERROR - 2019-07-17 13:03:55 --> Severity: Notice --> Undefined variable: Projectlogo C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 70
ERROR - 2019-07-17 13:03:55 --> Severity: Notice --> Undefined variable: Projectlogo C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 76
ERROR - 2019-07-17 13:03:55 --> Severity: Notice --> Undefined variable: ProjectImage C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 86
ERROR - 2019-07-17 13:03:55 --> Severity: Notice --> Undefined variable: ProjectImage C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 92
ERROR - 2019-07-17 13:03:55 --> Severity: Notice --> Undefined variable: Project_brochure C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 102
ERROR - 2019-07-17 13:03:55 --> Severity: Notice --> Undefined variable: Project_brochure C:\xampp\htdocs\realestate\admin\application\views\Project\ProjectAdd.php 108
ERROR - 2019-07-17 13:04:17 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:04:17 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 13:04:17 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 13:04:17 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 13:06:55 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:06:55 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 13:06:55 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 13:06:55 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 13:06:55 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 13:06:55 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 13:07:03 --> Severity: Notice --> Undefined variable: ProjectId C:\xampp\htdocs\realestate\admin\application\controllers\Project.php 183
ERROR - 2019-07-17 13:07:03 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 18
ERROR - 2019-07-17 13:07:03 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 39
ERROR - 2019-07-17 13:07:03 --> Severity: Notice --> Undefined variable: projectlist C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 44
ERROR - 2019-07-17 13:07:03 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 110
ERROR - 2019-07-17 13:07:03 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:07:03 --> Severity: Notice --> Undefined variable: ProjectId C:\xampp\htdocs\realestate\admin\application\controllers\Project.php 183
ERROR - 2019-07-17 13:07:03 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 18
ERROR - 2019-07-17 13:07:03 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 39
ERROR - 2019-07-17 13:07:03 --> Severity: Notice --> Undefined variable: projectlist C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 44
ERROR - 2019-07-17 13:07:03 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 110
ERROR - 2019-07-17 13:07:32 --> Severity: Notice --> Undefined variable: ProjectId C:\xampp\htdocs\realestate\admin\application\controllers\Project.php 183
ERROR - 2019-07-17 13:07:32 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 18
ERROR - 2019-07-17 13:07:32 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 39
ERROR - 2019-07-17 13:07:32 --> Severity: Notice --> Undefined variable: projectlist C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 44
ERROR - 2019-07-17 13:07:32 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 110
ERROR - 2019-07-17 13:07:32 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:07:32 --> Severity: Notice --> Undefined variable: ProjectId C:\xampp\htdocs\realestate\admin\application\controllers\Project.php 183
ERROR - 2019-07-17 13:07:32 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 18
ERROR - 2019-07-17 13:07:32 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 39
ERROR - 2019-07-17 13:07:32 --> Severity: Notice --> Undefined variable: projectlist C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 44
ERROR - 2019-07-17 13:07:32 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 110
ERROR - 2019-07-17 13:07:39 --> Severity: Notice --> Undefined variable: ProjectId C:\xampp\htdocs\realestate\admin\application\controllers\Project.php 183
ERROR - 2019-07-17 13:07:39 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 18
ERROR - 2019-07-17 13:07:39 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 39
ERROR - 2019-07-17 13:07:39 --> Severity: Notice --> Undefined variable: projectlist C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 44
ERROR - 2019-07-17 13:07:39 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 110
ERROR - 2019-07-17 13:18:33 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 18
ERROR - 2019-07-17 13:18:33 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 39
ERROR - 2019-07-17 13:18:33 --> Severity: Notice --> Undefined variable: projectlist C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 44
ERROR - 2019-07-17 13:18:33 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 110
ERROR - 2019-07-17 13:18:36 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 18
ERROR - 2019-07-17 13:18:36 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 39
ERROR - 2019-07-17 13:18:36 --> Severity: Notice --> Undefined variable: projectlist C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 44
ERROR - 2019-07-17 13:18:36 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 110
ERROR - 2019-07-17 13:18:36 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:18:36 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 13:18:36 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 13:18:36 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 18
ERROR - 2019-07-17 13:18:36 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 39
ERROR - 2019-07-17 13:18:36 --> Severity: Notice --> Undefined variable: projectlist C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 44
ERROR - 2019-07-17 13:18:36 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 110
ERROR - 2019-07-17 13:20:14 --> Severity: Notice --> Undefined index: project_id C:\xampp\htdocs\realestate\admin\application\controllers\Project.php 185
ERROR - 2019-07-17 13:20:14 --> Severity: Notice --> Undefined index: gallery_image C:\xampp\htdocs\realestate\admin\application\controllers\Project.php 186
ERROR - 2019-07-17 13:20:14 --> Severity: Notice --> Undefined index: IsActive C:\xampp\htdocs\realestate\admin\application\controllers\Project.php 187
ERROR - 2019-07-17 13:20:14 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 18
ERROR - 2019-07-17 13:20:14 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 39
ERROR - 2019-07-17 13:20:14 --> Severity: Notice --> Undefined variable: projectlist C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 44
ERROR - 2019-07-17 13:20:14 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 110
ERROR - 2019-07-17 13:20:14 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:20:14 --> Severity: Notice --> Undefined index: project_id C:\xampp\htdocs\realestate\admin\application\controllers\Project.php 185
ERROR - 2019-07-17 13:20:14 --> Severity: Notice --> Undefined index: gallery_image C:\xampp\htdocs\realestate\admin\application\controllers\Project.php 186
ERROR - 2019-07-17 13:20:14 --> Severity: Notice --> Undefined index: IsActive C:\xampp\htdocs\realestate\admin\application\controllers\Project.php 187
ERROR - 2019-07-17 13:20:14 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 18
ERROR - 2019-07-17 13:20:14 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 39
ERROR - 2019-07-17 13:20:14 --> Severity: Notice --> Undefined variable: projectlist C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 44
ERROR - 2019-07-17 13:20:14 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 110
ERROR - 2019-07-17 13:20:16 --> Severity: Notice --> Undefined index: project_id C:\xampp\htdocs\realestate\admin\application\controllers\Project.php 185
ERROR - 2019-07-17 13:20:16 --> Severity: Notice --> Undefined index: gallery_image C:\xampp\htdocs\realestate\admin\application\controllers\Project.php 186
ERROR - 2019-07-17 13:20:16 --> Severity: Notice --> Undefined index: IsActive C:\xampp\htdocs\realestate\admin\application\controllers\Project.php 187
ERROR - 2019-07-17 13:20:16 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 18
ERROR - 2019-07-17 13:20:16 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 39
ERROR - 2019-07-17 13:20:16 --> Severity: Notice --> Undefined variable: projectlist C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 44
ERROR - 2019-07-17 13:20:16 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 110
ERROR - 2019-07-17 13:20:38 --> Severity: error --> Exception: Call to undefined method Project_model::getdatagallery() C:\xampp\htdocs\realestate\admin\application\controllers\Project.php 183
ERROR - 2019-07-17 13:20:54 --> Severity: error --> Exception: Call to undefined method Project_model::getgellerydata() C:\xampp\htdocs\realestate\admin\application\controllers\Project.php 183
ERROR - 2019-07-17 13:20:59 --> Severity: error --> Exception: Call to undefined method Project_model::getgellerydata() C:\xampp\htdocs\realestate\admin\application\controllers\Project.php 183
ERROR - 2019-07-17 13:20:59 --> Severity: error --> Exception: Call to undefined method Project_model::getgellerydata() C:\xampp\htdocs\realestate\admin\application\controllers\Project.php 183
ERROR - 2019-07-17 13:22:27 --> Severity: error --> Exception: syntax error, unexpected 'die' (T_EXIT) C:\xampp\htdocs\realestate\admin\application\controllers\Project.php 184
ERROR - 2019-07-17 13:22:32 --> Severity: error --> Exception: Call to undefined method Project_model::getgellerydata() C:\xampp\htdocs\realestate\admin\application\controllers\Project.php 183
ERROR - 2019-07-17 13:22:43 --> Severity: error --> Exception: Call to undefined method Project_model::getgellerydata() C:\xampp\htdocs\realestate\admin\application\controllers\Project.php 183
ERROR - 2019-07-17 13:23:20 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 18
ERROR - 2019-07-17 13:23:20 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 39
ERROR - 2019-07-17 13:23:20 --> Severity: Notice --> Undefined variable: projectlist C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 44
ERROR - 2019-07-17 13:23:20 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 110
ERROR - 2019-07-17 13:23:20 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:23:20 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 13:23:20 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 18
ERROR - 2019-07-17 13:23:20 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 39
ERROR - 2019-07-17 13:23:20 --> Severity: Notice --> Undefined variable: projectlist C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 44
ERROR - 2019-07-17 13:23:20 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 110
ERROR - 2019-07-17 13:23:20 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 13:23:50 --> Severity: Notice --> Undefined variable: projectlist C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 44
ERROR - 2019-07-17 13:23:50 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:23:50 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 13:23:50 --> Severity: Notice --> Undefined variable: projectlist C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 44
ERROR - 2019-07-17 13:23:50 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 13:24:38 --> Severity: Notice --> Undefined variable: projectlist C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 44
ERROR - 2019-07-17 13:24:38 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:24:39 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 13:24:39 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 13:24:39 --> Severity: Notice --> Undefined variable: projectlist C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 44
ERROR - 2019-07-17 13:26:45 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:26:45 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 13:26:45 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 13:35:23 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:35:24 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 13:35:24 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 13:36:11 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:36:11 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 13:36:12 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 13:36:37 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:36:37 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 13:36:37 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 13:36:40 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:37:14 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:37:14 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 13:37:14 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 13:37:18 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:37:18 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 13:37:18 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 13:37:18 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 13:37:21 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:39:04 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 13:39:04 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 13:39:29 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:39:29 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 13:39:29 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 13:39:44 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:39:45 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 13:39:45 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 13:39:55 --> Query error: Unknown column 'CreatedOn' in 'field list' - Invalid query: UPDATE `tblgallery` SET `project_id` = '6', `gallery_image` = '97921GalleryImages.jpg', `IsActive` = 'Active', `CreatedOn` = '2019-07-17  13:39:55'
WHERE `gallery_id` IS NULL
ERROR - 2019-07-17 13:41:08 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:41:08 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 13:41:08 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 13:41:08 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 13:41:08 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 13:41:08 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 13:41:11 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:41:18 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:41:18 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 13:41:50 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:42:02 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:42:02 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 13:42:31 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:42:37 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:42:37 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 13:42:42 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:42:51 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:42:51 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 13:43:00 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:43:00 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 13:43:00 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 13:43:00 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 13:43:00 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 13:43:00 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 13:43:13 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:43:13 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 13:43:13 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 13:43:13 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 13:43:13 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 13:43:13 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 13:45:22 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:45:22 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 13:45:22 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 13:45:22 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 13:45:22 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 13:45:22 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 13:45:42 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:45:42 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 13:45:42 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 13:45:43 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 13:45:43 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 13:45:43 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 13:45:49 --> 404 Page Not Found: Project/gallery_delete
ERROR - 2019-07-17 13:47:00 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:47:00 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 13:47:00 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 13:47:00 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 13:47:00 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 13:47:00 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 13:48:20 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:48:20 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 13:48:20 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 13:48:20 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 13:48:20 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 13:48:20 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 13:48:23 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:48:23 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 13:48:23 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 13:48:23 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 13:48:32 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:48:32 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 13:48:32 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 13:48:32 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 13:48:32 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 13:48:32 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 13:50:07 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:50:07 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 13:50:07 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 13:50:07 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 13:50:07 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 13:50:07 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 13:51:32 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:51:32 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 13:51:32 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 13:51:32 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 13:51:32 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 13:51:32 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 13:51:49 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:51:50 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 13:51:50 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 13:51:50 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 13:51:50 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 13:51:50 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 13:52:17 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:52:18 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 13:52:18 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 13:52:18 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 13:52:18 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 13:52:18 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 13:52:35 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:52:35 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 13:52:35 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 13:52:35 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 13:52:35 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 13:52:35 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 13:59:46 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 13:59:47 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 13:59:47 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 13:59:47 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 13:59:47 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 13:59:47 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 14:00:13 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 14:00:13 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 14:00:14 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 14:00:16 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 14:00:16 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 14:00:16 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 14:00:19 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 14:00:21 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 14:00:23 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 14:00:23 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 14:00:23 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 14:00:55 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 14:00:55 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 14:00:55 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 14:00:56 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 14:00:56 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 14:00:56 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 14:01:12 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 14:01:12 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 14:01:12 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 14:01:12 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 14:01:12 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 14:01:12 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 14:01:12 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 14:02:04 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 14:02:05 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 14:02:05 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 14:02:05 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 14:02:05 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 14:02:05 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 14:03:02 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 14:03:02 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 14:03:02 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 14:03:02 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 14:03:03 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 14:03:03 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 14:04:18 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 14:04:19 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 14:04:19 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 14:04:19 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 14:04:19 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 14:04:19 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 14:05:42 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 14:05:43 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 14:05:43 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 14:05:43 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 14:06:33 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 14:06:33 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 14:06:33 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 14:06:34 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 14:06:43 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 14:06:43 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 14:06:43 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 14:06:43 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 14:07:03 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 14:07:04 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 14:07:04 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 14:07:04 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 14:07:04 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 14:07:04 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 14:07:32 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 14:07:32 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 14:07:32 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 14:07:32 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 14:07:32 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 14:07:32 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 14:07:34 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 14:07:35 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 14:07:35 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 14:07:35 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 14:07:45 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 14:07:46 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 14:07:46 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 14:07:46 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 14:07:50 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 14:07:51 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 14:07:51 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 14:07:51 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 14:08:17 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 14:08:17 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 14:08:17 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 14:08:17 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 14:08:17 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 14:08:17 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 15:00:44 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:00:45 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 15:00:45 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 15:00:45 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 15:00:45 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 15:00:45 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 15:00:51 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:00:52 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 15:02:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\realestate\admin\application\helpers\custom_helper.php 1362
ERROR - 2019-07-17 15:02:34 --> Severity: Notice --> Undefined property: stdClass::$gallery_image C:\xampp\htdocs\realestate\admin\application\views\Project\List_gallery.php 56
ERROR - 2019-07-17 15:02:34 --> Severity: Notice --> Undefined property: stdClass::$gallery_id C:\xampp\htdocs\realestate\admin\application\views\Project\List_gallery.php 77
ERROR - 2019-07-17 15:02:34 --> Severity: Notice --> Undefined property: stdClass::$gallery_id C:\xampp\htdocs\realestate\admin\application\views\Project\List_gallery.php 78
ERROR - 2019-07-17 15:02:34 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:02:34 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 15:02:34 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 15:02:34 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 15:02:34 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 15:02:34 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 15:04:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\realestate\admin\application\helpers\custom_helper.php 1362
ERROR - 2019-07-17 15:04:07 --> Severity: Notice --> Undefined property: stdClass::$gallery_image C:\xampp\htdocs\realestate\admin\application\views\Project\List_gallery.php 56
ERROR - 2019-07-17 15:04:07 --> Severity: Notice --> Undefined property: stdClass::$gallery_id C:\xampp\htdocs\realestate\admin\application\views\Project\List_gallery.php 77
ERROR - 2019-07-17 15:04:07 --> Severity: Notice --> Undefined property: stdClass::$gallery_id C:\xampp\htdocs\realestate\admin\application\views\Project\List_gallery.php 78
ERROR - 2019-07-17 15:04:08 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:04:08 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 15:04:08 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 15:04:08 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 15:04:08 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 15:04:08 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 15:04:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\realestate\admin\application\helpers\custom_helper.php 1362
ERROR - 2019-07-17 15:04:27 --> Severity: Notice --> Undefined property: stdClass::$gallery_image C:\xampp\htdocs\realestate\admin\application\views\Project\List_gallery.php 56
ERROR - 2019-07-17 15:04:27 --> Severity: Notice --> Undefined property: stdClass::$gallery_id C:\xampp\htdocs\realestate\admin\application\views\Project\List_gallery.php 77
ERROR - 2019-07-17 15:04:27 --> Severity: Notice --> Undefined property: stdClass::$gallery_id C:\xampp\htdocs\realestate\admin\application\views\Project\List_gallery.php 78
ERROR - 2019-07-17 15:04:27 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:04:27 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 15:04:27 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 15:04:28 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 15:04:28 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 15:04:28 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 15:04:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\realestate\admin\application\helpers\custom_helper.php 1362
ERROR - 2019-07-17 15:04:42 --> Severity: Notice --> Undefined property: stdClass::$gallery_image C:\xampp\htdocs\realestate\admin\application\views\Project\List_gallery.php 56
ERROR - 2019-07-17 15:04:42 --> Severity: Notice --> Undefined property: stdClass::$gallery_id C:\xampp\htdocs\realestate\admin\application\views\Project\List_gallery.php 77
ERROR - 2019-07-17 15:04:42 --> Severity: Notice --> Undefined property: stdClass::$gallery_id C:\xampp\htdocs\realestate\admin\application\views\Project\List_gallery.php 78
ERROR - 2019-07-17 15:04:42 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:04:42 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 15:04:42 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 15:04:42 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 15:04:42 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 15:04:42 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 15:04:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\realestate\admin\application\helpers\custom_helper.php 1362
ERROR - 2019-07-17 15:04:44 --> Severity: Notice --> Undefined property: stdClass::$gallery_image C:\xampp\htdocs\realestate\admin\application\views\Project\List_gallery.php 56
ERROR - 2019-07-17 15:04:44 --> Severity: Notice --> Undefined property: stdClass::$gallery_id C:\xampp\htdocs\realestate\admin\application\views\Project\List_gallery.php 77
ERROR - 2019-07-17 15:04:44 --> Severity: Notice --> Undefined property: stdClass::$gallery_id C:\xampp\htdocs\realestate\admin\application\views\Project\List_gallery.php 78
ERROR - 2019-07-17 15:04:44 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:04:45 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 15:04:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\realestate\admin\application\helpers\custom_helper.php 1362
ERROR - 2019-07-17 15:04:56 --> Severity: Notice --> Undefined property: stdClass::$gallery_image C:\xampp\htdocs\realestate\admin\application\views\Project\List_planlayout.php 56
ERROR - 2019-07-17 15:04:56 --> Severity: Notice --> Undefined property: stdClass::$gallery_id C:\xampp\htdocs\realestate\admin\application\views\Project\List_planlayout.php 77
ERROR - 2019-07-17 15:04:56 --> Severity: Notice --> Undefined property: stdClass::$gallery_id C:\xampp\htdocs\realestate\admin\application\views\Project\List_planlayout.php 78
ERROR - 2019-07-17 15:04:56 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:04:56 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 15:04:56 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 15:04:56 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 15:04:56 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 15:04:56 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 15:05:03 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:05:03 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 15:05:05 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:05:14 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:05:14 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 15:05:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\realestate\admin\application\helpers\custom_helper.php 1362
ERROR - 2019-07-17 15:05:19 --> Severity: Notice --> Undefined property: stdClass::$gallery_image C:\xampp\htdocs\realestate\admin\application\views\Project\List_planlayout.php 56
ERROR - 2019-07-17 15:05:19 --> Severity: Notice --> Undefined property: stdClass::$gallery_id C:\xampp\htdocs\realestate\admin\application\views\Project\List_planlayout.php 77
ERROR - 2019-07-17 15:05:19 --> Severity: Notice --> Undefined property: stdClass::$gallery_id C:\xampp\htdocs\realestate\admin\application\views\Project\List_planlayout.php 78
ERROR - 2019-07-17 15:05:19 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:05:19 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 15:05:20 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:05:38 --> Severity: Notice --> Undefined variable: ProjectId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 18
ERROR - 2019-07-17 15:05:38 --> Severity: Notice --> Undefined variable: ProjectId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 39
ERROR - 2019-07-17 15:05:38 --> Severity: Notice --> Undefined variable: ProjectTitle C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 41
ERROR - 2019-07-17 15:05:38 --> Severity: Notice --> Undefined variable: Projectsdesc C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 45
ERROR - 2019-07-17 15:05:38 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 51
ERROR - 2019-07-17 15:05:38 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 52
ERROR - 2019-07-17 15:05:38 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 53
ERROR - 2019-07-17 15:05:38 --> Severity: Notice --> Undefined variable: Projectldesc C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 59
ERROR - 2019-07-17 15:05:38 --> Severity: Notice --> Undefined variable: Projectlogo C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 70
ERROR - 2019-07-17 15:05:38 --> Severity: Notice --> Undefined variable: Projectlogo C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 76
ERROR - 2019-07-17 15:05:38 --> Severity: Notice --> Undefined variable: ProjectImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 86
ERROR - 2019-07-17 15:05:38 --> Severity: Notice --> Undefined variable: ProjectImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 92
ERROR - 2019-07-17 15:05:38 --> Severity: Notice --> Undefined variable: Project_brochure C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 102
ERROR - 2019-07-17 15:05:38 --> Severity: Notice --> Undefined variable: Project_brochure C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 108
ERROR - 2019-07-17 15:05:38 --> Severity: Notice --> Undefined variable: ProjectId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 152
ERROR - 2019-07-17 15:05:38 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:05:38 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 15:05:38 --> Severity: Notice --> Undefined variable: ProjectId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 18
ERROR - 2019-07-17 15:05:38 --> Severity: Notice --> Undefined variable: ProjectId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 39
ERROR - 2019-07-17 15:05:38 --> Severity: Notice --> Undefined variable: ProjectTitle C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 41
ERROR - 2019-07-17 15:05:38 --> Severity: Notice --> Undefined variable: Projectsdesc C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 45
ERROR - 2019-07-17 15:05:38 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 51
ERROR - 2019-07-17 15:05:38 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 52
ERROR - 2019-07-17 15:05:38 --> Severity: Notice --> Undefined variable: ProjectStatus C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 53
ERROR - 2019-07-17 15:05:38 --> Severity: Notice --> Undefined variable: Projectldesc C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 59
ERROR - 2019-07-17 15:05:38 --> Severity: Notice --> Undefined variable: Projectlogo C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 70
ERROR - 2019-07-17 15:05:38 --> Severity: Notice --> Undefined variable: Projectlogo C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 76
ERROR - 2019-07-17 15:05:38 --> Severity: Notice --> Undefined variable: ProjectImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 86
ERROR - 2019-07-17 15:05:38 --> Severity: Notice --> Undefined variable: ProjectImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 92
ERROR - 2019-07-17 15:05:38 --> Severity: Notice --> Undefined variable: Project_brochure C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 102
ERROR - 2019-07-17 15:05:38 --> Severity: Notice --> Undefined variable: Project_brochure C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 108
ERROR - 2019-07-17 15:05:38 --> Severity: Notice --> Undefined variable: ProjectId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 152
ERROR - 2019-07-17 15:05:38 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 15:06:30 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:06:30 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 15:06:30 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 15:07:04 --> Severity: Notice --> Undefined variable: PlanlayoutId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 18
ERROR - 2019-07-17 15:07:04 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:07:05 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 15:07:05 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 15:07:05 --> Severity: Notice --> Undefined variable: PlanlayoutId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 18
ERROR - 2019-07-17 15:07:20 --> Severity: Notice --> Undefined variable: PlanlayoutId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 18
ERROR - 2019-07-17 15:07:20 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:07:20 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 15:07:20 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 15:07:20 --> Severity: Notice --> Undefined variable: PlanlayoutId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 18
ERROR - 2019-07-17 15:07:29 --> Severity: Notice --> Undefined variable: PlanlayoutId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 18
ERROR - 2019-07-17 15:07:29 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:07:29 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 15:07:29 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 15:07:29 --> Severity: Notice --> Undefined variable: PlanlayoutId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 18
ERROR - 2019-07-17 15:08:57 --> Severity: Notice --> Undefined variable: PlanlayoutId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 18
ERROR - 2019-07-17 15:08:57 --> Severity: Notice --> Undefined variable: PlanlayoutImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 58
ERROR - 2019-07-17 15:08:57 --> Severity: Notice --> Undefined variable: PlanlayoutImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 64
ERROR - 2019-07-17 15:08:57 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:08:58 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 15:08:58 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 15:08:58 --> Severity: Notice --> Undefined variable: PlanlayoutId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 18
ERROR - 2019-07-17 15:08:58 --> Severity: Notice --> Undefined variable: PlanlayoutImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 58
ERROR - 2019-07-17 15:08:58 --> Severity: Notice --> Undefined variable: PlanlayoutImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 64
ERROR - 2019-07-17 15:09:35 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 39
ERROR - 2019-07-17 15:09:35 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 111
ERROR - 2019-07-17 15:09:35 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 149
ERROR - 2019-07-17 15:09:35 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:09:35 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 15:09:35 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 15:09:35 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 39
ERROR - 2019-07-17 15:09:35 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 111
ERROR - 2019-07-17 15:09:35 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 149
ERROR - 2019-07-17 15:09:43 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 39
ERROR - 2019-07-17 15:09:43 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 111
ERROR - 2019-07-17 15:09:43 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 149
ERROR - 2019-07-17 15:09:43 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:09:44 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 15:09:44 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 15:09:44 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 39
ERROR - 2019-07-17 15:09:44 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 111
ERROR - 2019-07-17 15:09:44 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 149
ERROR - 2019-07-17 15:10:01 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 39
ERROR - 2019-07-17 15:10:01 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 111
ERROR - 2019-07-17 15:10:01 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 149
ERROR - 2019-07-17 15:10:02 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:10:02 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 15:10:02 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 15:10:02 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 39
ERROR - 2019-07-17 15:10:02 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 111
ERROR - 2019-07-17 15:10:02 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 149
ERROR - 2019-07-17 15:10:44 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 111
ERROR - 2019-07-17 15:10:44 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 149
ERROR - 2019-07-17 15:10:44 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:10:45 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 15:10:45 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 111
ERROR - 2019-07-17 15:10:45 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 149
ERROR - 2019-07-17 15:10:45 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 15:10:55 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 149
ERROR - 2019-07-17 15:10:55 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:10:55 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 15:10:55 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 15:10:55 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 149
ERROR - 2019-07-17 15:10:58 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 149
ERROR - 2019-07-17 15:10:58 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:10:59 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 15:10:59 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 15:10:59 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 149
ERROR - 2019-07-17 15:11:29 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 149
ERROR - 2019-07-17 15:11:29 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:11:29 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 15:11:29 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 15:11:29 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 149
ERROR - 2019-07-17 15:11:30 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 149
ERROR - 2019-07-17 15:11:30 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:11:31 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 15:11:31 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 15:11:31 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 149
ERROR - 2019-07-17 15:11:34 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 149
ERROR - 2019-07-17 15:11:34 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:11:35 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 15:11:35 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 15:11:35 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 149
ERROR - 2019-07-17 15:15:06 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 149
ERROR - 2019-07-17 15:15:06 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 15:15:06 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 15:15:06 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 149
ERROR - 2019-07-17 15:15:16 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 149
ERROR - 2019-07-17 15:15:16 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:15:17 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 149
ERROR - 2019-07-17 15:15:51 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 149
ERROR - 2019-07-17 15:15:51 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:15:52 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_planlayout.php 149
ERROR - 2019-07-17 15:16:14 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:16:15 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 15:16:15 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 15:19:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\realestate\admin\application\helpers\custom_helper.php 1362
ERROR - 2019-07-17 15:19:13 --> Severity: Notice --> Undefined property: stdClass::$gallery_image C:\xampp\htdocs\realestate\admin\application\views\Project\List_planlayout.php 56
ERROR - 2019-07-17 15:19:13 --> Severity: Notice --> Undefined property: stdClass::$gallery_id C:\xampp\htdocs\realestate\admin\application\views\Project\List_planlayout.php 77
ERROR - 2019-07-17 15:19:13 --> Severity: Notice --> Undefined property: stdClass::$gallery_id C:\xampp\htdocs\realestate\admin\application\views\Project\List_planlayout.php 78
ERROR - 2019-07-17 15:19:13 --> Severity: Notice --> Undefined property: stdClass::$gallery_image C:\xampp\htdocs\realestate\admin\application\views\Project\List_planlayout.php 56
ERROR - 2019-07-17 15:19:13 --> Severity: Notice --> Undefined property: stdClass::$gallery_id C:\xampp\htdocs\realestate\admin\application\views\Project\List_planlayout.php 77
ERROR - 2019-07-17 15:19:13 --> Severity: Notice --> Undefined property: stdClass::$gallery_id C:\xampp\htdocs\realestate\admin\application\views\Project\List_planlayout.php 78
ERROR - 2019-07-17 15:19:13 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:19:14 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 15:19:14 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 15:19:14 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 15:19:14 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 15:19:14 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 15:19:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\realestate\admin\application\helpers\custom_helper.php 1362
ERROR - 2019-07-17 15:19:29 --> Severity: Notice --> Undefined property: stdClass::$gallery_image C:\xampp\htdocs\realestate\admin\application\views\Project\List_planlayout.php 56
ERROR - 2019-07-17 15:19:29 --> Severity: Notice --> Undefined property: stdClass::$gallery_id C:\xampp\htdocs\realestate\admin\application\views\Project\List_planlayout.php 77
ERROR - 2019-07-17 15:19:29 --> Severity: Notice --> Undefined property: stdClass::$gallery_id C:\xampp\htdocs\realestate\admin\application\views\Project\List_planlayout.php 78
ERROR - 2019-07-17 15:19:29 --> Severity: Notice --> Undefined property: stdClass::$gallery_image C:\xampp\htdocs\realestate\admin\application\views\Project\List_planlayout.php 56
ERROR - 2019-07-17 15:19:29 --> Severity: Notice --> Undefined property: stdClass::$gallery_id C:\xampp\htdocs\realestate\admin\application\views\Project\List_planlayout.php 77
ERROR - 2019-07-17 15:19:29 --> Severity: Notice --> Undefined property: stdClass::$gallery_id C:\xampp\htdocs\realestate\admin\application\views\Project\List_planlayout.php 78
ERROR - 2019-07-17 15:19:29 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:19:29 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 15:19:29 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 15:19:29 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 15:19:29 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 15:19:29 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 15:20:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\realestate\admin\application\helpers\custom_helper.php 1362
ERROR - 2019-07-17 15:20:21 --> Severity: Notice --> Undefined property: stdClass::$gallery_image C:\xampp\htdocs\realestate\admin\application\views\Project\List_planlayout.php 56
ERROR - 2019-07-17 15:20:21 --> Severity: Notice --> Undefined property: stdClass::$gallery_id C:\xampp\htdocs\realestate\admin\application\views\Project\List_planlayout.php 77
ERROR - 2019-07-17 15:20:21 --> Severity: Notice --> Undefined property: stdClass::$gallery_id C:\xampp\htdocs\realestate\admin\application\views\Project\List_planlayout.php 78
ERROR - 2019-07-17 15:20:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\realestate\admin\application\helpers\custom_helper.php 1362
ERROR - 2019-07-17 15:20:21 --> Severity: Notice --> Undefined property: stdClass::$gallery_image C:\xampp\htdocs\realestate\admin\application\views\Project\List_planlayout.php 56
ERROR - 2019-07-17 15:20:21 --> Severity: Notice --> Undefined property: stdClass::$gallery_id C:\xampp\htdocs\realestate\admin\application\views\Project\List_planlayout.php 77
ERROR - 2019-07-17 15:20:21 --> Severity: Notice --> Undefined property: stdClass::$gallery_id C:\xampp\htdocs\realestate\admin\application\views\Project\List_planlayout.php 78
ERROR - 2019-07-17 15:20:21 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:20:22 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 15:20:22 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 15:20:22 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 15:20:22 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 15:20:22 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 15:20:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\realestate\admin\application\helpers\custom_helper.php 1363
ERROR - 2019-07-17 15:20:38 --> Severity: Notice --> Undefined property: stdClass::$gallery_image C:\xampp\htdocs\realestate\admin\application\views\Project\List_planlayout.php 56
ERROR - 2019-07-17 15:20:38 --> Severity: Notice --> Undefined property: stdClass::$gallery_id C:\xampp\htdocs\realestate\admin\application\views\Project\List_planlayout.php 77
ERROR - 2019-07-17 15:20:38 --> Severity: Notice --> Undefined property: stdClass::$gallery_id C:\xampp\htdocs\realestate\admin\application\views\Project\List_planlayout.php 78
ERROR - 2019-07-17 15:20:38 --> Severity: Notice --> Undefined property: stdClass::$gallery_image C:\xampp\htdocs\realestate\admin\application\views\Project\List_planlayout.php 56
ERROR - 2019-07-17 15:20:38 --> Severity: Notice --> Undefined property: stdClass::$gallery_id C:\xampp\htdocs\realestate\admin\application\views\Project\List_planlayout.php 77
ERROR - 2019-07-17 15:20:38 --> Severity: Notice --> Undefined property: stdClass::$gallery_id C:\xampp\htdocs\realestate\admin\application\views\Project\List_planlayout.php 78
ERROR - 2019-07-17 15:20:38 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:20:38 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 15:20:38 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 15:20:38 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 15:20:38 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 15:20:38 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 15:21:03 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:21:03 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 15:21:03 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 15:21:42 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:21:48 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO), expecting ';' C:\xampp\htdocs\realestate\admin\application\helpers\custom_helper.php 1362
ERROR - 2019-07-17 15:21:53 --> Severity: Notice --> Undefined property: stdClass::$gallery_image C:\xampp\htdocs\realestate\admin\application\views\Project\List_planlayout.php 56
ERROR - 2019-07-17 15:21:53 --> Severity: Notice --> Undefined property: stdClass::$gallery_id C:\xampp\htdocs\realestate\admin\application\views\Project\List_planlayout.php 77
ERROR - 2019-07-17 15:21:53 --> Severity: Notice --> Undefined property: stdClass::$gallery_id C:\xampp\htdocs\realestate\admin\application\views\Project\List_planlayout.php 78
ERROR - 2019-07-17 15:21:54 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:21:54 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 15:21:54 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 15:21:54 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 15:21:54 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 15:21:54 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 15:22:46 --> Severity: Notice --> Undefined property: stdClass::$gallery_image C:\xampp\htdocs\realestate\admin\application\views\Project\List_planlayout.php 57
ERROR - 2019-07-17 15:22:46 --> Severity: Notice --> Undefined property: stdClass::$gallery_id C:\xampp\htdocs\realestate\admin\application\views\Project\List_planlayout.php 77
ERROR - 2019-07-17 15:22:46 --> Severity: Notice --> Undefined property: stdClass::$gallery_id C:\xampp\htdocs\realestate\admin\application\views\Project\List_planlayout.php 78
ERROR - 2019-07-17 15:22:46 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:22:47 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 15:22:47 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 15:22:47 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 15:22:47 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 15:22:47 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 15:22:56 --> Severity: Notice --> Undefined property: stdClass::$gallery_id C:\xampp\htdocs\realestate\admin\application\views\Project\List_planlayout.php 77
ERROR - 2019-07-17 15:22:56 --> Severity: Notice --> Undefined property: stdClass::$gallery_id C:\xampp\htdocs\realestate\admin\application\views\Project\List_planlayout.php 78
ERROR - 2019-07-17 15:22:56 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:22:56 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 15:22:56 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 15:22:56 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 15:22:56 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 15:22:56 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 15:23:09 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:23:09 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 15:23:09 --> 404 Page Not Found: Default/images
ERROR - 2019-07-17 15:23:09 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 15:23:09 --> 404 Page Not Found: Project/app-assets
ERROR - 2019-07-17 15:23:09 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 15:23:12 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:24:26 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:24:26 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 15:24:26 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 15:25:49 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:25:49 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 15:25:49 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 15:25:50 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:25:50 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:25:51 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 15:25:51 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 15:26:21 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:26:21 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 15:26:21 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 15:26:28 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:26:28 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 15:26:28 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 15:26:34 --> Severity: error --> Exception: Call to undefined method Project_model::getlayoutdata() C:\xampp\htdocs\realestate\admin\application\controllers\Project.php 286
ERROR - 2019-07-17 15:26:55 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 18
ERROR - 2019-07-17 15:26:55 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 39
ERROR - 2019-07-17 15:26:55 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 58
ERROR - 2019-07-17 15:26:55 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 64
ERROR - 2019-07-17 15:26:55 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 111
ERROR - 2019-07-17 15:26:55 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 149
ERROR - 2019-07-17 15:26:55 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:26:56 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 15:26:56 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 15:26:56 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 18
ERROR - 2019-07-17 15:26:56 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 39
ERROR - 2019-07-17 15:26:56 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 58
ERROR - 2019-07-17 15:26:56 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 64
ERROR - 2019-07-17 15:26:56 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 111
ERROR - 2019-07-17 15:26:56 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 149
ERROR - 2019-07-17 15:27:26 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 18
ERROR - 2019-07-17 15:27:26 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 39
ERROR - 2019-07-17 15:27:26 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 58
ERROR - 2019-07-17 15:27:26 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 64
ERROR - 2019-07-17 15:27:26 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 111
ERROR - 2019-07-17 15:27:26 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 149
ERROR - 2019-07-17 15:27:26 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:27:27 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 15:27:27 --> 404 Page Not Found: Favicon/favicon.ico
ERROR - 2019-07-17 15:27:27 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 18
ERROR - 2019-07-17 15:27:27 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 39
ERROR - 2019-07-17 15:27:27 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 58
ERROR - 2019-07-17 15:27:27 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 64
ERROR - 2019-07-17 15:27:27 --> Severity: Notice --> Undefined variable: GalleryId C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 111
ERROR - 2019-07-17 15:27:27 --> Severity: Notice --> Undefined variable: GalleryImage C:\xampp\htdocs\realestate\admin\application\views\Project\Add_gallery.php 149
ERROR - 2019-07-17 15:27:41 --> 404 Page Not Found: App-assets/images
ERROR - 2019-07-17 15:27:42 --> 404 Page Not Found: Favicon/favicon-32.png
ERROR - 2019-07-17 15:27:42 --> 404 Page Not Found: Favicon/favicon.ico
